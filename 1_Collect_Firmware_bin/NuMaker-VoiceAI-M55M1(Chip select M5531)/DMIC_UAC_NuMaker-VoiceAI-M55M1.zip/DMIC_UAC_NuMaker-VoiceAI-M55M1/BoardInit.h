/**************************************************************************//**
 * @file     BoardInit.h
 * @version  V2.00
 * @brief    NuMaker-VoiceAI-M55M1 board related functions
 *
 * @copyright SPDX-License-Identifier: Apache-2.0
 * @copyright Copyright (C) 2023 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/
#ifndef __BOARD_INIT_H__
#define __BOARD_INIT_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/** Status LEDs. NuMaker-VoiceAI-M55M1 has two, where NuMaker-GestureAI-M55M1
 *  had only one - hence the index argument on the LED calls below. */
typedef enum
{
    BOARD_LED_Y = 0,    /*!< Yellow LED_Y on PC.4, active low */
    BOARD_LED_G = 1,    /*!< Green  LED_G on PC.5, active low */
    BOARD_LED_COUNT
} E_BOARD_LED;

/**
  * @brief Initiate the hardware resources
  * @return 0: Success, <0: Fail
  * @details Initiate clock, debug UART4 (PB.11/PB.10), DMIC0 pins (PA.4/PA.5),
  *          HSUSBD PHY, status LEDs (PC.4/PC.5) and user button (PA.7).
  */
int BoardInit(void);

/**
  * @brief Drive one of the status LEDs (active low on this board)
  * @param[in] u32Led One of E_BOARD_LED
  * @param[in] u32On  0 = off, non-zero = lit
  */
void BoardLedSet(uint32_t u32Led, uint32_t u32On);

/**
  * @brief Toggle one of the status LEDs
  * @param[in] u32Led One of E_BOARD_LED
  */
void BoardLedToggle(uint32_t u32Led);

/**
  * @brief Read the user button (BTN1, PA.7, active low)
  * @return 1 when pressed, 0 when released
  */
uint32_t BoardKeyPressed(void);

#ifdef __cplusplus
}
#endif

#endif
