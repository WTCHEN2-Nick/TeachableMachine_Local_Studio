/**************************************************************************//**
 * @file     main.c
 * @version  V3.00
 * @brief    NuMaker-VoiceAI-M55M1: on-board MEMS DMIC -> USB microphone.
 *
 * The board does carry an audio codec (NAU88L21), an amplifier (NAU8318) and a
 * speaker connector (LS1), but this sample does not drive them: the HSUSB
 * Type-C port is the only audio sink. The board enumerates on the PC as a USB
 * Audio Class 1.0 recording device and can be selected as a microphone input.
 *
 *   MP34DT05-M (U4; the second footprint U10 is marked NC, so mono)
 *   PA.4 = DMIC0_CLK, PA.5 = DMIC0_DAT
 *       -> DMIC0 channel 0, 16 kHz / mono / signed 16-bit PCM
 *       -> LPPDMA0 ch2, one 1 ms block per USB frame
 *            |-> HSUSBD UAC 1.0 ISO IN endpoint -> PC microphone
 *            '-> application ring buffer -> UART4 level meter (diagnostics)
 *
 * The level meter runs whether or not a host has opened the audio endpoint, so
 * the microphone can be verified from the UART alone. LED_G additionally
 * lights whenever the last 10 ms block carried signal, so the microphone can be
 * verified with no PC connection at all - useful while confirming which DMIC
 * channel the mic actually lands on (see DMIC_MIC_CH_MSK in DMICRecord.h).
 *
 * SPDX-License-Identifier: Apache-2.0
 ******************************************************************************/
#include <stdio.h>
#include <stdlib.h>

#include "NuMicro.h"
#include "BoardInit.h"
#include "DMICRecord.h"
#include "usbd_audio.h"
/* Last: redirects printf() in this file to both UART4 and the USB CDC console. */
#include "cdc_console.h"

/*---------------------------------------------------------------------------*/
/* Capture configuration                                                     */
/*---------------------------------------------------------------------------*/
#define AUDIO_SAMPLE_RATE       AUDIO_RATE
#define AUDIO_CHANNELS          REC_CHANNELS

#if (AUDIO_SAMPLE_RATE != 16000)
    #error "This sample is fixed at AUDIO_RATE = 16000 Hz"
#endif

#if (AUDIO_CHANNELS != 1)
    #error "The board has a single microphone, so REC_CHANNELS must be 1 (mono)"
#endif

/* 160 samples = 10 ms at 16 kHz. The app ring stores 32 of them = 320 ms of
 * slack, which is far more than the 10 ms cadence of the main loop needs; the
 * headroom simply means a slow printf can never stall capture. */
#define APP_BLOCK_SAMPLES       (160U)
#define APP_BLOCK_COUNTS        (32U)
#define READ_CHUNK_SAMPLES      APP_BLOCK_SAMPLES

/* 100 x 10 ms = one level report per second. */
#define REPORT_EVERY_CHUNKS     (100U)
#define CLIP_THRESHOLD          (31000)

/* After this many consecutive silent seconds, print the wiring hint once. */
#define SILENT_SECONDS_HINT     (10U)

/* LED_G lights when a 10 ms block peaks above this (~2.4 % of full scale).
 * Chosen to sit above the MP34DT05-M noise floor so the LED is a usable
 * "the microphone is alive" indicator with no PC and no UART attached. */
#define SIGNAL_LED_THRESHOLD    (800)

static void PrintLevel(int32_t i32Peak, uint32_t u32ClipCount, uint32_t u32Streaming)
{
    const int i32BarWidth = 20;
    int i32Filled = (int)(((int64_t)i32Peak * i32BarWidth) / 32768);
    int i;

    if (i32Filled > i32BarWidth)
        i32Filled = i32BarWidth;

    printf("[");

    for (i = 0; i < i32BarWidth; i++)
        printf(i < i32Filled ? "#" : "-");

    printf("] peak=%5d (%3d%%)  usb=%s",
           (int)i32Peak,
           (int)(((int64_t)i32Peak * 100) / 32768),
           u32Streaming ? "streaming" : (HSUSBD_IS_ATTACHED() ? "attached " : "unplugged"));

    if (u32ClipCount != 0U)
        printf("  *** CLIP x%u -- lower DMIC_DSP_GAIN_DB ***", (unsigned)u32ClipCount);

    printf("\n");
}

/* LED_Y (PC.4) reports the USB audio state without needing the UART:
 *   solid on          host has opened the recording endpoint
 *   fast blink (2 Hz) cable attached, host has not started streaming
 *   slow blink (1 Hz) no VBUS - board is running on the debugger only        */
static void UpdateStatusLed(uint32_t u32Streaming, uint32_t u32Tick10ms)
{
    if (u32Streaming)
    {
        BoardLedSet(BOARD_LED_Y, 1U);
    }
    else if (HSUSBD_IS_ATTACHED())
    {
        BoardLedSet(BOARD_LED_Y, ((u32Tick10ms / 25U) & 1U) == 0U);
    }
    else
    {
        BoardLedSet(BOARD_LED_Y, ((u32Tick10ms / 50U) & 1U) == 0U);
    }
}

int main(void)
{
    static int16_t ai16Chunk[READ_CHUNK_SAMPLES * AUDIO_CHANNELS];
    int32_t i32Peak = 0;
    uint32_t u32ClipCount = 0U;
    uint32_t u32ChunkCount = 0U;
    uint32_t u32Tick10ms = 0U;
    uint32_t u32SilentSeconds = 0U;
    uint32_t u32HintPrinted = 0U;
    int32_t i32Ret;

    if (BoardInit() != 0)
    {
        printf("BoardInit failed\n");

        while (1);
    }

    printf("\n");
    printf("+------------------------------------------------------------+\n");
    printf("| NuMaker-VoiceAI-M55M1  DMIC -> USB microphone (UAC 1.0)     |\n");
    printf("+------------------------------------------------------------+\n");
    printf("Microphone   : MP34DT05-M, PA.4 DMIC0_CLK / PA.5 DMIC0_DAT\n");
    printf("DMIC channel : %u (unconfirmed - see DMICRecord.h if silent)\n",
           (unsigned)((DMIC_MIC_CH_MSK == DMIC_CTL_CHEN0_Msk) ? 0U : 1U));
    printf("Format       : %u Hz, mono, signed 16-bit PCM\n",
           (unsigned)AUDIO_SAMPLE_RATE);
    printf("USB          : HSUSB Type-C (J1), UAC 1.0 recording device\n");
    printf("Audio out    : USB only - the NAU88L21 codec is not used here\n");
    printf("\n");

    /* DMICRecord_Init also brings up the HSUSBD UAC interface. */
    i32Ret = DMICRecord_Init(AUDIO_SAMPLE_RATE,
                             AUDIO_CHANNELS,
                             APP_BLOCK_SAMPLES,
                             APP_BLOCK_COUNTS);

    if (i32Ret != 0)
    {
        printf("DMICRecord_Init failed (%d)\n", (int)i32Ret);

        while (1);
    }

    DMICRecord_StartRec();

    printf("\nPlug the Type-C port into a PC and pick \"VoiceAI DMIC Mic\"\n");
    printf("as the recording device. The level meter below runs regardless.\n\n");

    while (1)
    {
        uint32_t i;
        uint32_t u32Streaming;
        int32_t  i32ChunkPeak;

        /* Pump the USB console FIRST, before the `continue` below. This is the
           only place console output is pushed to the endpoint and the only
           place typed commands are executed - CdcConsole_Write() itself never
           touches USB, precisely so that it stays safe to call from an ISR. */
        CdcConsole_Poll();

        if (DMICRecord_AvailSamples() < (int32_t)READ_CHUNK_SAMPLES)
            continue;

        if (DMICRecord_ReadSamples(ai16Chunk, READ_CHUNK_SAMPLES) != 0)
            continue;

        DMICRecord_UpdateReadSampleIndex(READ_CHUNK_SAMPLES);

        i32ChunkPeak = 0;

        for (i = 0U; i < (READ_CHUNK_SAMPLES * AUDIO_CHANNELS); i++)
        {
            int32_t i32Abs = ai16Chunk[i];

            if (i32Abs < 0)
                i32Abs = -i32Abs;

            if (i32Abs > i32ChunkPeak)
                i32ChunkPeak = i32Abs;

            if (i32Abs >= CLIP_THRESHOLD)
                u32ClipCount++;
        }

        if (i32ChunkPeak > i32Peak)
            i32Peak = i32ChunkPeak;

        /* LED_G follows the current 10 ms block, so it tracks speech in real
           time rather than the once-per-second reporting peak. */
        BoardLedSet(BOARD_LED_G, (i32ChunkPeak >= SIGNAL_LED_THRESHOLD) ? 1U : 0U);

        u32Streaming = (g_usbd_UsbAudioState == UAC_START_AUDIO_RECORD) ? 1U : 0U;

        u32Tick10ms++;
        UpdateStatusLed(u32Streaming, u32Tick10ms);

        if (++u32ChunkCount >= REPORT_EVERY_CHUNKS)
        {
            PrintLevel(i32Peak, u32ClipCount, u32Streaming);

            /* A dead-flat stream means the PDM data is being latched on the
               wrong clock edge, i.e. the mic is on the other channel of the
               DMIC0 pin pair. Say so once instead of leaving the user guessing. */
            if (i32Peak == 0)
            {
                if ((++u32SilentSeconds >= SILENT_SECONDS_HINT) && (u32HintPrinted == 0U))
                {
                    printf("\n*** No PDM data on DMIC channel %u after %u s. ***\n",
                           (unsigned)((DMIC_MIC_CH_MSK == DMIC_CTL_CHEN0_Msk) ? 0U : 1U),
                           (unsigned)SILENT_SECONDS_HINT);
                    printf("*** Try the fallback documented in Device/include/DMICRecord.h ***\n\n");
                    u32HintPrinted = 1U;
                }
            }
            else
            {
                u32SilentSeconds = 0U;
            }

            i32Peak = 0;
            u32ClipCount = 0U;
            u32ChunkCount = 0U;
        }
    }
}
