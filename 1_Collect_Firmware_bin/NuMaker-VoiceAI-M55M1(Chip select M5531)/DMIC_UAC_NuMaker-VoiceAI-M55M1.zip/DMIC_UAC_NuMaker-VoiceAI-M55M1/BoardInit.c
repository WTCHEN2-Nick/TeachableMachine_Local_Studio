/**************************************************************************//**
 * @file     BoardInit.c
 * @version  V2.00
 * @brief    Board bring-up for NuMaker-VoiceAI-M55M1.
 *
 * Board reference: UM_NuMaker-VoiceAI-M55M1_EN_Rev0.01, sheets
 * "M55M1R2LJC7E", "High-speed USB", "MEMS Digital MIC", "LED & Buttons",
 * "Extension Connectors".
 *
 *   MCU            M5531, LQFP64. The CMSIS device name is M5531R2LJAE (that is
 *                  what the VSCode csolution.yml and the Keil target select, and
 *                  what Nu-Link's "Chip Select" is set to). Note the UM text and
 *                  the silkscreen say "M55M1R2LJC7E" - that is an orderable part
 *                  number, not a CMSIS device name, and UM Rev0.01 is a lightly
 *                  edited copy of the GestureAI manual (its table of contents
 *                  still lists gesture chapters). M5531 is M55M1 without the
 *                  Ethos-U NPU; every peripheral used here is identical, and
 *                  this project never touches an NPU register, so the M55M1 BSP
 *                  under Library/ is what we build against.
 *   HXT            24 MHz (X1)
 *   MEMS mic       ST MP34DT05-M (U4). A second footprint (U10) is marked NC,
 *                  so the board is mono.
 *                    PA.4 = DMIC0_CLK   (net DMIC0_CLK)
 *                    PA.5 = DMIC0_DAT   (net DMIC0_DAT)
 *                    PA.3 = DMIC0_CLKLP (net DMIC0_CLKLP) - NOT configured here,
 *                           see the R79 note below.
 *                  This is the FIRST PDM pin pair, i.e. DMIC channels 0 and 1 -
 *                  unlike NuMaker-GestureAI-M55M1, which used DMIC1_CLK/DMIC1_DAT
 *                  on PB.2/PB.3 (channels 2 and 3). See DMIC_MIC_CH_MSK in
 *                  Device/include/DMICRecord.h.
 *   R79            0 ohm link between net DMIC0_CLKLP (PA.3) and net DMIC0_CLK
 *                  (PA.4); both microphone footprints take their CLK from
 *                  DMIC0_CLK. Only PA.4 is driven here. Do NOT also call
 *                  SET_DMIC0_CLKLP_PA3() unless R79 is confirmed unfitted -
 *                  with R79 in place that would put two output drivers on one
 *                  net.
 *   Debug console  UART4, PB.11 = TXD / PB.10 = RXD, on 5-pin header J3
 *                  (J3 also carries PB.9 = I2C0_SCL and PB.8 = I2C0_SDA).
 *   SWD            J2: PF.1 ICE_CLK, PF.0 ICE_DAT, nRESET, VDD, VSS.
 *                  There is no UART on J2, so an external Nu-Link's VCOM cannot
 *                  reach this board's console - use a USB-TTL adapter on J3.
 *   HSUSB          Type-C J1, device only (CC1/CC2 each 5.1 K to GND,
 *                  HSUSB_ID not connected). VBUS is divided 20 K/39 K into
 *                  the MCU HSUSB VBUS-detect pin, so HSUSBD_IS_ATTACHED()
 *                  works. The board is also powered from this connector.
 *   LED_Y          PC.4, active LOW (VDD - 330 R R23 - LED - PC.4)
 *   LED_G          PC.5, active LOW (VDD - 330 R R71 - LED - PC.5)
 *   User button    PA.7 (BTN1), active LOW (R72 10 K pull-up to VDD, switch to
 *                  GND). NOTE: PA.7 was the LED on NuMaker-GestureAI-M55M1 and
 *                  PA.4 was the button - the two pins swapped roles. PA.7 must
 *                  never be driven as a push-pull output here: the switch would
 *                  short it straight to GND when pressed.
 *
 * This board does have an audio codec (NAU88L21) and amplifier (NAU8318) with a
 * speaker connector LS1, but this sample does not use them: the only audio sink
 * is the USB Audio Class 1.0 microphone endpoint.
 *
 * @copyright SPDX-License-Identifier: Apache-2.0
 * @copyright Copyright (C) 2023 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/
#include <stdio.h>

#include "NuMicro.h"
#include "BoardInit.h"
/* Last: its printf -> Console_Printf redirect makes every message below appear
   on the USB CDC console as well as on UART4. */
#include "cdc_console.h"

#define DESIGN_NAME "M5531 / NuMaker-VoiceAI-M55M1"

/* Board description handed to the board-independent CDC console module.
 * This is the ONLY place the console learns anything board specific; the
 * console sources themselves are identical between the VoiceAI and GestureAI
 * builds of this sample. */
static const S_CONSOLE_CFG s_sConsoleCfg =
{
    .pszBoardName   = "NuMaker-VoiceAI-M55M1",
    .pszConsolePins = "UART4, PB.11 TXD / PB.10 RXD (header J3), 115200 8N1",
    /* The mic hangs off the DMIC0_CLK/DMIC0_DAT pin pair -> channels 0/1. */
    .u32DmicChBase  = 0U,
    .u32LedCount    = (uint32_t)BOARD_LED_COUNT,
    .pfnLedSet      = BoardLedSet,
    .pfnKeyRead     = BoardKeyPressed,
};

/* The console on this board is UART4 (PB.11 TXD / PB.10 RXD, header J3), not
 * the BSP default UART0 (PB.12/PB.13) and not the UART5 (PB.4/PB.5) of the
 * GestureAI board this sample was ported from. On VoiceAI PB.4/PB.5 are not
 * brought out at all, and they are the alternate-function pins of
 * DMIC0_CLK/DMIC0_DAT.
 *
 * DEBUG_PORT_UART_IDX must be defined project-wide, because system_M55M1.c and
 * retarget.c are compiled separately and both expand it. It is set in
 * VSCode/DMIC_UAC_Codec_Monitor.cproject.yml (define:) and in the Keil project
 * under Options for Target -> C/C++ -> Define. Fail loudly rather than silently
 * printing into the wrong pins. */
#if (DEBUG_PORT_UART_IDX != 4)
    #error "NuMaker-VoiceAI-M55M1 console is UART4 on PB.11/PB.10 (header J3): add DEBUG_PORT_UART_IDX=4 to the target-wide preprocessor defines."
#endif

/* The BSP's SetDebugUartMFP() (system_M55M1.c) only has branches for
 * DEBUG_PORT_UART_IDX 0, 5 and 6 - anything else stops the build with
 * "[Miss] Set UART MFP" from inside a shared library file, with no hint about
 * this project. NVT_DBG_UART_OFF removes that whole block so we can supply our
 * own UART4 versions below. */
#ifndef NVT_DBG_UART_OFF
    #error "NVT_DBG_UART_OFF must also be defined target-wide: the BSP SetDebugUartMFP() has no UART4 branch and would stop the build with '[Miss] Set UART MFP'."
#endif

/* UART4 lives in UARTSEL0/UARTDIV0; clk.h has no CLK_UARTSEL1_UART4SEL_*. */
#if (DEBUG_PORT_UART_GRP_IDX != 0)
    #error "DEBUG_PORT_UART_GRP_IDX must stay 0 for UART4."
#endif

/* NVT_DBG_UART_OFF removes the BSP's __WEAK SetDebugUartMFP/SetDebugUartCLK/
 * InitDebugUart (system_M55M1.c:77-151) *and* their prototypes
 * (system_M55M1.h:167-183), so both declare and define them here. Everything
 * still derives from DEBUG_PORT_UART_IDX=4:
 *   DEBUG_PORT        = UART4
 *   DEBUG_PORT_MODULE = UART4_MODULE
 *   DEBUG_PORT_RST    = SYS_UART4RST
 *   DEBUG_PORT_CLKSEL = CLK_UARTSEL0_UART4SEL_HIRC
 *   DEBUG_PORT_CLKDIV = CLK_UARTDIV0_UART4DIV(1)
 * Do not mark these __WEAK - nothing else provides them now. */
void SetDebugUartMFP(void);
void SetDebugUartCLK(void);
void InitDebugUart(void);

void SetDebugUartMFP(void)
{
    /* Console on header J3: PB.11 = UART4_TXD, PB.10 = UART4_RXD. */
    SET_UART4_RXD_PB10();
    SET_UART4_TXD_PB11();
}

void SetDebugUartCLK(void)
{
    /* Mirrors the BSP version with the UART4 macros. The HXT enable is
       redundant when called from SYS_Init() below (HXT is already up and the
       UART clock source is HIRC), but it is kept so this stays a drop-in
       replacement for the BSP function. */
    CLK_EnableXtalRC(CLK_SRCCTL_HXTEN_Msk);
    CLK_WaitClockReady(CLK_STATUS_HXTSTB_Msk);

    CLK_SetModuleClock(DEBUG_PORT_MODULE, DEBUG_PORT_CLKSEL, DEBUG_PORT_CLKDIV);
    CLK_EnableModuleClock(DEBUG_PORT_MODULE);
    SYS_ResetModule(DEBUG_PORT_RST);
}

void InitDebugUart(void)
{
    UART_Open(DEBUG_PORT, 115200);
}

static void SYS_Init(void)
{
    /*------------------------------------------------------------------*/
    /* Init System Clock                                                */
    /*------------------------------------------------------------------*/

    /* Enable Internal RC 12MHz clock */
    CLK_EnableXtalRC(CLK_SRCCTL_HIRCEN_Msk);

    /* Waiting for Internal RC clock ready */
    CLK_WaitClockReady(CLK_STATUS_HIRCSTB_Msk);

    /* Enable HXT clock (24 MHz crystal X1 on this board) */
    CLK_EnableXtalRC(CLK_SRCCTL_HXTEN_Msk);

    /* Waiting for HXT clock ready */
    CLK_WaitClockReady(CLK_STATUS_HXTSTB_Msk);

    /* Switch SCLK clock source to APLL0 and Enable APLL0 220MHz clock */
    CLK_SetBusClock(CLK_SCLKSEL_SCLKSEL_APLL0, CLK_APLLCTL_APLLSRC_HXT, FREQ_220MHZ);

    /* Update System Core Clock */
    SystemCoreClockUpdate();

    /* Enable GPIO module clock */
    CLK_EnableModuleClock(GPIOA_MODULE);
    CLK_EnableModuleClock(GPIOB_MODULE);
    CLK_EnableModuleClock(GPIOC_MODULE);
    CLK_EnableModuleClock(GPIOD_MODULE);
    CLK_EnableModuleClock(GPIOE_MODULE);
    CLK_EnableModuleClock(GPIOF_MODULE);
    CLK_EnableModuleClock(GPIOG_MODULE);
    CLK_EnableModuleClock(GPIOH_MODULE);
    CLK_EnableModuleClock(GPIOI_MODULE);
    CLK_EnableModuleClock(GPIOJ_MODULE);

    /* Enable FMC0 module clock */
    CLK_EnableModuleClock(FMC0_MODULE);

    /* NOTE: this part (M5531) has no Ethos-U NPU, and this build would not use
             one anyway. There is deliberately no NPU clock enable here. */

    /* Select debug UART module clock source. With DEBUG_PORT_UART_IDX=4 this
       resolves to UART4_MODULE / CLK_UARTSEL0_UART4SEL_HIRC. Our own
       SetDebugUartCLK() above is used, not the BSP one. */
    SetDebugUartCLK();

    /* DMIC_APLL1_FREQ_196608KHZ supports 8000/16000/48000 Hz sample rates with
       64/128/256 down-sample. This is independent of SCLK: changing the core
       clock does not change the PDM bit clock. */
    CLK_EnableAPLL(CLK_APLLCTL_APLLSRC_HIRC, DMIC_APLL1_FREQ_196608KHZ, CLK_APLL1_SELECT);
    /* Select DMIC CLK source from APLL1_DIV2. */
    CLK_SetModuleClock(DMIC0_MODULE, CLK_DMICSEL_DMIC0SEL_APLL1_DIV2, MODULE_NoMsk);
    /* Enable DMIC clock. */
    CLK_EnableModuleClock(DMIC0_MODULE);
    /* DMIC IP reset. */
    SYS_ResetModule(SYS_DMIC0RST);

    /* LPPDMA init. */
    CLK_EnableModuleClock(LPPDMA0_MODULE);
    CLK_EnableModuleClock(LPSRAM0_MODULE);
    SYS_ResetModule(SYS_LPPDMA0RST);

    /* Enable HSOTG module clock */
    CLK_EnableModuleClock(HSOTG0_MODULE);

    /* Select HSOTG PHY Reference clock frequency which is from HXT (24 MHz) */
    HSOTG_SET_PHY_REF_CLK(HSOTG_PHYCTL_FSEL_24_0M);

    /* Set HSUSB role to HSUSBD. The Type-C connector is wired as a UFP
       (5.1 K on both CC lines, ID left open), so device role is the only
       valid role on this board. */
    SET_HSUSBDROLE();

    /* Enable HSUSB PHY */
    SYS_Enable_HSUSB_PHY();

    /* Enable HSUSBD peripheral clock */
    CLK_EnableModuleClock(HSUSBD0_MODULE);

    /*------------------------------------------------------------------*/
    /* Init I/O Multi-function                                          */
    /*------------------------------------------------------------------*/

    /* Set multi-function pins for the debug UART (PB.11 TXD / PB.10 RXD).
       This calls our SetDebugUartMFP() above, not the BSP one. */
    SetDebugUartMFP();

    /* Set multi-function pins for the on-board MP34DT05-M PDM microphone.
       IMPORTANT: this board uses the FIRST PDM pin pair of the single DMIC
       controller (nets DMIC0_CLK/DMIC0_DAT on PA.4/PA.5), which feeds DMIC
       channels 0 and 1 - not PB.2/PB.3 / channels 2 and 3 as on the
       NuMaker-GestureAI-M55M1 this sample was ported from. See DMIC_MIC_CH_MSK
       in Device/include/DMICRecord.h.

       PA.3 (DMIC0_CLKLP) is deliberately left at reset: R79 links it to the
       DMIC0_CLK net, so driving both would be two outputs on one net. */
    SET_DMIC0_CLK_PA4();
    SET_DMIC0_DAT_PA5();

    /* Status LEDs (LED_Y, LED_G) and user button.
       Nothing here may touch PA.4 - it is DMIC0_CLK, set immediately above. */
    SET_GPIO_PC4();
    SET_GPIO_PC5();
    SET_GPIO_PA7();
}

/**
  * @brief Initiate the hardware resources of board
  * @return 0: Success, <0: Fail
  */
int BoardInit(void)
{
    /* Unlock protected registers */
    SYS_UnlockReg();

    SYS_Init();

    /* UART init - enables printf (stdout re-directed at the debug UART) */
    InitDebugUart();

    SYS_LockReg();

    /* Both LEDs are active low: drive high (off) before enabling the output so
       they do not flash during start-up. */
    PC4 = 1;
    PC5 = 1;
    GPIO_SetMode(PC, BIT4 | BIT5, GPIO_MODE_OUTPUT);

    /* User button BTN1 on PA.7 already has a 10 K external pull-up; input mode
       is enough. It MUST stay an input - the switch shorts PA.7 to GND. */
    GPIO_SetMode(PA, BIT7, GPIO_MODE_INPUT);

    /* Bring the USB console up before the first printf so that start-up output
       is captured in its ring buffer and replayed once the host opens the port.
       The endpoints are configured later, by UAC_Init(). */
    CdcConsole_Init(&s_sConsoleCfg);

    printf("BoardInit: complete\n");
    printf("Target board : %s\n", DESIGN_NAME);
    printf("System core clock = %u Hz\n", (unsigned)SystemCoreClock);
    printf("Console      : UART4, PB.11 TXD / PB.10 RXD (header J3), 115200 8N1\n");

    return 0;
}

void BoardLedSet(uint32_t u32Led, uint32_t u32On)
{
    /* VDD -> 330 R -> LED -> PCx, so LOW = lit. */
    uint32_t u32Level = (u32On != 0U) ? 0U : 1U;

    switch (u32Led)
    {
        case BOARD_LED_Y:
            PC4 = u32Level;
            break;

        case BOARD_LED_G:
            PC5 = u32Level;
            break;

        default:
            break;
    }
}

void BoardLedToggle(uint32_t u32Led)
{
    switch (u32Led)
    {
        case BOARD_LED_Y:
            PC4 ^= 1U;
            break;

        case BOARD_LED_G:
            PC5 ^= 1U;
            break;

        default:
            break;
    }
}

uint32_t BoardKeyPressed(void)
{
    /* BTN1 on PA.7: 10 K pull-up to VDD, switch to GND -> LOW when pressed. */
    return (PA7 == 0U) ? 1U : 0U;
}
