This directory must exist before a build.
The Keil AfterMake step runs:
    fromelf --bin ".\Objects\@L.axf" --output ".\release\@L.bin"
and fromelf does NOT create its output directory, so deleting this folder
breaks the post-build step with "cannot open output file".

The produced binary is release/DMIC_UAC_Codec_Monitor.bin - that is the file to
drag onto the board's mass-storage bootloader (see README_zh-TW.md section 4).
