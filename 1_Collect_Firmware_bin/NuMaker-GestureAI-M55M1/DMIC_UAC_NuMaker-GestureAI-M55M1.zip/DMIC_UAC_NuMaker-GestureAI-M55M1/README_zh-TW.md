# NuMaker-GestureAI-M55M1：板載 MEMS DMIC → HSUSB UAC 麥克風

這個版本是把原本給 **NuMaker-X-M55M1D** 用的 `DMIC_UAC_Codec_Monitor`
移植到 **NuMaker-GestureAI-M55M1**。

GestureAI 這片板子**沒有 audio codec、沒有 Phone Jack**（NAU8822 / I2S0 / I2C3 /
PD.1 JK-EN 那一整條路徑在這片板子上根本不存在），所以原本的本地監聽功能整組移除。
唯一的音訊輸出路徑就是 **HSUSB Type-C**：板子在 PC 上會列舉成一個
USB Audio Class 1.0 錄音裝置，可以直接當成麥克風輸入來源。

```text
MP34DT05-M (U4，板背面)
PB.2 = DMIC1_CLK
PB.3 = DMIC1_DAT
        │
        ▼
DMIC0 controller，channel 2
16 kHz / mono / signed 16-bit PCM
        │
        ▼
LPPDMA0 channel 2（每 1 ms 一個 block = 32 bytes）
        │
        ├────────► HSUSBD UAC 1.0 ISO IN endpoint ──► PC 麥克風
        │
        └────────► application ring buffer ──► UART5 音量表（診斷用）
```

音量表不依賴 PC：只要板子有電，UART5 就會每秒印一行，可以在完全不接 PC
音訊軟體的情況下確認麥克風有沒有收到聲音。

---

## 1. 板上硬體對照

依據 `UM_NuMaker-GestureAI-M55M1_EN_Rev1.00` 的原理圖。

| 功能 | M55M1 腳位 / 模組 | 備註 |
|---|---|---|
| MCU | **M55M1R2LJAE，LQFP64** | 原本是 M55M1H2LJAE (LQFP176) |
| HXT | 24 MHz (X1) | 與 BSP 的 `__HXT` 相同，不用改 |
| DMIC Clock | **PB.2 / DMIC1_CLK** | 原本 PB.4 / DMIC0_CLK |
| DMIC Data | **PB.3 / DMIC1_DAT** | 原本 PB.5 / DMIC0_DAT |
| MEMS 麥克風 | ST **MP34DT05-M** (U4) | L/R 腳被 10K 下拉到 GND (R21 NC、R22 10K) |
| DMIC 通道 | **channel 2** | 見下面第 7 節 |
| Debug Console | **UART5，PB.5 TXD / PB.4 RXD** | 拉到 2-pin 排針 **J3**，115200 8N1 |
| SWD / ICE | J2：PF.1 ICE_CLK、PF.0 ICE_DAT、nRESET、VDD、GND | |
| USB | HSUSB Type-C **J1** | CC1/CC2 各 5.1K 下拉 → 純 device (UFP)；同時是板子電源 |
| USB VBUS 偵測 | HSUSB VBUS 腳（LQFP64 pin 43） | 5V 經 20K/39K 分壓 ≈ 3.3V，`HSUSBD_IS_ATTACHED()` 可用 |
| 狀態 LED | **PA.7 (LED_Y，黃色)** | 低電位亮（VDD → 330Ω → LED → PA.7） |
| User Key | **PA.4 (BTN2)** | 10K 上拉，按下為低；本韌體只讀不用 |
| DMIC RX DMA | LPPDMA0 channel 2 | 未變 |

> **注意**：`DMIC1_CLK / DMIC1_DAT` 不是第二顆 DMIC 控制器。M55M1 只有**一顆**
> DMIC 控制器（暫存器基底 `DMIC0`），但有**兩組 PDM 腳位**：
> `DMIC0_CLK/DAT` 餵 channel 0、1；`DMIC1_CLK/DAT` 餵 channel 2、3。
> GestureAI 用的是第二組，所以程式要開的是 **channel 2**，不是 channel 0。
> 這是這次移植最容易踩到的一點。

---

## 2. 相對於 NuMaker-X-M55M1D 版本改了什麼

### 移除（Codec / Phone Jack 整組）

| 項目 | 動作 |
|---|---|
| `Codec/CodecMonitor.c`、`Codec/include/CodecMonitor.h` | 刪除整個 `Codec/` 目錄 |
| NAU8822 (I2C3, PG.0/PG.1)、I2S0 (PI.6–PI.10)、PDMA0 ch2、PD.1 JK-EN | 全部移除 |
| Keil 專案裡的 `i2c.c` / `i2s.c` / `pdma.c` | 從 Driver group 移除（只有 codec 需要）<br>DMICRecord.c 仍用到的 `PDMA_WIDTH_16` 等是 **標頭檔常數**，不需要 `pdma.c` |
| Keil 專案的 `Codec` group、`..\Codec\include` include path | 移除 |
| `main.c` 裡所有 `CodecMonitor_*` 呼叫、三緩衝、衰減設定 | 移除 |
| `usbd_audio.h` 的 `AdjustCodecPll()`、`RESAMPLE_STATE_T`、`timer_init()`、`INPUT_IS_LIN` | 移除（宣告了但從來沒有定義、也沒人呼叫的 codec 殘留） |
| `PDMA0_IRQHandler()` | 隨 `CodecMonitor.c` 一起消失；`startup_M55M1.c` 有 weak default handler，不會有懸空參考 |
| 舊的 `Keil/Objects`、`Keil/Listings` | 刪除，避免把舊板子的 AXF/BIN 誤認成新版（uVision 會自己重建）<br>`Keil/release/` 裡舊的 .bin 也刪了，但**目錄本身保留**：post-build 的 `fromelf --output ".\release\@L.bin"` 不會自己建目錄 |

### 修改（板子相關）

| 檔案 | 修改 |
|---|---|
| `BoardInit.c` | DMIC MFP 改成 `SET_DMIC1_CLK_PB2()` / `SET_DMIC1_DAT_PB3()`；加上 LED (PA.7) 與 Key (PA.4) 初始化；加上 `DEBUG_PORT_UART_IDX != 5` 的 `#error` 保護 |
| `BoardInit.h` | 新增 `BoardLedSet()` / `BoardLedToggle()` / `BoardKeyPressed()` |
| `Device/include/DMICRecord.h` | 新增 `DMIC_MIC_CH_MSK`（= `DMIC_CTL_CHEN2_Msk`）與完整的接線說明 / fallback 說明；新增 `DMIC_OVERSAMPLE_RATIO`（見第 8 節） |
| `Device/DMICRecord/DMICRecord.c` | 原本「channel 數 → CHEN0..CHEN3」的對應改成直接使用 `DMIC_MIC_CH_MSK`；開機時多印一行實際的 PDM 時脈 |
| `UAC/usbd_audio.c` | `AudioStartRecord()` 原本硬寫 `DMIC_CTL_CHEN0_Msk`，改成 `DMIC_MIC_CH_MSK`（**這行不改的話，PC 一開始錄音就會把通道切回 channel 0，變成沒有聲音**） |
| `UAC/usbd_audio.h` | PID `0x1288` → **`0x1289`**，避免 Windows 沿用舊板子快取的裝置描述 |
| `UAC/descriptors.c` | Product string `"M55M1 DMIC Mic"` → **`"GestureAI DMIC Mic"`**（bLength 30 → 38） |
| `main.c` | 重寫：移除 codec，保留音量表，加上 LED 狀態指示與「收不到 PDM 資料」的提示 |

### Keil 專案設定

| 項目 | 舊 | 新 |
|---|---|---|
| `<Device>` | `M55M1H2LJAE` | **`M55M1R2LJAE`** |
| `<RegisterFile>` / `<SFDFile>` / `<FlashDriverDll>` 的 `$$Device:` | `M55M1H2LJAE` | `M55M1R2LJAE` |
| Flash algorithm | `M55M1_NS.FLM`（**pack 裡根本沒有這個檔**） | `M55M1_NS_2M.FLM`（順手修掉的既有錯誤） |
| `<Define>` | `NVT_VECTOR_ON_FLASH, ARM_MATH_DSP` | `NVT_VECTOR_ON_FLASH, ARM_MATH_DSP, **DEBUG_PORT_UART_IDX=5**` |

`DEBUG_PORT_UART_IDX=5` 必須是 **target 層級**的 define，因為 `system_M55M1.c`
（設定 MFP / clock）和 `retarget.c`（`printf` 實際寫哪顆 UART）是兩個不同的
translation unit，兩邊都要看到。只改其中一邊，會變成腳位設在 UART5 但
`printf` 還是往 UART0 送。

`<Cpu>` 的 IRAM/IROM 不用改：CMSIS pack 把記憶體定義放在 `<subFamily>` 層級，
`M55M1R2LJAE` 和 `M55M1H2LJAE` 共用同一份（2 MB Flash / 0x150000 SRAM），
兩者差別只有封裝與腳位數量。

---

## 3. 編譯

用 Keil MDK（Arm Compiler 6）開啟：

```text
Keil\DMIC_UAC_Codec_Monitor.uvprojx
```

需要已安裝 CMSIS pack `Nuvoton.NuMicroM55_DFP` **3.1.4-rc.3**（`<PackID>` 指定的版本，
裡面有宣告 `M55M1R2LJAE`）。然後 `Rebuild`。

> 專案資料夾和 target 名稱仍叫 `DMIC_UAC_Codec_Monitor` 是歷史包袱。要改名的話
> 需要一併改 `<TargetName>`、`<OutputName>`、post-build 的 `fromelf` 路徑和
> `.uvoptx`，跟功能無關，所以這次沒動。

---

## 4. 燒錄

**方法 A（建議）— Nu-Link + SWD**

接 J2（1=VDD、2=ICE_DAT、3=ICE_CLK、4=nRESET、5=GND），在 Keil 按 `Download`。

**方法 B — 板上原廠的 drag-and-drop bootloader**

依 User Manual 4.3 節：接上 Type-C → 按住 User button → 按一下 Reset → 放開
User button → PC 出現名為 `M55M1` 的 USB 大量儲存裝置 → 把 `.bin` 複製進去 → 再按 Reset。

專案的 post-build 已經會產生 `.\release\DMIC_UAC_Codec_Monitor.bin`。
本韌體 link 在 APROM base `0x00100000`（無 offset），與 M55M1 bootloader 的慣例一致。

> 我沒有實板可以驗證 GestureAI 出廠 bootloader 的行為，**方法 B 未經實測**。
> 如果 drag-and-drop 後跑不起來，請用方法 A。

---

## 5. 在 PC 上使用

1. 用 USB Type-C 線接 J1 到 PC（這條線同時供電）。
2. Windows 會出現錄音裝置 **`GestureAI DMIC Mic`**（Nuvoton, VID 0x0416 / PID 0x1289）。
   免驅動，用 Windows 內建的 USB Audio class driver。
3. 到「設定 → 系統 → 音效 → 輸入」選擇它，或在 Audacity / OBS / Zoom 裡選成輸入來源。
4. 格式固定 **16000 Hz、單聲道、16-bit**。

裝置以 **Full Speed** 列舉（descriptor 的 bcdUSB = 0x0110）。16 kHz mono 每個
1 ms frame 只有 32 bytes，遠低於 FS isochronous 的頻寬上限，所以沒有換成
High Speed 的必要，也刻意不動它（改 HS 需要同時動 `OPER`、`bcdUSB`、`bInterval`
和 other-speed descriptor，四個地方要一起對，風險大於效益）。

### LED 狀態（PA.7 黃燈）

| LED | 意義 |
|---|---|
| 恆亮 | PC 已經開啟錄音端點，正在串流 |
| 快閃（約 2 Hz） | USB 已插上，但 host 還沒開始錄音 |
| 慢閃（約 1 Hz） | 沒有偵測到 VBUS（例如只接了 Nu-Link 供電） |

---

## 6. UART5 上會看到什麼

接 J3（PB.5 = 板子的 TXD，接 USB-TTL 的 RX；PB.4 = 板子的 RXD），115200 8N1：

```text
BoardInit: complete
Target board : M55M1R2LJAE / NuMaker-GestureAI-M55M1
System core clock = 220000000 Hz
Console      : UART5, PB.5 TXD / PB.4 RXD (header J3), 115200 8N1

+------------------------------------------------------------+
| NuMaker-GestureAI-M55M1  DMIC -> USB microphone (UAC 1.0)   |
+------------------------------------------------------------+
Microphone   : MP34DT05-M, PB.2 DMIC1_CLK / PB.3 DMIC1_DAT
DMIC channel : 2
Format       : 16000 Hz, mono, signed 16-bit PCM
USB          : HSUSB Type-C (J1), UAC 1.0 recording device
Audio out    : USB only - this board has no codec / phone jack

DMIC SampleRate is 16000
DMIC PDM clock on PB.2 = 4096000 Hz (Fs x 256)
DMIC DSP gain is +24 dB
Start Record ...

Plug the Type-C port into a PC and pick "GestureAI DMIC Mic"
as the recording device. The level meter below runs regardless.
```

之後每秒一行：

```text
[##########----------] peak=16384 ( 50%)  usb=streaming
```

---

## 7. 如果收不到聲音：DMIC channel 2 / 3

這是這次移植**唯一沒辦法在沒有實板的情況下 100% 證明**的地方，所以韌體在
連續 10 秒 peak 都是 0 的時候會自己印出提示：

```text
*** No PDM data on DMIC channel 2 after 10 s. ***
*** Try the fallback documented in Device/include/DMICRecord.h ***
```

**判斷依據（為什麼預設選 channel 2）：**

- MP34DT05-M datasheet Table 7：`L/R = GND` 時，DOUT 在 **CLK 為 low 的期間有效**，
  CLK 為 high 時是高阻抗。
- GestureAI 原理圖：R21（拉到 VDD）**NC**、R22 = 10K 到 GND → **L/R = LOW**。
- NuMaker-X-M55M1D 原理圖（UM Rev1.01, Figure 7-15）：**完全相同的電路**，
  R122 NC、R123 = 10K 到 GND → 也是 L/R = LOW。
- 而 X-M55M1D 上能正常工作的韌體（含 Nuvoton 官方 `DMIC_WAVRecorder`）用的是
  **channel 0** 搭配 `LCHEDGE01` 的重置預設值。
- 兩片板子接線相同、只差在接到第一組還是第二組 PDM 腳位，所以 channel 0 的對應
  就是 **channel 2**，`LCHEDGE23` 同樣保持預設值。

**Fallback（真的沒聲音時）：** 編輯 `Device/include/DMICRecord.h`：

```c
/* 原本 */
#define DMIC_MIC_CH_MSK         (DMIC_CTL_CHEN2_Msk)

/* 改成 */
#define DMIC_MIC_CH_MSK         (DMIC_CTL_CHEN3_Msk)
```

如果還是不行，在 `DMICRecord_Init()` 裡（`DMIC_Open()` 之後）加一行：

```c
DMIC_SET_LATCHEDGE_CH23(DMIC0, DMIC_LATCHDATA_CH23R);
```

`DMIC_MIC_CH_MSK` 是唯一的來源，`DMICRecord.c` 和 `usbd_audio.c` 都吃它，
改一個地方就好。

---

## 8. 如果聲音很雜、破音或整個怪怪的：PDM 時脈

韌體預設的 oversampling ratio 是 **256**，所以 PB.2 上的 PDM bit clock 是：

```text
16000 Hz x 256 = 4.096 MHz
```

但 **MP34DT05-M datasheet (Rev 3, Table 5) 規定 normal mode 的 fCLK 是
1.2 MHz ~ 3.25 MHz**，4.096 MHz 已經超出規格上限約 26%。

這是**原本就有的設定**（NuMaker-X-M55M1D 版本、以及 Nuvoton 官方
`SampleCode/StdDriver/DMIC_WAVRecorder` 用的是同一顆麥克風、同樣的 256），
所以這次移植沒有擅自改掉它。但如果實際上聲音有問題，**這是第一個該試的地方**。

編輯 `Device/include/DMICRecord.h`：

```c
/* 原本 */
#define DMIC_OVERSAMPLE_RATIO   (256U)      /* -> 4.096 MHz，超出 datasheet 上限 */

/* 改成 */
#define DMIC_OVERSAMPLE_RATIO   (128U)      /* -> 2.048 MHz，在規格內 */
```

128 除得盡 APLL1_DIV2（98.304 MHz ÷ 2.048 MHz = 48），不會有分頻誤差。

**不要用 64**：16000 × 64 = 1.024 MHz，低於 datasheet 的 1.2 MHz 下限，
麥克風可能直接進入 power-down 模式。

開機時 UART 會把實際算出來的 PDM 時脈印出來，可以直接對照。

---

## 9. 調整增益

編輯 `UAC/usbd_audio.h`：

```c
#define DMIC_DSP_GAIN_DB    24      /* 可用範圍 0..36 */
```

- UART 出現 `*** CLIP xN ***` → 調低（先試 18）
- peak 一直很小 → 調高（試 30；不建議一開始就用 36，近距離講話很容易削波）

增益是套在全部 4 個 DMIC 通道上的（`DMIC_MIC_GAIN_CH_MSK`），所以上面第 7 節的
fallback 換通道之後增益設定仍然有效。

---

## 10. 這次沒有動、但你可能會想知道的

| 項目 | 狀態 |
|---|---|
| `Keil/M55M1.scf` | **沒動**。裡面有一段 `HYPERRAM` 執行區（SPIM0 `0x82000000`），那是 X-M55M1D 的東西，GestureAI 沒有。但目前它是空的（map 顯示 size 0），留著不影響編譯與執行。 |
| `mpu_config_M55M1.h` | **沒動**。它會被 `M55M1.h` 用 `__has_include` 自動帶進每個 translation unit。`MPU_INIT_REGION0` 指向 EBI (`0x60000000`)，GestureAI 沒有 EBI，但把一段沒有元件的位址設成 Device-nGnRnE + XN 是無害的。**不要直接刪掉這個檔**，刪掉會讓整個專案改用 BSP 的 template 版本。 |
| `Keil/Nu_Link_Driver.ini` | **沒動**。裡面寫死了一組 Nu-Link 序號和一個 X-M55M1D 遺留的 SPIM 演算法（`SPIM=0`，未使用）。刪掉也沒關係，Nu-Link 會重新產生。 |
| ISO IN endpoint 大小不一致 | descriptor 宣告 `wMaxPacketSize = 64`、硬體 max payload 設 40、實際每 frame 只送 32 bytes。這是原廠範例就有的，不影響運作，沒有一起改。 |
| `bcdUSB 0x0110` vs Qualifier descriptor `0x0200` | 同上，原廠範例既有的不一致，列舉正常就不動它。 |
| VS Code 建置 | 這個範例沒有 `csolution.yml`，只有 Keil 專案。 |

---

## 11. 驗證狀態（請務必看這段）

**已經用證據確認的：**

- GestureAI 原理圖判讀：MEMS MIC 接 PB.2/PB.3，L/R 下拉到 GND；HSUSB 為純 device；
  UART5 在 PB.4/PB.5 出到 J3；LED PA.7 低態亮；HXT 24 MHz。
- BSP 確實提供 `SET_DMIC1_CLK_PB2()` / `SET_DMIC1_DAT_PB3()`，
  且 M55M1 只有一顆 DMIC 控制器（沒有 `DMIC1_BASE`/`DMIC1_MODULE`）。
- BSP 的 `SetDebugUartMFP()` 有 `DEBUG_PORT_UART_IDX == 5` 的分支，
  且 `UART5` / `UART5_MODULE` / `SYS_UART5RST` / `CLK_UARTSEL0_UART5SEL_HIRC` /
  `CLK_UARTDIV0_UART5DIV` 全部存在（group index 必須是 0，用 1 會編不過）。
- 已安裝的 CMSIS pack 3.1.4-rc.3 有宣告 `M55M1R2LJAE`，且與 `M55M1H2LJAE`
  共用同一份 flash/SRAM 定義。
- pack 的 Flash 目錄確實只有 `M55M1_NS_2M.FLM`，沒有 `M55M1_NS.FLM`。
- USB descriptor 長度自洽：config `wTotalLength = 0x6A`（實際 106 bytes）、
  AudioControl header `wTotalLength = 0x26`（實際 38 bytes）、
  product string `bLength = 38`（實際 38 bytes）。
- 移除 `i2c.c`/`i2s.c`/`pdma.c` 後沒有殘留的 link 相依：程式只用到 `PDMA_*` 的
  標頭檔常數，沒有呼叫 `pdma.c` 裡的任何函式。

**沒有驗證的（這台機器上沒有 Keil、沒有 Nu-Link、也沒有 GestureAI 板子）：**

- **沒有實際編譯過**，所以沒有附上新的 AXF / BIN。請自己在 Keil 按 Rebuild；
  如果有 error，請從**第一個** error 開始貼完整 build log。
- 沒有實際列舉過 USB、沒有實際錄過音。
- DMIC channel 2 vs 3（見第 7 節）——推理鏈很完整，但終究要上板才算數。
- 原廠 drag-and-drop bootloader 與本韌體共存的行為（見第 4 節方法 B）。
