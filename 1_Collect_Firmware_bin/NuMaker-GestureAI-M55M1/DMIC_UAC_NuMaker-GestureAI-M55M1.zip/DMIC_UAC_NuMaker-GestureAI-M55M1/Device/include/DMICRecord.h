/**************************************************************************//**
 * @file     DMICRecord.h
 * @version  V2.00
 * @brief    DMIC audio record function (NuMaker-GestureAI-M55M1)
 *
 * @copyright (C) 2023 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/
#ifndef __DMIC_RECORD_H__
#define __DMIC_RECORD_H__

#include <inttypes.h>

#include "NuMicro.h"

#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------------------------------------------------------*/
/* Board microphone wiring                                                   */
/*---------------------------------------------------------------------------*/
/* The M55M1 has ONE DMIC controller with four channels fed by TWO PDM pin
 * pairs:
 *
 *   DMIC0_CLK / DMIC0_DAT  ->  channels 0 (even) and 1 (odd)
 *   DMIC1_CLK / DMIC1_DAT  ->  channels 2 (even) and 3 (odd)
 *
 * Within a pair the two channels are separated by the clock edge on which the
 * data is latched, which is how a stereo pair of PDM mics sharing one data
 * line is de-interleaved.
 *
 * NuMaker-GestureAI-M55M1 has a single MP34DT05-M (U4) on the SECOND pair:
 * PB.2 = DMIC1_CLK, PB.3 = DMIC1_DAT. Its L/R pin is strapped LOW (R21 to VDD
 * is NC, R22 is a 10 K to GND), so per MP34DT05 datasheet Table 7 its data is
 * valid while CLK is low - the same strapping the NuMaker-X-M55M1D uses on its
 * DMIC0 pair, where the working Nuvoton samples capture it on channel 0 with
 * LCHEDGE01 left at its reset value. The direct equivalent here is therefore
 * channel 2 with LCHEDGE23 left at its reset value.
 *
 * FALLBACK: if capture is silent or is pure noise, the mic is landing on the
 * other half of the pair. Change the two lines below to CHEN3/GAINCTL channel 3
 * (and, if needed, add DMIC_SET_LATCHEDGE_CH23(DMIC0, DMIC_LATCHDATA_CH23R)
 * in DMICRecord_Init()). Nothing else in the project needs to change.
 */
#define DMIC_MIC_CH_MSK         (DMIC_CTL_CHEN2_Msk)

/* Gain is applied to every channel so the fallback above keeps working. */
#define DMIC_MIC_GAIN_CH_MSK    (DMIC_CTL_CHEN0_Msk | DMIC_CTL_CHEN1_Msk | \
                                 DMIC_CTL_CHEN2_Msk | DMIC_CTL_CHEN3_Msk)

/* Oversampling ratio. This directly sets the PDM bit clock on PB.2:
 *
 *      f_DMIC_CLK = sample_rate * DMIC_OVERSAMPLE_RATIO
 *
 * At 16 kHz:  256 -> 4.096 MHz    128 -> 2.048 MHz
 *             100 -> 1.600 MHz     64 -> 1.024 MHz
 *
 * HEADS-UP: the MP34DT05-M datasheet (Rev 3, Table 5) specifies f_CLK for
 * normal mode as 1.2 MHz min / 3.25 MHz max, so the default 256 runs the mic
 * about 26 % above its published maximum. 256 is kept as the default anyway
 * because it is what Nuvoton's own DMIC_WAVRecorder sample and the
 * NuMaker-X-M55M1D build of this project use with the very same microphone.
 * If capture is noisy, distorted or dead, 128 (2.048 MHz) is the first thing
 * to try - it is comfortably inside the datasheet window and still divides
 * APLL1_DIV2 (98.304 MHz) exactly. Do NOT use 64: 1.024 MHz is below the
 * 1.2 MHz minimum and the mic may drop into power-down mode.
 */
#define DMIC_OVERSAMPLE_RATIO   (256U)

#if   (DMIC_OVERSAMPLE_RATIO == 256U)
    #define DMIC_OVERSAMPLE_SEL DMIC_DOWNSAMPLE_256
#elif (DMIC_OVERSAMPLE_RATIO == 128U)
    #define DMIC_OVERSAMPLE_SEL DMIC_DOWNSAMPLE_128
#elif (DMIC_OVERSAMPLE_RATIO == 100U)
    #define DMIC_OVERSAMPLE_SEL DMIC_DOWNSAMPLE_100
#elif (DMIC_OVERSAMPLE_RATIO == 64U)
    #define DMIC_OVERSAMPLE_SEL DMIC_DOWNSAMPLE_64
#else
    #error "DMIC_OVERSAMPLE_RATIO must be 64, 100, 128 or 256"
#endif

/*---------------------------------------------------------------------------*/

// Init DMIC record resource
int32_t DMICRecord_Init(
    uint32_t u32SampleRate,
    uint32_t u32Channels,
    uint32_t u32BlockSamples,
    uint32_t u32BlockCounts
);

// DMIC start record
int32_t DMICRecord_StartRec(void);

// DMIC stop record
int32_t DMICRecord_StopRec(void);

// Get available audio sample number
int32_t DMICRecord_AvailSamples(void);

// Read audio sample data
int32_t DMICRecord_ReadSamples(int16_t *pi16SampleData, uint32_t u32Samples);

// Update audio sample data index
int32_t DMICRecord_UpdateReadSampleIndex(uint32_t u32Samples);

// Un-init DMIC record
void DMICRecord_UnInit(void);

#ifdef __cplusplus
}
#endif

#endif
