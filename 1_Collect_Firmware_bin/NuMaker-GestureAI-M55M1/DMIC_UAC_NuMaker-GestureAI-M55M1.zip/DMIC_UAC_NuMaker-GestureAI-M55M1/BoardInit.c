/**************************************************************************//**
 * @file     BoardInit.c
 * @version  V2.00
 * @brief    Board bring-up for NuMaker-GestureAI-M55M1.
 *
 * Board reference: UM_NuMaker-GestureAI-M55M1_EN_Rev1.00, sheets
 * "M55M1R2LJAE", "High-speed USB", "MEMS Digital MIC", "LED & Buttons".
 *
 *   MCU            M55M1R2LJAE, LQFP64
 *   HXT            24 MHz (X1)
 *   MEMS mic       ST MP34DT05-M (U4), PDM
 *                    PB.2 = DMIC1_CLK   (net DMIC1_CLK)
 *                    PB.3 = DMIC1_DAT   (net DMIC1_DAT)
 *                    L/R strapped LOW (R21 to VDD is NC, R22 10 K to GND)
 *   Debug console  UART5, PB.5 = TXD / PB.4 = RXD, on 2-pin header J3
 *   SWD            J2: PF.1 ICE_CLK, PF.0 ICE_DAT, nRESET
 *   HSUSB          Type-C J1, device only (CC1/CC2 each 5.1 K to GND,
 *                  HSUSB_ID not connected). VBUS is divided 20 K/39 K into
 *                  the MCU HSUSB VBUS-detect pin, so HSUSBD_IS_ATTACHED()
 *                  works. The board is also powered from this connector.
 *   LED_Y          PA.7, active LOW (VDD - 330 R - LED - PA.7)
 *   User button    PA.4, active LOW (10 K pull-up to VDD, switch to GND)
 *
 * There is NO audio codec and NO phone jack on this board; the only audio
 * sink is the USB Audio Class 1.0 microphone endpoint.
 *
 * @copyright SPDX-License-Identifier: Apache-2.0
 * @copyright Copyright (C) 2023 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/
#include <stdio.h>

#include "NuMicro.h"
#include "BoardInit.h"

/* Last: redirects printf() in this file to both UART5 and the USB CDC console. */
#include "cdc_console.h"

#define DESIGN_NAME "M55M1R2LJAE / NuMaker-GestureAI-M55M1"

/* Everything the board-independent console module needs to know about this
   board. Identical in shape to the NuMaker-VoiceAI-M55M1 build - only the
   values differ, which is the whole point of keeping cdc_console.c shared. */
static const S_CONSOLE_CFG s_sConsoleCfg =
{
    .pszBoardName   = "NuMaker-GestureAI-M55M1",
    .pszConsolePins = "UART5, PB.5 TXD / PB.4 RXD (header J3), 115200 8N1",
    /* The mic hangs off the DMIC1_CLK/DMIC1_DAT pin pair -> channels 2/3. */
    .u32DmicChBase  = 2U,
    .u32LedCount    = (uint32_t)BOARD_LED_COUNT,
    .pfnLedSet      = BoardLedSet,
    .pfnKeyRead     = BoardKeyPressed,
};

/* The console on this board is UART5 (PB.4/PB.5), not the BSP default UART0
 * (PB.12/PB.13) - PB.12/PB.13 carry CCAP_SCLK/CCAP_PIXCLK here.
 *
 * DEBUG_PORT_UART_IDX must be defined project-wide, because system_M55M1.c and
 * retarget.c are compiled separately and both expand it. It is set in the Keil
 * project under Options for Target -> C/C++ -> Define. Fail loudly rather than
 * silently printing into the camera clock pins. */
#if (DEBUG_PORT_UART_IDX != 5)
    #error "NuMaker-GestureAI-M55M1 console is UART5 on PB.4/PB.5 (header J3): add DEBUG_PORT_UART_IDX=5 to the target-wide preprocessor defines."
#endif

static void SYS_Init(void)
{
    /*------------------------------------------------------------------*/
    /* Init System Clock                                                */
    /*------------------------------------------------------------------*/

    /* Enable Internal RC 12MHz clock */
    CLK_EnableXtalRC(CLK_SRCCTL_HIRCEN_Msk);

    /* Waiting for Internal RC clock ready */
    CLK_WaitClockReady(CLK_STATUS_HIRCSTB_Msk);

    /* Enable HXT clock (24 MHz crystal X1 on this board) */
    CLK_EnableXtalRC(CLK_SRCCTL_HXTEN_Msk);

    /* Waiting for HXT clock ready */
    CLK_WaitClockReady(CLK_STATUS_HXTSTB_Msk);

    /* Switch SCLK clock source to APLL0 and Enable APLL0 220MHz clock */
    CLK_SetBusClock(CLK_SCLKSEL_SCLKSEL_APLL0, CLK_APLLCTL_APLLSRC_HXT, FREQ_220MHZ);

    /* Update System Core Clock */
    SystemCoreClockUpdate();

    /* Enable GPIO module clock */
    CLK_EnableModuleClock(GPIOA_MODULE);
    CLK_EnableModuleClock(GPIOB_MODULE);
    CLK_EnableModuleClock(GPIOC_MODULE);
    CLK_EnableModuleClock(GPIOD_MODULE);
    CLK_EnableModuleClock(GPIOE_MODULE);
    CLK_EnableModuleClock(GPIOF_MODULE);
    CLK_EnableModuleClock(GPIOG_MODULE);
    CLK_EnableModuleClock(GPIOH_MODULE);
    CLK_EnableModuleClock(GPIOI_MODULE);
    CLK_EnableModuleClock(GPIOJ_MODULE);

    /* Enable FMC0 module clock */
    CLK_EnableModuleClock(FMC0_MODULE);

    /* NOTE: NPU0_MODULE clock is intentionally NOT enabled - this build has no
             Ethos-U usage. Enable it when a model is added to this project. */

    /* Select debug UART module clock source. With DEBUG_PORT_UART_IDX=5 this
       resolves to UART5_MODULE / CLK_UARTSEL0_UART5SEL_HIRC. */
    SetDebugUartCLK();

    /* DMIC_APLL1_FREQ_196608KHZ supports 8000/16000/48000 Hz sample rates with
       64/128/256 down-sample. */
    CLK_EnableAPLL(CLK_APLLCTL_APLLSRC_HIRC, DMIC_APLL1_FREQ_196608KHZ, CLK_APLL1_SELECT);
    /* Select DMIC CLK source from APLL1_DIV2. */
    CLK_SetModuleClock(DMIC0_MODULE, CLK_DMICSEL_DMIC0SEL_APLL1_DIV2, MODULE_NoMsk);
    /* Enable DMIC clock. */
    CLK_EnableModuleClock(DMIC0_MODULE);
    /* DMIC IP reset. */
    SYS_ResetModule(SYS_DMIC0RST);

    /* LPPDMA init. */
    CLK_EnableModuleClock(LPPDMA0_MODULE);
    CLK_EnableModuleClock(LPSRAM0_MODULE);
    SYS_ResetModule(SYS_LPPDMA0RST);

    /* Enable HSOTG module clock */
    CLK_EnableModuleClock(HSOTG0_MODULE);

    /* Select HSOTG PHY Reference clock frequency which is from HXT (24 MHz) */
    HSOTG_SET_PHY_REF_CLK(HSOTG_PHYCTL_FSEL_24_0M);

    /* Set HSUSB role to HSUSBD. The Type-C connector is wired as a UFP
       (5.1 K on both CC lines, ID left open), so device role is the only
       valid role on this board. */
    SET_HSUSBDROLE();

    /* Enable HSUSB PHY */
    SYS_Enable_HSUSB_PHY();

    /* Enable HSUSBD peripheral clock */
    CLK_EnableModuleClock(HSUSBD0_MODULE);

    /*------------------------------------------------------------------*/
    /* Init I/O Multi-function                                          */
    /*------------------------------------------------------------------*/

    /* Set multi-function pins for the debug UART.
       DEBUG_PORT_UART_IDX=5 -> SET_UART5_RXD_PB4() / SET_UART5_TXD_PB5(). */
    SetDebugUartMFP();

    /* Set multi-function pins for the on-board MP34DT05-M PDM microphone.
       IMPORTANT: this board uses the SECOND PDM pin pair of the single DMIC
       controller (nets DMIC1_CLK/DMIC1_DAT on PB.2/PB.3), which feeds DMIC
       channels 2 and 3 - not PB.4/PB.5 / channels 0 and 1 as on the
       NuMaker-X-M55M1D. See DMIC_MIC_CH_MSK in DMICRecord.h. */
    SET_DMIC1_CLK_PB2();
    SET_DMIC1_DAT_PB3();

    /* Status LED (LED_Y) and user button. */
    SET_GPIO_PA7();
    SET_GPIO_PA4();
}

/**
  * @brief Initiate the hardware resources of board
  * @return 0: Success, <0: Fail
  */
int BoardInit(void)
{
    /* Unlock protected registers */
    SYS_UnlockReg();

    SYS_Init();

    /* UART init - enables printf (stdout re-directed at the debug UART) */
    InitDebugUart();

    SYS_LockReg();

    /* LED_Y is active low: drive high (off) before enabling the output so the
       LED does not flash during start-up. */
    PA7 = 1;
    GPIO_SetMode(PA, BIT7, GPIO_MODE_OUTPUT);

    /* User button already has a 10 K external pull-up; input mode is enough. */
    GPIO_SetMode(PA, BIT4, GPIO_MODE_INPUT);

    /* Bring the USB console up before the first printf so that start-up output
       is captured in its ring buffer and replayed once the host opens the port.
       The endpoints are configured later, by UAC_Init(). */
    CdcConsole_Init(&s_sConsoleCfg);

    printf("BoardInit: complete\n");
    printf("Target board : %s\n", DESIGN_NAME);
    printf("System core clock = %u Hz\n", (unsigned)SystemCoreClock);
    printf("Console      : UART5, PB.5 TXD / PB.4 RXD (header J3), 115200 8N1\n");

    return 0;
}

void BoardLedSet(uint32_t u32Led, uint32_t u32On)
{
    /* This board has one user LED, but the signature carries an index so that
       BoardInit.h and the shared cdc_console.c stay identical to the
       NuMaker-VoiceAI-M55M1 build, which has two. */
    if (u32Led != (uint32_t)BOARD_LED_Y)
        return;

    /* LED_Y: VDD -> 330 R -> LED -> PA.7, so LOW = lit. */
    PA7 = (u32On != 0U) ? 0U : 1U;
}

void BoardLedToggle(uint32_t u32Led)
{
    if (u32Led != (uint32_t)BOARD_LED_Y)
        return;

    PA7 ^= 1U;
}

uint32_t BoardKeyPressed(void)
{
    /* BTN2 on PA.4: 10 K pull-up to VDD, switch to GND -> LOW when pressed. */
    return (PA4 == 0U) ? 1U : 0U;
}
