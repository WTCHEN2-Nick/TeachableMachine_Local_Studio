/**************************************************************************//**
 * @file     descriptors.c
 * @version  V3.00
 * @brief    HSUSBD descriptor.
 *
 * @copyright SPDX-License-Identifier: Apache-2.0
 * @copyright Copyright (C) 2021 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/
/*!<Includes */
#include "NuMicro.h"
#include "usbd_audio.h"

/*----------------------------------------------------------------------------*/
/*!<USB Device Descriptor */
uint8_t gu8DeviceDescriptor[] =
{
    LEN_DEVICE,     /* bLength */
    DESC_DEVICE,    /* bDescriptorType */
    0x00, 0x02,     /* bcdUSB 2.00 - was 0x0110. This part enumerates on HSUSBD and
                       already ships a Device Qualifier reporting 0x0200, so 1.10 here
                       was inconsistent; IAD is a USB 2.0 ECN mechanism and wants 2.00. */
    /* Multi-interface function device: the configuration below groups its
       interfaces with Interface Association Descriptors, so the device class
       triple must be Miscellaneous / Common Class / IAD. Without this Windows'
       usbccgp.sys ignores the IADs and splits every interface into its own
       function - which would tear AudioControl (IF0) away from AudioStreaming
       (IF1) and break the microphone. */
    0xEF,           /* bDeviceClass:    Miscellaneous */
    0x02,           /* bDeviceSubClass: Common Class */
    0x01,           /* bDeviceProtocol: Interface Association Descriptor */
    CEP_MAX_PKT_SIZE,   /* bMaxPacketSize0 */
    /* idVendor */
    USBD_VID & 0x00FF,
    ((USBD_VID & 0xFF00) >> 8),
    /* idProduct */
    USBD_PID & 0x00FF,
    ((USBD_PID & 0xFF00) >> 8),
    0x00, 0x01,     /* bcdDevice */
    0x01,           /* iManufacture */
    0x02,           /* iProduct */
    0x00,           /* iSerialNumber - no serial */
    0x01            /* bNumConfigurations */
};

/*!<USB Qualifier Descriptor */
uint8_t gu8QualifierDescriptor[] =
{
    LEN_QUALIFIER,  /* bLength */
    DESC_QUALIFIER, /* bDescriptorType */
    0x00, 0x02,     /* bcdUSB */
    0x00,           /* bDeviceClass */
    0x00,           /* bDeviceSubClass */
    0x00,           /* bDeviceProtocol */
    CEP_MAX_PKT_SIZE, /* bMaxPacketSize0 */
    0x01,           /* bNumConfigurations */
    0x00
};

/*!<USB Configure Descriptor */
uint8_t gu8ConfigDescriptor[] =
{
    LEN_CONFIG,     /* bLength */
    DESC_CONFIG,    /* bDescriptorType */
    0xB4, 0x00,         /* wTotalLength = 180 (0xB4). Recount whenever a descriptor
                           is added or removed - a wrong value here is the single
                           most common cause of "device descriptor request failed":
                             Configuration                 0x09
                             IAD (audio function)          0x08
                             IF0 AudioControl              0x09
                               AC Header                   0x09
                               Input Terminal  (mic)       0x0C
                               Feature Unit    (mic)       0x08
                               Output Terminal (mic)       0x09
                             IF1 AudioStreaming alt0       0x09
                             IF1 AudioStreaming alt1       0x09
                               AS General                  0x07
                               Format Type I               0x0B
                               Endpoint  (EPA ISO IN)      0x07
                               CS Endpoint                 0x07
                                                           ----   0x72 audio
                             IAD (CDC function)            0x08
                             IF2 CDC Communication         0x09
                               CDC Header functional       0x05
                               CDC Call Management         0x05
                               CDC ACM functional          0x04
                               CDC Union functional        0x05
                               Endpoint  (EPD Int IN)      0x07
                             IF3 CDC Data                  0x09
                               Endpoint  (EPB Bulk IN)     0x07
                               Endpoint  (EPC Bulk OUT)    0x07
                                                           ----   0x42 CDC
                                                           ====
                                                           0xB4  (180) */
    /*
       Configuration Descriptor                    (0x09)
       Interface Descriptor (Audio Class)          (0x09)
       Audio Control Interface Header Descriptor   (0x0A)
       Microphone - Audio Control
         Audio Control Input Terminal Descriptor   (0x0C)
         Audio Control Feature Unit Descriptor     (0x08)
         Audio Control Output Terminal Descriptor  (0x09)
       Speaker - Audio Control
         Audio Control Input Terminal Descriptor   (0x0C)
         Audio Control Feature Unit Descriptor     (0x0A)
         Audio Control Output Terminal Descriptor  (0x09)
       Microphone - Interface alternate 0
         Standard AS interface                     (0x09)
       Microphone - Interface alternate 1~6
         Standard AS interface                                         (0x09)
         Audio Streaming Class Specific Interface Descriptor           (0x07)
         Audio Streaming Format Type Descriptor                        (0x0E)
         Endpoint Descriptor                                           (0x07)
         Audio Streaming Class Specific Audio Data Endpoint Descriptor (0x07)
         *Each Interface alternate Summary                             (0x2C)
       Speaker - Interface alternate 0
         Standard AS interface                     (0x09)
       Speaker - Interface alternate 1~4
         Standard AS interface                                         (0x09)
         Audio Streaming Class Specific Interface Descriptor           (0x07)
         Audio Streaming Format Type Descriptor                        (0x0E)
         Endpoint Descriptor                                           (0x09)
         Audio Streaming Class Specific Audio Data Endpoint Descriptor (0x07)
         *Each Interface alternate Summary                             (0x2E)

       0x09 + 0x09 + 0x0A + (0x0C + 0x08 + 0x09) + (0x0C + 0x0A + 0x09) +
       0x09 + 0x2C
       0x09 + 0x2E = 0xC4
    */
    0x04,               /* bNumInterfaces - IF0 AudioControl, IF1 AudioStreaming,
                           IF2 CDC Communication, IF3 CDC Data */
    0x01,               /* bConfigurationValue */
    0x00,               /* iConfiguration */
    0x80,               /* bmAttributes */
    0x20,               /* Max power */

    /* ---- Interface Association Descriptor: AUDIO function (IF0 + IF1) ----
       Groups the AudioControl and AudioStreaming interfaces into one function
       so usbccgp.sys hands both to usbaudio.sys as a unit. Mandatory once the
       device declares itself EF/02/01 - see the device descriptor above. */
    0x08,               /* bLength */
    0x0B,               /* bDescriptorType: INTERFACE_ASSOCIATION */
    0x00,               /* bFirstInterface:  IF0 (AudioControl) */
    0x02,               /* bInterfaceCount:  IF0 + IF1 */
    0x01,               /* bFunctionClass:    AUDIO */
    0x01,               /* bFunctionSubClass: AUDIOCONTROL */
    0x00,               /* bFunctionProtocol */
    0x00,               /* iFunction */

    /* Interface Descriptor (Audio Class) */
    0x09,               /* bLength */
    0x04,               /* bDescriptorType */
    0x00,               /* bInterfaceNumber */
    0x00,               /* bAlternateSetting */
    0x00,               /* bNumEndpoints */
    0x01,               /* bInterfaceClass:AUDIO */
    0x01,               /* bInterfaceSubClass:AUDIOCONTROL */
    0x00,               /* bInterfaceProtocol */
    0x00,               /* iInterface */

    /* Audio Control Interface Header Descriptor */
    0x09,               /* bLength */
    0x24,               /* bDescriptorType:CS_INTERFACE */
    0x01,               /* bDescriptorSubType:HEADER */
    0x00, 0x01,         /* bcdADC:1.0 */
    0x26, 0x00,         /* wTotalLength  -- CORRECTED, was 0x23 in the stock sample.
                           Per UAC 1.0 this is the total size of the class-specific
                           AudioControl interface descriptor, INCLUDING this header:
                             AC Header               0x09
                             Input Terminal (mic)    0x0C
                             Feature Unit (mic)      0x08
                             Output Terminal (mic)   0x09
                                                     ----
                                                     0x26  (38 bytes)
                           The original 0x23 (35) under-reports by 3 bytes, which can
                           make a host truncate its parse of the Output Terminal.
                           If enumeration regresses, this is the first thing to revert.

                           (The comment block below is inherited from the stock
                            two-interface sample and lists speaker units that this
                            record-only build does not contain.)
                           Audio Control Interface Header Descriptor  (0x0A)
                           Microphone - Audio Control
                             Audio Control Input Terminal Descriptor  (0x0C)
                             Audio Control Feature Unit Descriptor    (0x08)
                             Audio Control Output Terminal Descriptor (0x09)
                           Speaker - Audio Control
                             Audio Control Input Terminal Descriptor  (0x0C)
                             Audio Control Feature Unit Descriptor    (0x0A)
                             Audio Control Output Terminal Descriptor (0x09)

                             0x0A + (0x0C + 0x08 + 0x09) + (0x0C + 0x0A + 0x09) = 0x46
                        */
    0x01,               /* bInCollection */
    0x01,               /* baInterfaceNr(1) - Microphone */

    /* Audio Control Input Terminal Descriptor - Microphone (Terminal ID 4) */
    0x0C,               /* bLength */
    0x24,               /* bDescriptorType:CS_INTERFACE */
    0x02,               /* bDescriptorSubType:INPUT_TERMINAL*/
    0x04,               /* bTerminalID*/
    0x02, 0x04,         /* wTerminalType: Headset */
    0x00,               /* bAssocTerminal*/
    0x01,               /* bNrChannels : a number that specifies how many logical audio channels are present in the cluster */
    0x01, 0x00,         /* wChannelConfig: a bit field that indicates which spatial locations are present in the cluster.
                           The bit allocations are as follows:
                             D0: Left Front (L)
                             D1: Right Front (R)
                             D2: Center Front (C)
                             D3: Low Frequency Enhancement (LFE)
                             D4: Left Surround (LS)
                             D5: Right Surround (RS)
                             D6: Left of Center (LC)
                             D7: Right of Center (RC)
                             D8: Surround (S)
                             D9: Side Left (SL)
                             D10: Side Right (SR)
                             D11: Top (T)
                             D15..12: Reserved
                        */
    0x00,               /* iChannelNames*/
    0x00,               /* iTerminal*/

    /* Audio Control Feature Unit Descriptor - Microphone (UNIT ID 5 - Source 4) */
    0x08,               /* bLength */
    0x24,               /* bDescriptorType */
    0x06,               /* bDescriptorSubType */
    REC_FEATURE_UNITID, /* bUnitID */
    0x04,               /* bSourceID */
    0x01,               /* bControlSize - Size, in bytes, of the bmControls field: n */
    0x03,               /* bmaControls(0) */
    /* A bit set to 1 indicates that the mentioned
       Control is supported for master channel
       0:
       D0: Mute
       D1: Volume
       D2: Bass
       D3: Mid
       D4: Treble
       D5: Graphic Equalizer
       D6: Automatic Gain
       D7: Delay
       D8: Bass Boost
       D9: Loudness
       D10..(n*8-1): Reserved
    */
    0x00,               /* iFeature */

    /* Audio Control Output Terminal Descriptor - Microphone (Terminal ID 2 - Source ID 5) */
    0x09,               /* bLength */
    0x24,               /* bDescriptorType:CS_INTERFACE */
    0x03,               /* bDescriptorSubType:OUTPUT_TERMINAL */
    0x02,               /* bTerminalID */
    0x01, 0x01,         /* wTerminalType: 0x0101 usb streaming */
    0x00,               /* bAssocTerminal */
    REC_FEATURE_UNITID, /* bSourceID */
    0x00,               /* iTerminal */

    /* Interface Descriptor - Interface 1, alternate 0 */
    0x09,               /* bLength */
    0x04,               /* bDescriptorType */
    0x01,               /* bInterfaceNumber */
    0x00,               /* bAlternateSetting */
    0x00,               /* bNumEndpoints */
    0x01,               /* bInterfaceClass:AUDIO */
    0x02,               /* bInterfaceSubClass:AUDIOSTREAMING */
    0x00,               /* bInterfaceProtocol */
    0x00,               /* iInterface */

    /* Interface Descriptor - Interface 1, alternate 1 */
    0x09,               /* bLength */
    0x04,               /* bDescriptorType */
    0x01,               /* bInterfaceNumber */
    0x01,               /* bAlternateSetting */
    0x01,               /* bNumEndpoints */
    0x01,               /* bInterfaceClass:AUDIO */
    0x02,               /* bInterfaceSubClass:AUDIOSTREAMING */
    0x00,               /* bInterfaceProtocol */
    0x00,               /* iInterface */

    /* Audio Streaming Class Specific Interface Descriptor (this interface's endpoint connect to Terminal ID 0x02 - Microphoe) */
    0x07,               /* bLength */
    0x24,               /* bDescriptorType:CS_INTERFACE */
    0x01,               /* bDescriptorSubType:AS_GENERAL */
    0x02,               /* bTernimalLink */
    0x01,               /* bDelay */
    0x01, 0x00,         /* wFormatTag:0x0001 PCM */

    /* Audio Streaming Format Type Descriptor */
    0x0B,               /* bLength */
    0x24,               /* bDescriptorType:CS_INTERFACE */
    0x02,               /* bDescriptorSubType:FORMAT_TYPE */
    0x01,               /* bFormatType:FORMAT_TYPE_I */
    /* Standard AS interface 1, alternate 1 */
    0x01,               /* bNrChannels    :  2 Channels */
    0x02,               /* bSubFrameSize  :  2 bytes per sample */
    0x10,               /* bBitResolution : 16 bits  per sample */
    0x01,               /* bSamFreqType :
                           0 Continuous sampling frequency
                           1 The number of discrete sampling frequencies */
    /* bSamFreqType  */
    (AUDIO_RATE_16K & 0xFF),
    ((AUDIO_RATE_16K >> 8) & 0xFF),
    ((AUDIO_RATE_16K >> 16) & 0xFF),

    /* Endpoint Descriptor (ISO IN Audio Data Endpoint - alternate 1) */
    0x07,                             /* bLength */
    0x05,                             /* bDescriptorType */
    ISO_IN_EP_NUM | EP_INPUT,         /* bEndpointAddress */
    0x05,                             /* bmAttributes */
    /* wMaxPacketSize note */
    (EPA_MAX_PKT_SIZE + 24) & 0x00FF,
    (((EPA_MAX_PKT_SIZE + 24) & 0xFF00) >> 8),
    0x01,                             /* bInterval*/

    /* Audio Streaming Class Specific Audio Data Endpoint Descriptor */
    0x07,               /* bLength */
    0x25,               /* bDescriptorType:CS_ENDPOINT */
    0x01,               /* bDescriptorSubType:EP_GENERAL */
    0x01,               /* bmAttributes, Bit 0: Sampling Frequency */
    0x00,               /* bLockDelayUnits */
    0x00, 0x00,         /* wLockDelay */

    /* ================= CDC-ACM console function (IF2 + IF3) ================= */

    /* ---- Interface Association Descriptor: CDC function ---- */
    0x08,               /* bLength */
    0x0B,               /* bDescriptorType: INTERFACE_ASSOCIATION */
    CDC_CTRL_ITF_NUM,   /* bFirstInterface:  IF2 (CDC Communication) */
    0x02,               /* bInterfaceCount:  IF2 + IF3 */
    0x02,               /* bFunctionClass:    CDC (Communication) */
    0x02,               /* bFunctionSubClass: Abstract Control Model */
    0x01,               /* bFunctionProtocol: AT commands (V.250) */
    0x00,               /* iFunction */

    /* ---- IF2: CDC Communication interface ---- */
    0x09,               /* bLength */
    0x04,               /* bDescriptorType: INTERFACE */
    CDC_CTRL_ITF_NUM,   /* bInterfaceNumber */
    0x00,               /* bAlternateSetting */
    0x01,               /* bNumEndpoints: the notification endpoint */
    0x02,               /* bInterfaceClass:    CDC */
    0x02,               /* bInterfaceSubClass: Abstract Control Model */
    0x01,               /* bInterfaceProtocol: AT commands */
    0x00,               /* iInterface */

    /* CDC Header Functional Descriptor */
    0x05,               /* bLength */
    0x24,               /* bDescriptorType: CS_INTERFACE */
    0x00,               /* bDescriptorSubtype: Header */
    0x10, 0x01,         /* bcdCDC: 1.10 */

    /* CDC Call Management Functional Descriptor */
    0x05,               /* bLength */
    0x24,               /* bDescriptorType: CS_INTERFACE */
    0x01,               /* bDescriptorSubtype: Call Management */
    0x00,               /* bmCapabilities: device does not handle call management */
    CDC_DATA_ITF_NUM,   /* bDataInterface */

    /* CDC Abstract Control Management Functional Descriptor */
    0x04,               /* bLength */
    0x24,               /* bDescriptorType: CS_INTERFACE */
    0x02,               /* bDescriptorSubtype: ACM */
    0x02,               /* bmCapabilities: supports Set/Get_Line_Coding,
                           Set_Control_Line_State and Serial_State. Bit 1 is what
                           makes Windows expose DTR, which the firmware uses as the
                           "host has opened the port" gate. */

    /* CDC Union Functional Descriptor */
    0x05,               /* bLength */
    0x24,               /* bDescriptorType: CS_INTERFACE */
    0x06,               /* bDescriptorSubtype: Union */
    CDC_CTRL_ITF_NUM,   /* bControlInterface */
    CDC_DATA_ITF_NUM,   /* bSubordinateInterface0 */

    /* Notification endpoint (EPD, interrupt IN).
       Never actually written by this firmware - the CDC spec requires the
       endpoint to exist, and Windows will not bind usbser.sys without it. */
    0x07,                             /* bLength */
    0x05,                             /* bDescriptorType: ENDPOINT */
    INT_IN_EP_NUM | EP_INPUT,         /* bEndpointAddress: 0x84 */
    0x03,                             /* bmAttributes: Interrupt */
    EPD_MAX_PKT_SIZE, 0x00,           /* wMaxPacketSize: 8 */
    0x10,                             /* bInterval: 16 ms (full speed) */

    /* ---- IF3: CDC Data interface ---- */
    0x09,               /* bLength */
    0x04,               /* bDescriptorType: INTERFACE */
    CDC_DATA_ITF_NUM,   /* bInterfaceNumber */
    0x00,               /* bAlternateSetting */
    0x02,               /* bNumEndpoints: bulk IN + bulk OUT */
    0x0A,               /* bInterfaceClass: CDC Data */
    0x00,               /* bInterfaceSubClass */
    0x00,               /* bInterfaceProtocol */
    0x00,               /* iInterface */

    /* Bulk IN endpoint (EPB) - console output, device -> host */
    0x07,                             /* bLength */
    0x05,                             /* bDescriptorType: ENDPOINT */
    BULK_IN_EP_NUM | EP_INPUT,        /* bEndpointAddress: 0x82 */
    0x02,                             /* bmAttributes: Bulk */
    EPB_MAX_PKT_SIZE, 0x00,           /* wMaxPacketSize: 64 (full-speed maximum) */
    0x00,                             /* bInterval: ignored for bulk */

    /* Bulk OUT endpoint (EPC) - command input, host -> device */
    0x07,                             /* bLength */
    0x05,                             /* bDescriptorType: ENDPOINT */
    BULK_OUT_EP_NUM | EP_OUTPUT,      /* bEndpointAddress: 0x03 */
    0x02,                             /* bmAttributes: Bulk */
    EPC_MAX_PKT_SIZE, 0x00,           /* wMaxPacketSize: 64 (full-speed maximum) */
    0x00,                             /* bInterval: ignored for bulk */
};

/*!<USB Language String Descriptor */
uint8_t gu8StringLang[4] =
{
    4,              /* bLength */
    DESC_STRING,    /* bDescriptorType */
    0x09, 0x04
};

/*!<USB Vendor String Descriptor */
uint8_t gu8VendorStringDesc[] =
{
    16,
    DESC_STRING,
    'N', 0, 'u', 0, 'v', 0, 'o', 0, 't', 0, 'o', 0, 'n', 0
};

/*!<USB Product String Descriptor */
/* "GestureAI DMIC Mic" = 18 chars -> bLength = 2 + 18*2 = 38 (0x26).
   Keep bLength in sync if you rename the device. */
uint8_t gu8ProductStringDesc[] =
{
    38,
    DESC_STRING,
    'G', 0, 'e', 0, 's', 0, 't', 0, 'u', 0, 'r', 0, 'e', 0, 'A', 0, 'I', 0, ' ', 0,
    'D', 0, 'M', 0, 'I', 0, 'C', 0, ' ', 0,
    'M', 0, 'i', 0, 'c', 0
};

uint8_t *gpu8UsbString[4] =
{
    gu8StringLang,
    gu8VendorStringDesc,
    gu8ProductStringDesc,
    NULL,
};

uint8_t *gu8UsbHidReport[3] =
{
    NULL,
    NULL,
    NULL,
};

uint32_t gu32UsbHidReportLen[3] =
{
    0,
    0,
    0,
};

uint32_t gu32ConfigHidDescIdx[3] =
{
    0,
    0,
    0
};

S_HSUSBD_INFO_T gsHSInfo =
{
    gu8DeviceDescriptor,
    gu8ConfigDescriptor,
    gpu8UsbString,
    gu8QualifierDescriptor,
    gu8ConfigDescriptor,
    gu8ConfigDescriptor,
    gu8ConfigDescriptor,
    NULL,
    gu8UsbHidReport,
    gu32UsbHidReportLen,
    gu32ConfigHidDescIdx,
};
