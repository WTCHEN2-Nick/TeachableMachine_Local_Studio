/***************************************************************************//**
 * @file     usbd_audio.h
 * @version  V3.10
 * @brief    HSUSBD USB Audio Class 1.0 microphone header (NuMaker-GestureAI-M55M1).
 *
 * @copyright SPDX-License-Identifier: Apache-2.0
 * @copyright Copyright (C) 2021 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/
#ifndef __USBD_UAC_H__
#define __USBD_UAC_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Define the vendor id and product id */
/* NOTE: VID 0x0416 is Nuvoton's. Each variant of this sample uses its own PID
         so that Windows does not reuse a cached driver / endpoint description
         from a different board:
           0x1287  KeywordSpotting sample
           0x1288  NuMaker-X-M55M1D build of this sample
           0x1289  NuMaker-GestureAI-M55M1 (this build)
           0x128A  NuMaker-VoiceAI-M55M1

   Distinct PIDs let both boards be plugged into one PC at the same time, and
   stop Windows serving one board a descriptor set it cached from the other -
   which matters now that this is a UAC+CDC composite rather than a
   single-function audio device. */
#define USBD_VID        0x0416
#define USBD_PID        0x1289

#define AUDIO_RATE  AUDIO_RATE_16K

#define AUDIO_RATE_16K   16000
#define AUDIO_RATE_48K   48000       /* The audo play sampling rate. The setting is 48KHz */
#define AUDIO_RATE_96K   96000       /* The audo play sampling rate. The setting is 96KHz */
#define AUDIO_RATE_441K  44100       /* The audo play sampling rate. The setting is 44.1KHz */

/*!<Define Audio information */
/* Mono. The board has a single MP34DT05-M feeding one DMIC channel, and the
   USB descriptor in descriptors.c declares bNrChannels = 1, so this MUST
   stay 1. See DMIC_MIC_CH_MSK in Device/include/DMICRecord.h. */
#define REC_CHANNELS    1
#define REC_BIT_RATE    0x10    /* 16-bit data rate */

#define REC_FEATURE_UNITID      0x05

/* Bytes of PCM produced in one 1 ms USB frame.
   16000 Hz * 1 ch * 2 bytes / 1000 = 32 bytes */
#define UAC_REC_BYTES_PER_MS    ((AUDIO_RATE * REC_CHANNELS * 2) / 1000)

/* Size of one PcmRecBuff row. One LPPDMA block == one 1 ms ISO packet, so only
   UAC_REC_BYTES_PER_MS bytes are used; rounded up to a 32-byte cache line. */
#define BUFF_LEN    64

/* DMIC DSP gain in dB (0..36). The Nuvoton samples hard-code +36 dB, which
   clips easily on near-field speech. +24 dB is a safer starting point for
   recording noise/speech datasets; raise it if the level meter stays low. */
#define DMIC_DSP_GAIN_DB    24

/********************************************/
/* Audio Class Current State                */
/********************************************/
/*!<Define Audio Class Current State */
#define UAC_STOP_AUDIO_RECORD           0
#define UAC_START_AUDIO_RECORD          1
#define UAC_PROCESSING_AUDIO_RECORD     2
#define UAC_BUSY_AUDIO_RECORD           3

/***************************************************/
/*      Audio Class-Specific Request Codes         */
/***************************************************/
/*!<Define Audio Class Specific Request */
#define UAC_REQUEST_CODE_UNDEFINED  0x00
#define UAC_SET_CUR                 0x01
#define UAC_GET_CUR                 0x81
#define UAC_SET_MIN                 0x02
#define UAC_GET_MIN                 0x82
#define UAC_SET_MAX                 0x03
#define UAC_GET_MAX                 0x83
#define UAC_SET_RES                 0x04
#define UAC_GET_RES                 0x84
#define UAC_SET_MEM                 0x05
#define UAC_GET_MEM                 0x85
#define UAC_GET_STAT                0xFF

#define MUTE_CONTROL                0x01
#define VOLUME_CONTROL              0x02

/*-------------------------------------------------------------*/
/* Define EP maximum packet size */
#define CEP_MAX_PKT_SIZE        64
#define CEP_OTHER_MAX_PKT_SIZE  64
/* descriptors.c declares wMaxPacketSize = EPA_MAX_PKT_SIZE + 24.
   40 + 24 = 64 bytes, i.e. 2x the 32 bytes actually sent each 1 ms frame. */
#define EPA_MAX_PKT_SIZE            40
#define EPA_OTHER_MAX_PKT_SIZE      40

/* CDC-ACM console endpoints.
 *
 * IMPORTANT: UAC_Init() sets HSUSBD->OPER = 0, i.e. this device enumerates at
 * FULL SPEED. A full-speed bulk endpoint may only declare wMaxPacketSize of
 * 8/16/32/64 - 512 is High Speed only and would be rejected. Do not "optimise"
 * these to 512 without also moving the device to High Speed, which would break
 * the 1 ms isochronous cadence UAC_Init() depends on. */
#define EPB_MAX_PKT_SIZE            64      /* CDC bulk IN  (device -> host) */
#define EPC_MAX_PKT_SIZE            64      /* CDC bulk OUT (host -> device) */
#define EPD_MAX_PKT_SIZE            8       /* CDC notification (unused, spec-required) */

/* HSUSBD endpoint SRAM map. Total must stay inside 4 KB (0x1000).
 * EPA keeps its original base/len so the proven audio path is untouched. */
#define CEP_BUF_BASE    0
#define CEP_BUF_LEN     CEP_MAX_PKT_SIZE    /* 0x0000 .. 0x003F */
#define EPA_BUF_BASE    0x100
#define EPA_BUF_LEN     0x600               /* 0x0100 .. 0x06FF */
/* Keep the bulk endpoint buffers exactly one wMaxPacketSize long.
 *
 * HSUSBD_ConfigEp() puts bulk endpoints in MODE_AUTO (auto-validate): the
 * controller commits a packet by itself as soon as the endpoint buffer holds a
 * full wMaxPacketSize. cdc_console.c's TxKick() relies on that, and gates every
 * FIFO load on EPINTSTS.BUFEMPTYIF - the controller's own "a buffer is free for
 * the local side" flag. A one-packet window makes BUFEMPTYIF mean exactly
 * "the previous packet has been collected", which is the whole interlock.
 *
 * A larger window is legal (the BSP's own samples run EPA_BUF_LEN 512 against a
 * 64-byte full-speed MPS), but it decouples BUFEMPTYIF from packet completion
 * and there is no reason to want that here.
 *
 * TxKick() deliberately does NOT write EPTXCNT: that is the manual-validate
 * mechanism, and issuing it on an auto-validate endpoint commits the same
 * packet twice. See the commentary in cdc_console.c. */
#define EPB_BUF_BASE    0x700
#define EPB_BUF_LEN     EPB_MAX_PKT_SIZE    /* 0x0700 .. 0x073F */
#define EPC_BUF_BASE    0x740
#define EPC_BUF_LEN     EPC_MAX_PKT_SIZE    /* 0x0740 .. 0x077F */
#define EPD_BUF_BASE    0x780
#define EPD_BUF_LEN     0x40                /* 0x0780 .. 0x07BF */

/* Endpoint addresses (the low nibble of bEndpointAddress) */
#define ISO_IN_EP_NUM       0x01    /* EPA - UAC microphone   */
#define BULK_IN_EP_NUM      0x02    /* EPB - CDC console TX   */
#define BULK_OUT_EP_NUM     0x03    /* EPC - CDC console RX   */
#define INT_IN_EP_NUM       0x04    /* EPD - CDC notification */

/* Interface numbers. IF0/IF1 are the audio function, IF2/IF3 the CDC function;
 * each pair is wrapped in an Interface Association Descriptor. */
#define UAC_CTRL_ITF_NUM    0x00
#define UAC_STREAM_ITF_NUM  0x01
#define CDC_CTRL_ITF_NUM    0x02
#define CDC_DATA_ITF_NUM    0x03

#define PDMA_TXBUFFER_CNT     7
#define PDMA_RXBUFFER_CNT     8

/*-------------------------------------------------------------*/
extern volatile uint8_t u8RxDataCntInBuffer;

extern uint32_t volatile u32BuffLen, u32RxBuffLen;
extern uint32_t volatile g_usbd_UsbAudioState;
extern uint32_t g_usbd_SampleRate;

extern uint8_t PcmRecBuff[PDMA_RXBUFFER_CNT][BUFF_LEN];
extern uint8_t u8PcmRxBufFull[PDMA_RXBUFFER_CNT];
extern volatile uint8_t u8PDMARxIdx;

void UAC_DeviceEnable(uint32_t bIsPlay);
void UAC_DeviceDisable(uint32_t bIsPlay);
void UAC_SendRecData(void);

void AudioStartRecord(uint32_t u32SampleRate);
/*-------------------------------------------------------------*/
void UAC_Init(void);
/** Configure every non-control endpoint. Called from UAC_Init() and, crucially,
 *  again from the bus-reset branch of HSUSBD_IRQHandler(). */
void UAC_ConfigEndpoints(void);
void UAC_ClassRequest(void);
void UAC_SetInterface(uint32_t u32AltInterface);

void EPA_Handler(void);

typedef struct dma_desc_t
{
    uint32_t ctl;
    uint32_t src;
    uint32_t dest;
    uint32_t offset;
} DMA_DESC_T;

extern volatile uint8_t g_usbd_txflag;
extern volatile uint8_t g_usbd_rxflag;
void LPPDMA_init();

#ifdef __cplusplus
}
#endif

#endif  /* __USBD_UAC_H_ */
