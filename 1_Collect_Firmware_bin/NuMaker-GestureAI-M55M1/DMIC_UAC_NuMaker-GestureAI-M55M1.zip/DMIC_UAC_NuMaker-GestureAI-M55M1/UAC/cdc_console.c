/**************************************************************************//**
 * @file     cdc_console.c
 * @version  V1.00
 * @brief    USB CDC-ACM console + command line for the DMIC_UAC sample.
 *
 * WHY EVERY WRITE PATH HERE IS NON-BLOCKING
 * -----------------------------------------
 * The CDC console and the UAC microphone share one HSUSBD controller and one
 * interrupt handler. printf() is reachable from inside that handler:
 *
 *     HSUSBD_IRQHandler()            usbd_audio.c
 *       -> UAC_DeviceEnable(0)
 *         -> AudioStartRecord()
 *           -> printf("Start Record ...")
 *
 * If CdcConsole_Write() waited for the bulk IN endpoint to drain, that wait
 * would happen inside the ISR - and the EPB completion interrupt that would end
 * the wait cannot pre-empt an interrupt of the same priority. The firmware
 * would deadlock with the microphone stopped.
 *
 * So: producers only ever copy into a ring buffer and return. The endpoint is
 * fed exclusively from CdcConsole_Poll() in the main loop. When the ring is
 * full, bytes are DROPPED and counted - never blocked on. Losing a few log
 * lines is always preferable to stalling audio capture, and the UART console
 * still has the complete output.
 *
 * BOARD-INDEPENDENT ON PURPOSE - see cdc_console.h.
 *
 * @copyright SPDX-License-Identifier: Apache-2.0
 ******************************************************************************/
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <stdlib.h>

#include "NuMicro.h"
#include "usbd_audio.h"
#include "DMICRecord.h"

/* This translation unit implements Console_Printf(); it must see the real
   printf, not the macro that redirects to it. */
#define CDC_CONSOLE_NO_PRINTF_REDIRECT
#include "cdc_console.h"

/*---------------------------------------------------------------------------*/
/* Tunables                                                                  */
/*---------------------------------------------------------------------------*/
/* Ring sizes MUST be powers of two - the index wrap uses a mask. 2 KB holds
   the ~25 lines printed between reset and the host opening the port, so no
   start-up output is lost. */
#define CONSOLE_TX_RING_SIZE    2048U
#define CONSOLE_RX_RING_SIZE    256U
#define CONSOLE_LINE_MAX        80U
#define CONSOLE_FMT_BUF         160U

/* How long a queued bulk IN packet may sit uncollected before the console
 * gives up on it, in USB frames (1 ms each).
 *
 * This is the recovery path for a host that stops collecting. A queued packet
 * keeps EPB's single buffer occupied, so BUFEMPTYIF stays low and TxKick()
 * returns without draining the ring. If the host stops polling (COM port
 * closed, terminal exited, application stopped reading) that state would
 * otherwise persist forever and every subsequent console byte would be
 * silently dropped.
 *
 * It is no longer load-bearing for normal operation: with the TXPKIF/BUFEMPTYIF
 * protocol in TxKick() a healthy host never reaches this timeout. If
 * s_u32TxAborts is anything but 0 during normal use, the endpoint protocol is
 * broken again - treat it as a regression signal, not as routine.
 *
 * 500 frames is far longer than any healthy host takes to service a bulk
 * endpoint, so a timeout here always means the host really has stopped. */
#define CONSOLE_TX_STALL_FRAMES 500U

/*---------------------------------------------------------------------------*/
/* State                                                                     */
/*---------------------------------------------------------------------------*/
static S_CONSOLE_CFG    s_sCfg;
static uint32_t         s_u32Inited      = 0U;

static char             s_acTxRing[CONSOLE_TX_RING_SIZE];
static volatile uint32_t s_u32TxHead     = 0U;   /* written by producers */
static volatile uint32_t s_u32TxTail     = 0U;   /* written by CdcConsole_Poll only */
static volatile uint32_t s_u32Dropped    = 0U;
static volatile uint8_t  s_u8TxBusy      = 0U;   /* a packet is in flight on EPB */
static uint16_t          s_u16TxKickFrame = 0U;  /* FRAMECNT when it was queued */
static uint32_t          s_u32TxAborts    = 0U;  /* stalled packets abandoned */
static volatile uint8_t  s_u8TxNeedZlp    = 0U;  /* last packet was exactly MPS */

/* EPINTSTS is write-1-to-clear; 0x1FFF covers every defined EPx flag. Same
   idiom as the BSP HSUSBD_CLR_CEP_INT_FLAG(0x1ffc).

   Clearing the whole set before arming an endpoint interrupt is essential.
   INTKIF and friends latch on every host token even while EPINTEN is 0, and
   the ISR only ever clears EPINTSTS & EPINTEN - so anything latched during an
   idle period survives and fires the handler the instant the interrupt is
   armed, for a packet that has not been sent. */
#define EPB_INTSTS_ALL          0x1FFFU

static char             s_acRxRing[CONSOLE_RX_RING_SIZE];
static volatile uint32_t s_u32RxHead     = 0U;   /* written by EPC ISR */
static volatile uint32_t s_u32RxTail     = 0U;   /* written by CdcConsole_Poll only */

static char             s_acLine[CONSOLE_LINE_MAX + 1U];
static uint32_t         s_u32LineLen     = 0U;

static volatile uint8_t  s_u8PortOpen    = 0U;   /* host asserted DTR */

/* CDC line coding. The console is not bridged to a real UART, so these values
   are stored and echoed back purely to keep the host's driver happy. */
static struct
{
    uint32_t u32DTERate;
    uint8_t  u8CharFormat;
    uint8_t  u8ParityType;
    uint8_t  u8DataBits;
} s_sLineCoding = { 115200UL, 0U, 0U, 8U };

/* Runtime DMIC state, so "stat" can report what was actually applied. */
static uint32_t s_u32ActiveCh   = 0U;
static uint32_t s_u32ActiveEdgeIsRising = 0U;
static int32_t  s_i32ActiveGain = DMIC_DSP_GAIN_DB;
static uint32_t s_u32ActiveOsr  = DMIC_OVERSAMPLE_RATIO;

static const uint32_t s_au32ChMsk[4] =
{
    DMIC_CTL_CHEN0_Msk, DMIC_CTL_CHEN1_Msk, DMIC_CTL_CHEN2_Msk, DMIC_CTL_CHEN3_Msk
};

static void TxAbort(void);      /* defined with the pump, used by the class request */

/*---------------------------------------------------------------------------*/
/* Low-level output                                                          */
/*---------------------------------------------------------------------------*/

/* Write straight to the debug UART, expanding '\n' to "\r\n" exactly as the
   BSP's SendChar_ToUART() does. Bypasses stdio so it cannot recurse back into
   Console_Printf(). Blocking, but only on the UART FIFO. */
static void Console_WriteUart(const char *pcData, uint32_t u32Len)
{
    uint32_t i;

    for (i = 0U; i < u32Len; i++)
    {
        if (pcData[i] == '\n')
        {
            while (DEBUG_PORT->FIFOSTS & UART_FIFOSTS_TXFULL_Msk) {}

            DEBUG_PORT->DAT = '\r';
        }

        while (DEBUG_PORT->FIFOSTS & UART_FIFOSTS_TXFULL_Msk) {}

        DEBUG_PORT->DAT = (uint32_t)pcData[i];
    }
}

void CdcConsole_Write(const char *pcData, uint32_t u32Len)
{
    uint32_t u32Primask;
    uint32_t i;

    if ((s_u32Inited == 0U) || (pcData == NULL))
        return;

    /* Producers may be the main loop or the HSUSBD/LPPDMA ISRs, so the head
       update has to be atomic. Saving PRIMASK (rather than a bare
       __enable_irq()) keeps this safe when called from an ISR. */
    u32Primask = __get_PRIMASK();
    __disable_irq();

    for (i = 0U; i < u32Len; i++)
    {
        uint32_t u32Next = (s_u32TxHead + 1U) & (CONSOLE_TX_RING_SIZE - 1U);

        if (u32Next == s_u32TxTail)
        {
            /* Ring full: drop the rest. Never block - see the file header. */
            s_u32Dropped += (u32Len - i);
            break;
        }

        /* Expand '\n' to "\r\n" so the host terminal shows proper line breaks. */
        if (pcData[i] == '\n')
        {
            s_acTxRing[s_u32TxHead] = '\r';
            s_u32TxHead = u32Next;
            u32Next = (s_u32TxHead + 1U) & (CONSOLE_TX_RING_SIZE - 1U);

            if (u32Next == s_u32TxTail)
            {
                s_u32Dropped += (u32Len - i);
                break;
            }
        }

        s_acTxRing[s_u32TxHead] = pcData[i];
        s_u32TxHead = u32Next;
    }

    __set_PRIMASK(u32Primask);
}

void Console_Printf(const char *fmt, ...)
{
    char    acBuf[CONSOLE_FMT_BUF];
    va_list ap;
    int     n;

    va_start(ap, fmt);
    n = vsnprintf(acBuf, sizeof(acBuf), fmt, ap);
    va_end(ap);

    if (n < 0)
        return;

    /* vsnprintf returns the length it WOULD have written; clamp to what fits. */
    if (n > (int)(sizeof(acBuf) - 1U))
        n = (int)(sizeof(acBuf) - 1U);

    Console_WriteUart(acBuf, (uint32_t)n);
    CdcConsole_Write(acBuf, (uint32_t)n);
}

/* Convenience: console-only output (used by the command handlers, whose replies
   belong to whoever typed the command, not in the UART log). */
static void CdcPuts(const char *pcStr)
{
    CdcConsole_Write(pcStr, (uint32_t)strlen(pcStr));
}

static void CdcPrintf(const char *fmt, ...)
{
    char    acBuf[CONSOLE_FMT_BUF];
    va_list ap;
    int     n;

    va_start(ap, fmt);
    n = vsnprintf(acBuf, sizeof(acBuf), fmt, ap);
    va_end(ap);

    if (n < 0)
        return;

    if (n > (int)(sizeof(acBuf) - 1U))
        n = (int)(sizeof(acBuf) - 1U);

    CdcConsole_Write(acBuf, (uint32_t)n);
}

/*---------------------------------------------------------------------------*/
/* HSUSBD glue                                                               */
/*---------------------------------------------------------------------------*/

void CdcConsole_ConfigEndpoints(void)
{
    /* EPB ==> Bulk IN, console output (device -> host) */
    HSUSBD_SetEpBufAddr(EPB, EPB_BUF_BASE, EPB_BUF_LEN);
    HSUSBD_SET_MAX_PAYLOAD(EPB, EPB_MAX_PKT_SIZE);
    HSUSBD_ConfigEp(EPB, BULK_IN_EP_NUM, HSUSBD_EP_CFG_TYPE_BULK, HSUSBD_EP_CFG_DIR_IN);

    /* Start from a clean slate: no interrupt armed, no latched status bits.
       Arming an endpoint interrupt over a stale status flag fires the handler
       for a packet that was never sent - that is what killed this device. */
    HSUSBD_ENABLE_EP_INT(EPB, 0U);
    HSUSBD_CLR_EP_INT_FLAG(EPB, EPB_INTSTS_ALL);
    s_u8TxBusy    = 0U;
    s_u8TxNeedZlp = 0U;

    /* EPC ==> Bulk OUT, command input (host -> device) */
    HSUSBD_SetEpBufAddr(EPC, EPC_BUF_BASE, EPC_BUF_LEN);
    HSUSBD_SET_MAX_PAYLOAD(EPC, EPC_MAX_PKT_SIZE);
    HSUSBD_ConfigEp(EPC, BULK_OUT_EP_NUM, HSUSBD_EP_CFG_TYPE_BULK, HSUSBD_EP_CFG_DIR_OUT);
    HSUSBD_ENABLE_EP_INT(EPC, HSUSBD_EPINTEN_RXPKIEN_Msk | HSUSBD_EPINTEN_SHORTRXIEN_Msk);

    /* EPD ==> Interrupt IN, CDC notification. Required by the CDC spec and by
       usbser.sys; this firmware never sends a SERIAL_STATE notification. */
    HSUSBD_SetEpBufAddr(EPD, EPD_BUF_BASE, EPD_BUF_LEN);
    HSUSBD_SET_MAX_PAYLOAD(EPD, EPD_MAX_PKT_SIZE);
    HSUSBD_ConfigEp(EPD, INT_IN_EP_NUM, HSUSBD_EP_CFG_TYPE_INT, HSUSBD_EP_CFG_DIR_IN);
}

void CdcConsole_EpbHandler(void)
{

    /* Only an actual transmission ends the packet. Test the flag rather than
       trusting that some EPB interrupt fired: with INTKIEN this handler used to
       run on a bare IN token - set at token time, before any data leaves, and
       set even for tokens the endpoint NAKs. EPA_Handler() gates the same way,
       as does hid_transfer_and_msc.c:330. */
    if (HSUSBD->EP[EPB].EPINTSTS & HSUSBD_EPINTSTS_TXPKIF_Msk)
    {
        s_u8TxBusy = 0U;
        HSUSBD_ENABLE_EP_INT(EPB, 0U);
    }
}

void CdcConsole_EpcHandler(void)
{
    uint32_t u32Cnt = HSUSBD->EP[EPC].EPDATCNT & 0xFFFFU;
    uint32_t i;

    for (i = 0U; i < u32Cnt; i++)
    {
        char     cCh    = (char)HSUSBD->EP[EPC].EPDAT_BYTE;
        uint32_t u32Nxt = (s_u32RxHead + 1U) & (CONSOLE_RX_RING_SIZE - 1U);

        if (u32Nxt == s_u32RxTail)
            continue;               /* RX ring full - discard, no blocking */

        s_acRxRing[s_u32RxHead] = cCh;
        s_u32RxHead = u32Nxt;
    }
}

void CdcConsole_BusReset(void)
{
    s_u8PortOpen = 0U;
    s_u32LineLen = 0U;
    s_u32RxTail  = s_u32RxHead;

    /* Flush the endpoint as well as clearing the flag: a bus reset abandons any
       packet still sitting in the EPB FIFO, and leaving it there would corrupt
       the first packet sent after re-enumeration. */
    TxAbort();
}

uint32_t CdcConsole_IsOpen(void)
{
    return (uint32_t)s_u8PortOpen;
}

uint32_t CdcConsole_Dropped(void)
{
    return s_u32Dropped;
}

uint32_t CdcConsole_ClassRequest(void)
{
    /* Route by interface number: the audio function owns IF0/IF1, the CDC
       function IF2/IF3. Anything else is not ours. */
    uint32_t u32Itf = gUsbCmd.wIndex & 0xFFU;

    if ((u32Itf != CDC_CTRL_ITF_NUM) && (u32Itf != CDC_DATA_ITF_NUM))
        return 0U;

    if (gUsbCmd.bmRequestType & 0x80U)
    {
        /* Device to host */
        switch (gUsbCmd.bRequest)
        {
            case CDC_GET_LINE_CODE:
                HSUSBD_PrepareCtrlIn((uint8_t *)&s_sLineCoding, 7U);
                HSUSBD_CLR_CEP_INT_FLAG(HSUSBD_CEPINTSTS_INTKIF_Msk);
                HSUSBD_ENABLE_CEP_INT(HSUSBD_CEPINTEN_INTKIEN_Msk);
                return 1U;

            default:
                HSUSBD_SET_CEP_STATE(HSUSBD_CEPCTL_STALLEN_Msk);
                return 1U;
        }
    }
    else
    {
        /* Host to device */
        switch (gUsbCmd.bRequest)
        {
            case CDC_SET_LINE_CODE:
                HSUSBD_CtrlOut((uint8_t *)&s_sLineCoding, 7U);
                HSUSBD_CLR_CEP_INT_FLAG(HSUSBD_CEPINTSTS_STSDONEIF_Msk);
                HSUSBD_SET_CEP_STATE(HSUSBD_CEPCTL_NAKCLR);
                HSUSBD_ENABLE_CEP_INT(HSUSBD_CEPINTEN_STSDONEIEN_Msk);
                return 1U;

            case CDC_SET_CONTROL_LINE_STATE:
                /* wValue bit0 = DTR, bit1 = RTS. DTR is the gate that says the
                   host has actually opened the COM port; without it the queued
                   output would be pushed at an endpoint nobody reads. */
                s_u8PortOpen = (uint8_t)(gUsbCmd.wValue & 0x01U);

                /* Closing the port leaves any queued packet uncollectable. Drop
                   it now instead of waiting for the stall timeout, so the next
                   open starts from a clean endpoint. */
                if (s_u8PortOpen == 0U)
                    TxAbort();

                HSUSBD_CLR_CEP_INT_FLAG(HSUSBD_CEPINTSTS_STSDONEIF_Msk);
                HSUSBD_SET_CEP_STATE(HSUSBD_CEPCTL_NAKCLR);
                HSUSBD_ENABLE_CEP_INT(HSUSBD_CEPINTEN_STSDONEIEN_Msk);
                return 1U;

            default:
                HSUSBD_SET_CEP_STATE(HSUSBD_CEPCTL_STALLEN_Msk);
                return 1U;
        }
    }
}

/*---------------------------------------------------------------------------*/
/* Commands                                                                  */
/*---------------------------------------------------------------------------*/

static void CmdHelp(void)
{
    CdcPuts("\n"
            "commands:\n"
            "  help              this list\n"
            "  stat              sample rate / DMIC channel / gain / USB state\n"
            "  ch <n>            enable DMIC channel n only\n"
            "  edge f|r          latch PDM data on falling / rising edge\n"
            "  gain <dB>         DMIC DSP gain, 0..36\n"
            "  osr <n>           downsample 64 | 100 | 128 | 256\n"
            "  led y|g on|off    drive a user LED\n"
            "  key               read the user button\n");
}

static void CmdStat(void)
{
    CdcPrintf("\nboard      : %s\n", s_sCfg.pszBoardName);
    CdcPrintf("console    : %s + USB CDC\n", s_sCfg.pszConsolePins);
    CdcPrintf("format     : %u Hz, %u ch, 16-bit\n",
              (unsigned)AUDIO_RATE, (unsigned)REC_CHANNELS);
    CdcPrintf("DMIC pair  : channels %u/%u\n",
              (unsigned)s_sCfg.u32DmicChBase, (unsigned)(s_sCfg.u32DmicChBase + 1U));
    CdcPrintf("DMIC ch    : %u\n", (unsigned)s_u32ActiveCh);
    CdcPrintf("latch edge : %s\n", s_u32ActiveEdgeIsRising ? "rising" : "falling");
    CdcPrintf("DSP gain   : %d dB\n", (int)s_i32ActiveGain);
    CdcPrintf("oversample : %u  (PDM clk = %u Hz)\n",
              (unsigned)s_u32ActiveOsr, (unsigned)(AUDIO_RATE * s_u32ActiveOsr));
    CdcPrintf("DMIC CTL   : 0x%08X\n", (unsigned)DMIC0->CTL);
    CdcPrintf("USB audio  : %s\n",
              (g_usbd_UsbAudioState == UAC_START_AUDIO_RECORD) ? "streaming" :
              (HSUSBD_IS_ATTACHED() ? "attached" : "unplugged"));
    CdcPrintf("CDC dropped: %u bytes, %u stalled packet(s) abandoned\n",
              (unsigned)s_u32Dropped, (unsigned)s_u32TxAborts);
}

static void CmdCh(const char *pcArg)
{
    uint32_t u32Ch;

    if ((pcArg == NULL) || (*pcArg == '\0'))
    {
        CdcPrintf("ch: current %u (usage: ch 0..3)\n", (unsigned)s_u32ActiveCh);
        return;
    }

    u32Ch = (uint32_t)atoi(pcArg);

    if (u32Ch > 3U)
    {
        CdcPuts("ch: channel must be 0..3\n");
        return;
    }

    /* Disable every channel, then enable just the requested one. */
    DMIC_DisableChMsk(DMIC0, s_au32ChMsk[0] | s_au32ChMsk[1] |
                      s_au32ChMsk[2] | s_au32ChMsk[3]);
    DMIC_EnableChMsk(DMIC0, s_au32ChMsk[u32Ch]);
    s_u32ActiveCh = u32Ch;

    CdcPrintf("ch: now %u (CTL=0x%08X)\n", (unsigned)u32Ch, (unsigned)DMIC0->CTL);

    if ((u32Ch / 2U) != (s_sCfg.u32DmicChBase / 2U))
        CdcPuts("ch: WARNING - that channel belongs to the other PDM pin pair,\n"
                "    which is not wired to a microphone on this board.\n");
}

static void CmdEdge(const char *pcArg)
{
    uint32_t u32Rising;

    if ((pcArg == NULL) || ((*pcArg != 'f') && (*pcArg != 'r')))
    {
        CdcPuts("edge: usage: edge f|r\n");
        return;
    }

    u32Rising = (*pcArg == 'r') ? 1U : 0U;

    if (s_sCfg.u32DmicChBase == 0U)
        DMIC_SET_LATCHEDGE_CH01(DMIC0, u32Rising ? DMIC_LATCHDATA_CH01R
                                : DMIC_LATCHDATA_CH01F);
    else
        DMIC_SET_LATCHEDGE_CH23(DMIC0, u32Rising ? DMIC_LATCHDATA_CH23R
                                : DMIC_LATCHDATA_CH23F);

    s_u32ActiveEdgeIsRising = u32Rising;
    CdcPrintf("edge: now %s (CTL=0x%08X)\n",
              u32Rising ? "rising" : "falling", (unsigned)DMIC0->CTL);
}

static void CmdGain(const char *pcArg)
{
    int32_t i32Db;

    if ((pcArg == NULL) || (*pcArg == '\0'))
    {
        CdcPrintf("gain: current %d dB (usage: gain 0..36)\n", (int)s_i32ActiveGain);
        return;
    }

    i32Db = (int32_t)atoi(pcArg);

    if ((i32Db < 0) || (i32Db > 36))
    {
        CdcPuts("gain: must be 0..36 dB\n");
        return;
    }

    DMIC_SetDSPGainVolume(DMIC0, DMIC_MIC_GAIN_CH_MSK, i32Db);
    s_i32ActiveGain = i32Db;
    CdcPrintf("gain: now %d dB\n", (int)i32Db);
}

static void CmdOsr(const char *pcArg)
{
    uint32_t u32Osr;
    uint32_t u32Sel;

    if ((pcArg == NULL) || (*pcArg == '\0'))
    {
        CdcPrintf("osr: current %u (usage: osr 64|100|128|256)\n",
                  (unsigned)s_u32ActiveOsr);
        return;
    }

    u32Osr = (uint32_t)atoi(pcArg);

    switch (u32Osr)
    {
        case 64U:  u32Sel = DMIC_DOWNSAMPLE_64;  break;
        case 100U: u32Sel = DMIC_DOWNSAMPLE_100; break;
        case 128U: u32Sel = DMIC_DOWNSAMPLE_128; break;
        case 256U: u32Sel = DMIC_DOWNSAMPLE_256; break;

        default:
            CdcPuts("osr: must be 64, 100, 128 or 256\n");
            return;
    }

    DMIC_SET_DOWNSAMPLE(DMIC0, u32Sel);
    (void)DMIC_SetSampleRate(DMIC0, AUDIO_RATE);
    s_u32ActiveOsr = u32Osr;

    CdcPrintf("osr: now %u, PDM clock %u Hz\n",
              (unsigned)u32Osr, (unsigned)(AUDIO_RATE * u32Osr));

    if (u32Osr == 64U)
        CdcPuts("osr: WARNING - 1.024 MHz is below the MP34DT05-M 1.2 MHz minimum;\n"
                "     the microphone may enter power-down mode.\n");
    else if (u32Osr == 256U)
        CdcPuts("osr: NOTE - 4.096 MHz exceeds the MP34DT05-M 3.25 MHz maximum.\n");
}

static void CmdLed(const char *pcColour, const char *pcState)
{
    uint32_t u32Idx;
    uint32_t u32On;

    if ((pcColour == NULL) || (pcState == NULL))
    {
        CdcPuts("led: usage: led y|g on|off\n");
        return;
    }

    if (*pcColour == 'y')      u32Idx = 0U;
    else if (*pcColour == 'g') u32Idx = 1U;
    else
    {
        CdcPuts("led: colour must be y or g\n");
        return;
    }

    if (u32Idx >= s_sCfg.u32LedCount)
    {
        CdcPrintf("led: this board only has %u user LED(s)\n",
                  (unsigned)s_sCfg.u32LedCount);
        return;
    }

    u32On = (strncmp(pcState, "on", 2) == 0) ? 1U : 0U;

    if (s_sCfg.pfnLedSet != NULL)
        s_sCfg.pfnLedSet(u32Idx, u32On);

    CdcPrintf("led: %s = %s\n", (u32Idx == 0U) ? "yellow" : "green",
              u32On ? "on" : "off");
}

static void CmdKey(void)
{
    if (s_sCfg.pfnKeyRead == NULL)
    {
        CdcPuts("key: not supported on this board\n");
        return;
    }

    CdcPrintf("key: %s\n", s_sCfg.pfnKeyRead() ? "PRESSED" : "released");
}

/*---------------------------------------------------------------------------*/
/* Line handling                                                             */
/*---------------------------------------------------------------------------*/

/* Split a line into at most u32MaxTok whitespace-separated tokens, in place.
   Hand-rolled because strtok_r is POSIX, not ISO C, and the ARM C library does
   not provide it under -std=c11; strtok() would work here (single-threaded,
   main context only) but leaves hidden static state, which is worse. */
static uint32_t SplitLine(char *pcLine, char *apcTok[], uint32_t u32MaxTok)
{
    uint32_t u32N = 0U;
    char    *pc   = pcLine;

    while ((*pc != '\0') && (u32N < u32MaxTok))
    {
        while ((*pc == ' ') || (*pc == '\t'))
            pc++;

        if (*pc == '\0')
            break;

        apcTok[u32N++] = pc;

        while ((*pc != '\0') && (*pc != ' ') && (*pc != '\t'))
            pc++;

        if (*pc != '\0')
            *pc++ = '\0';
    }

    return u32N;
}

static void ExecuteLine(char *pcLine)
{
    char *apcTok[3] = { NULL, NULL, NULL };
    char *pcCmd;
    char *pcArg1;
    char *pcArg2;

    if (SplitLine(pcLine, apcTok, 3U) == 0U)
    {
        CdcPuts("> ");
        return;
    }

    pcCmd  = apcTok[0];
    pcArg1 = apcTok[1];
    pcArg2 = apcTok[2];

    if      (strcmp(pcCmd, "help") == 0) CmdHelp();
    else if (strcmp(pcCmd, "?")    == 0) CmdHelp();
    else if (strcmp(pcCmd, "stat") == 0) CmdStat();
    else if (strcmp(pcCmd, "ch")   == 0) CmdCh(pcArg1);
    else if (strcmp(pcCmd, "edge") == 0) CmdEdge(pcArg1);
    else if (strcmp(pcCmd, "gain") == 0) CmdGain(pcArg1);
    else if (strcmp(pcCmd, "osr")  == 0) CmdOsr(pcArg1);
    else if (strcmp(pcCmd, "led")  == 0) CmdLed(pcArg1, pcArg2);
    else if (strcmp(pcCmd, "key")  == 0) CmdKey();
    else CdcPrintf("unknown command '%s' - try 'help'\n", pcCmd);

    CdcPuts("> ");
}

static void ProcessRxChar(char cCh)
{
    if ((cCh == '\r') || (cCh == '\n'))
    {
        CdcPuts("\n");
        s_acLine[s_u32LineLen] = '\0';
        ExecuteLine(s_acLine);
        s_u32LineLen = 0U;
        return;
    }

    if ((cCh == '\b') || (cCh == 0x7F))
    {
        if (s_u32LineLen > 0U)
        {
            s_u32LineLen--;
            CdcPuts("\b \b");        /* erase the character on the terminal */
        }

        return;
    }

    /* Ignore anything that is not printable ASCII. */
    if ((cCh < 0x20) || (cCh > 0x7E))
        return;

    if (s_u32LineLen >= CONSOLE_LINE_MAX)
        return;                      /* line too long - swallow the rest */

    /* Fold command names to lower case so "STAT" works like "stat". */
    if ((cCh >= 'A') && (cCh <= 'Z'))
        cCh = (char)(cCh - 'A' + 'a');

    s_acLine[s_u32LineLen++] = cCh;
    CdcConsole_Write(&cCh, 1U);      /* echo */
}

/*---------------------------------------------------------------------------*/
/* Pump                                                                      */
/*---------------------------------------------------------------------------*/

/* 11-bit USB frame counter, one tick per millisecond, driven by the host's SOF.
   Free-running and read-only, so it costs nothing to use as a time base. */
static uint16_t FrameNow(void)
{
    return (uint16_t)((HSUSBD->FRAMECNT & HSUSBD_FRAMECNT_FRAMECNT_Msk)
                      >> HSUSBD_FRAMECNT_FRAMECNT_Pos);
}

/* Abandon a queued bulk IN packet and make the endpoint usable again.
 *
 * Read-modify-write so HALT (bit 4) survives; a bare store would silently
 * un-halt a stalled endpoint. This is the BSP idiom (massstorage.c:166,
 * hid_transfer_and_msc.c:173). Every latched status bit is cleared too - see
 * the comment on EPB_INTSTS_ALL. */
static void TxAbort(void)
{
    HSUSBD->EP[EPB].EPRSPCTL = (HSUSBD->EP[EPB].EPRSPCTL & HSUSBD_EPRSPCTL_HALT_Msk)
                               | HSUSBD_EP_RSPCTL_FLUSH;
    HSUSBD_ENABLE_EP_INT(EPB, 0U);
    HSUSBD_CLR_EP_INT_FLAG(EPB, EPB_INTSTS_ALL);
    s_u8TxBusy    = 0U;
    s_u8TxNeedZlp = 0U;
}

/* Move up to one bulk packet from the TX ring into EPB. Main context only.
 *
 * NO CRITICAL SECTION - deliberately. The TX ring is single-producer /
 * single-consumer: producers only advance s_u32TxHead (each under its own mask,
 * in CdcConsole_Write()), and this is the only writer of s_u32TxTail. Masking
 * the FIFO burst never protected anything anyway - __disable_irq() masks the
 * Cortex-M core, not the USB engine, which may start streaming this endpoint
 * buffer at any instant. What protects the endpoint is the BUFEMPTYIF / TXPKIF
 * protocol below, which is what every working HSUSBD bulk-IN sample uses.
 */
static void TxKick(void)
{
    uint8_t  au8Pkt[EPB_MAX_PKT_SIZE];
    uint32_t u32Head;
    uint32_t u32Len = 0U;
    uint32_t i;

    if (s_u8PortOpen == 0U)
        return;

    /* THE authoritative "may I write?" test. BUFEMPTYIF (EPINTSTS bit 1) is a
       read-only level flag: for an IN endpoint it means a buffer is free for
       the local side to fill. Every working BSP bulk-IN sample gates on it
       before every load (massstorage.c:747/773/796,
       hid_transfer_and_msc.c:840/866/889). It supersedes s_u8TxBusy - if the
       controller says the buffer is empty, the previous packet is gone,
       whatever the software flag believes. */
    if ((HSUSBD->EP[EPB].EPINTSTS & HSUSBD_EPINTSTS_BUFEMPTYIF_Msk) == 0U)
    {
        /* Buffer still occupied. Only abandon it if the host has genuinely
           stopped collecting. FRAMECNT is 11 bits and wraps every 2.048 s; the
           mask makes the subtraction modular so this survives a wrap. */
        uint16_t u16Elapsed = (uint16_t)((FrameNow() - s_u16TxKickFrame) & 0x7FFU);

        if (s_u8TxBusy && (u16Elapsed >= CONSOLE_TX_STALL_FRAMES))
        {
            TxAbort();
            s_u32TxAborts++;
        }

        return;
    }

    s_u8TxBusy = 0U;            /* the hardware says the endpoint is free */

    u32Head = s_u32TxHead;

    if (s_u32TxTail == u32Head)
    {
        /* Nothing to send. A bulk transfer whose length is an exact multiple of
           wMaxPacketSize is not terminated until a short or zero-length packet
           arrives, so close a previous full-size packet with a ZLP - otherwise
           the usbser.sys read IRP stays outstanding and the terminal shows a
           truncated line. HSUSBD_VCOM_SerialEmulator does the same
           (main.c:215-222). */
        if (s_u8TxNeedZlp)
        {
            s_u8TxNeedZlp    = 0U;
            s_u8TxBusy       = 1U;
            s_u16TxKickFrame = FrameNow();
            HSUSBD_CLR_EP_INT_FLAG(EPB, EPB_INTSTS_ALL);
            HSUSBD->EP[EPB].EPRSPCTL =
                (HSUSBD->EP[EPB].EPRSPCTL & HSUSBD_EPRSPCTL_HALT_Msk)
                | HSUSBD_EP_RSPCTL_SHORTTXEN | HSUSBD_EP_RSPCTL_ZEROLEN;
            HSUSBD_ENABLE_EP_INT(EPB, HSUSBD_EPINTEN_TXPKIEN_Msk);
        }

        return;
    }

    /* ---------------------------------------------------------------------
     * Historical note - this block used to run under __disable_irq().
     *
     * The theory was that the shared HSUSBD DMA engine (armed once a
     * millisecond from the LPPDMA ISR by UAC_SendRecData(), see
     * Device/DMICRecord/DMICRecord.c) was colliding with these FIFO writes.
     * That theory was disproved on hardware: the device died with
     * g_usbd_UsbAudioState == 0, i.e. with no audio DMA running at all, and
     * adding the mask changed nothing.
     *
     * The mask was never protection in any case - __disable_irq() masks the
     * Cortex-M core, not the USB engine, which can begin streaming this
     * endpoint buffer at any instant. Worse, it actively contributed to the
     * real bug: IN tokens arriving during the masked FIFO burst latched INTKIF
     * without reaching the NVIC, and the ENABLE_EP_INT(INTKIEN) that followed
     * then fired the handler instantly on that stale flag, for a packet the
     * host had not collected.
     *
     * The correct interlock is the BUFEMPTYIF precondition above plus TXPKIF
     * completion below - what HSUSBD_MassStorage_SRAM and
     * HSUSBD_HID_Transfer_And_MSC both do on their bulk IN endpoints.
     * ------------------------------------------------------------------- */

    /* Snapshot out of the ring BEFORE touching the endpoint, so a producer
       running from an ISR can never mutate bytes that are already mid-flight
       into the FIFO. */
    while ((s_u32TxTail != u32Head) && (u32Len < EPB_MAX_PKT_SIZE))
    {
        au8Pkt[u32Len++] = (uint8_t)s_acTxRing[s_u32TxTail];
        s_u32TxTail = (s_u32TxTail + 1U) & (CONSOLE_TX_RING_SIZE - 1U);
    }

    /* Claim the endpoint before the first FIFO write, and clear every latched
       status bit before arming. Nothing can have been transmitted yet, so this
       cannot discard a real completion - but it does discard the IN tokens that
       latched while EPINTEN was 0, which is the bug that killed this device. */
    s_u8TxBusy       = 1U;
    s_u16TxKickFrame = FrameNow();
    s_u8TxNeedZlp    = (uint8_t)((u32Len == EPB_MAX_PKT_SIZE) ? 1U : 0U);
    HSUSBD_CLR_EP_INT_FLAG(EPB, EPB_INTSTS_ALL);

    for (i = 0U; i < u32Len; i++)
        HSUSBD->EP[EPB].EPDAT_BYTE = au8Pkt[i];

    /* MODE_AUTO already committed the packet when the 64th byte landed.
       SHORTTXEN is applicable only to the auto-validate method and only for a
       sub-MPS remainder, and it self-clears once the packet is sent - so
       asserting it over an already-emptied buffer leaves it latched to validate
       the first byte of the NEXT packet. Assert it only for a genuine short
       packet, preserving HALT (massstorage.c:164-166).

       EPTXCNT is the MANUAL-validate mechanism and is deliberately NOT written
       any more: running auto-validate and manual-validate over one packet
       double-commits it. Neither massstorage nor monitor-bulk writes EPTXCNT on
       an auto-validate endpoint. */
    if (u32Len < EPB_MAX_PKT_SIZE)
        HSUSBD->EP[EPB].EPRSPCTL =
            (HSUSBD->EP[EPB].EPRSPCTL & HSUSBD_EPRSPCTL_HALT_Msk)
            | HSUSBD_EP_RSPCTL_SHORTTXEN;

    /* TXPKIEN, not INTKIEN. INTKIF means only that a Data IN token has been
       received - it is set at token time, before any data leaves, and it is set
       even for tokens the endpoint NAKs. TXPKIF means the packet actually went
       out. massstorage.c:742/768/791 and hid_transfer_and_msc.c:835/861/884 use
       TXPKIEN on their bulk IN endpoints, and our own EPA already uses it. */
    HSUSBD_ENABLE_EP_INT(EPB, HSUSBD_EPINTEN_TXPKIEN_Msk);

}

void CdcConsole_Poll(void)
{
    static uint8_t u8WasOpen = 0U;

    if (s_u32Inited == 0U)
        return;


    /* Greet the terminal the first time the host opens the port. */
    if (s_u8PortOpen && (u8WasOpen == 0U))
    {
        u8WasOpen = 1U;
        CdcPrintf("\n=== %s : USB CDC console ===\n", s_sCfg.pszBoardName);

        if (s_u32Dropped != 0U)
            CdcPrintf("(%u bytes of start-up output were dropped before the port"
                      " was opened)\n", (unsigned)s_u32Dropped);

        CdcPuts("type 'help' for commands\n> ");
    }
    else if ((s_u8PortOpen == 0U) && u8WasOpen)
    {
        u8WasOpen = 0U;
    }

    /* Consume anything the host typed. */
    while (s_u32RxTail != s_u32RxHead)
    {
        char cCh = s_acRxRing[s_u32RxTail];
        s_u32RxTail = (s_u32RxTail + 1U) & (CONSOLE_RX_RING_SIZE - 1U);
        ProcessRxChar(cCh);
    }

    TxKick();
}

/*---------------------------------------------------------------------------*/
void CdcConsole_Init(const S_CONSOLE_CFG *psCfg)
{
    if (psCfg == NULL)
        return;

    s_sCfg        = *psCfg;
    s_u32ActiveCh = psCfg->u32DmicChBase;
    s_u32TxHead   = 0U;
    s_u32TxTail   = 0U;
    s_u32RxHead   = 0U;
    s_u32RxTail   = 0U;
    s_u32Dropped  = 0U;
    s_u8TxBusy    = 0U;
    s_u8TxNeedZlp = 0U;
    s_u32TxAborts = 0U;
    s_u16TxKickFrame = 0U;
    s_u8PortOpen  = 0U;
    s_u32LineLen  = 0U;
    s_u32Inited   = 1U;
}
