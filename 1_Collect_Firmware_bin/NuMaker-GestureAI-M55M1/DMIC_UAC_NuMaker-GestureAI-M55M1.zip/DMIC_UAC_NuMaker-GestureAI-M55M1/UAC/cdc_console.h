/**************************************************************************//**
 * @file     cdc_console.h
 * @version  V1.00
 * @brief    USB CDC-ACM console + command line for the DMIC_UAC sample.
 *
 * BOARD-INDEPENDENT ON PURPOSE. Everything board specific arrives through
 * S_CONSOLE_CFG, so this file and cdc_console.c are byte-identical between the
 * NuMaker-VoiceAI-M55M1 and NuMaker-GestureAI-M55M1 builds of this sample.
 * Keep it that way: put board differences in BoardInit.c, never here.
 *
 * The console shares the HSUSBD controller with the UAC 1.0 microphone; see
 * the header of cdc_console.c for why every write path here is non-blocking.
 *
 * @copyright SPDX-License-Identifier: Apache-2.0
 ******************************************************************************/
#ifndef __CDC_CONSOLE_H__
#define __CDC_CONSOLE_H__

#include <stdint.h>
#include "NuMicro.h"

#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------------------------------------------------------*/
/* CDC-ACM class requests (bRequest)                                         */
/*---------------------------------------------------------------------------*/
#define CDC_SET_LINE_CODE           0x20
#define CDC_GET_LINE_CODE           0x21
#define CDC_SET_CONTROL_LINE_STATE  0x22

/*---------------------------------------------------------------------------*/
/* Board description supplied by BoardInit.c                                 */
/*---------------------------------------------------------------------------*/
typedef struct
{
    /** Shown in the console banner, e.g. "NuMaker-VoiceAI-M55M1". */
    const char *pszBoardName;

    /** Human-readable console pin description for the banner, e.g.
     *  "UART4, PB.11 TXD / PB.10 RXD (header J3)". */
    const char *pszConsolePins;

    /** Lowest DMIC channel of the PDM pin pair this board wires the mic to:
     *  0 for the DMIC0_CLK/DMIC0_DAT pair (channels 0/1, NuMaker-VoiceAI),
     *  2 for the DMIC1_CLK/DMIC1_DAT pair (channels 2/3, NuMaker-GestureAI).
     *  The "ch" and "edge" commands use it to pick the right register field. */
    uint32_t u32DmicChBase;

    /** Number of user LEDs the board has (1 or 2). */
    uint32_t u32LedCount;

    /** Drive a user LED. u32Idx 0 = yellow, 1 = green. */
    void (*pfnLedSet)(uint32_t u32Idx, uint32_t u32On);

    /** Read the user button: 1 = pressed. */
    uint32_t (*pfnKeyRead)(void);
} S_CONSOLE_CFG;

/*---------------------------------------------------------------------------*/
/* API                                                                       */
/*---------------------------------------------------------------------------*/

/** Initialise the console. Call once, after BoardInit() has brought up the
 *  debug UART and before UAC_Init() configures the endpoints. */
void CdcConsole_Init(const S_CONSOLE_CFG *psCfg);

/** Queue bytes for the USB console. NEVER blocks: if the ring is full the
 *  bytes are dropped and an internal counter is incremented. Safe to call from
 *  an interrupt handler. */
void CdcConsole_Write(const char *pcData, uint32_t u32Len);

/** Pump the console: pushes queued output to the bulk IN endpoint and executes
 *  any command line received on the bulk OUT endpoint. Call from the main loop
 *  as often as convenient - it returns immediately when there is nothing to do. */
void CdcConsole_Poll(void);

/** 1 once the host has asserted DTR, i.e. opened the COM port. */
uint32_t CdcConsole_IsOpen(void);

/** Number of bytes dropped because the TX ring was full. */
uint32_t CdcConsole_Dropped(void);

/*---------------------------------------------------------------------------*/
/* HSUSBD glue - called from usbd_audio.c                                    */
/*---------------------------------------------------------------------------*/
void CdcConsole_EpbHandler(void);       /**< bulk IN  (console TX) done      */
void CdcConsole_EpcHandler(void);       /**< bulk OUT (console RX) received  */
void CdcConsole_ConfigEndpoints(void);  /**< HSUSBD_ConfigEp for EPB/EPC/EPD */
void CdcConsole_BusReset(void);         /**< drop DTR, abort in-flight TX    */

/** Handle a CDC class request. Returns 1 if the request was consumed, 0 if it
 *  is not addressed to the CDC function and the caller should handle it. */
uint32_t CdcConsole_ClassRequest(void);

/*---------------------------------------------------------------------------*/
/* printf routing                                                            */
/*---------------------------------------------------------------------------*/

/** printf() that fans out to BOTH the debug UART and the USB console. */
void Console_Printf(const char *fmt, ...);

/* Redirect printf in the project's own translation units so that every
 * existing (and future) printf appears on the USB console as well as the UART,
 * with no call-site edits.
 *
 * This deliberately does NOT touch the BSP: Library/StdDriver/src/retarget.c
 * and system_M55M1.c do not include this header, so their printf keeps going
 * straight to the UART, and retarget.c stays in the build unmodified (it also
 * supplies ProcessHardFault and the semihosting plumbing).
 *
 * INCLUDE THIS HEADER LAST, after <stdio.h>, or the macro will rewrite the
 * declaration of printf inside stdio.h itself.
 *
 * Limit: one Console_Printf() call renders at most 159 characters (see
 * CONSOLE_FMT_BUF in cdc_console.c). The longest line in this project is ~70. */
#ifndef CDC_CONSOLE_NO_PRINTF_REDIRECT
    #undef printf
    #define printf(...)   Console_Printf(__VA_ARGS__)
#endif

#ifdef __cplusplus
}
#endif

#endif /* __CDC_CONSOLE_H__ */
