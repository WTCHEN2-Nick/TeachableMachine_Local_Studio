/**************************************************************************//**
 * @file     BoardInit.h
 * @version  V2.00
 * @brief    NuMaker-GestureAI-M55M1 board related functions
 *
 * @copyright SPDX-License-Identifier: Apache-2.0
 * @copyright Copyright (C) 2023 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/
#ifndef __BOARD_INIT_H__
#define __BOARD_INIT_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/** Status LEDs. NuMaker-GestureAI-M55M1 has one, where NuMaker-VoiceAI-M55M1
 *  has two - hence the index argument on the LED calls below. The enum is kept
 *  identical in both builds so cdc_console.c can stay board-independent; on
 *  this board BOARD_LED_COUNT is 1 and the "led g" command is refused. */
typedef enum
{
    BOARD_LED_Y = 0,    /*!< Yellow LED_Y on PA.7, active low */
    BOARD_LED_COUNT
} E_BOARD_LED;

/**
  * @brief Initiate the hardware resources
  * @return 0: Success, <0: Fail
  * @details Initiate clock, debug UART5, DMIC1 pins (PB.2/PB.3), HSUSBD PHY,
  *          status LED (PA.7) and user button (PA.4).
  */
int BoardInit(void);

/**
  * @brief Drive one of the status LEDs (active low on this board)
  * @param[in] u32Led One of E_BOARD_LED
  * @param[in] u32On  0 = off, non-zero = lit
  */
void BoardLedSet(uint32_t u32Led, uint32_t u32On);

/**
  * @brief Toggle one of the status LEDs
  * @param[in] u32Led One of E_BOARD_LED
  */
void BoardLedToggle(uint32_t u32Led);

/**
  * @brief Read the user button (BTN2, PA.4, active low)
  * @return 1 when pressed, 0 when released
  */
uint32_t BoardKeyPressed(void);

#ifdef __cplusplus
}
#endif

#endif
