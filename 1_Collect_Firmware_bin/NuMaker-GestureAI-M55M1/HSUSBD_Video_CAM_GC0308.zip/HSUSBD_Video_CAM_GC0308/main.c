/**************************************************************************//**
 * @file     main.c
 * @version  V1.00
 * @brief    Simulate an USB Video Class
 *
 ******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include "NuMicro.h"
#include "uvc.h"
#include "sensor.h"

/*---------------------------------------------------------------------------------------------------------*/
/* UART1 Console (TX=PA.9, RX=PA.8): non-blocking RX while UVC streaming                                   */
/*---------------------------------------------------------------------------------------------------------*/
#define CONSOLE_UART     UART1
#define CONSOLE_BAUDRATE 115200

static inline void Console_PutChar(uint8_t ch)
{
    while (UART_IS_TX_FULL(CONSOLE_UART)) { }

    UART_WRITE(CONSOLE_UART, ch);
}

/* Minimal printf -> UART1 (avoid semihost / avoid blocking USB) */
static int Console_Printf(const char *fmt, ...)
{
    char buf[256];
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);

    if (n < 0)
    {
        return n;
    }

    if (n >= (int)sizeof(buf))
    {
        n = (int)sizeof(buf) - 1;
    }

    for (int i = 0; i < n; i++)
    {
        if (buf[i] == '\n')
        {
            Console_PutChar('\r');
        }

        Console_PutChar((uint8_t)buf[i]);
    }

    return n;
}

/* Route printf() in this file to UART1 */
#define printf Console_Printf


/*---------------------------------------------------------------------------------------------------------*/
/* Define global variables and constants                                                                   */
/*---------------------------------------------------------------------------------------------------------*/
#define SENSOR_IN_WIDTH             640
#define SENSOR_IN_HEIGHT            480
#define SYSTEM_WIDTH                320
#define SYSTEM_HEIGHT               240


/*---------------------------------------------------------------------------------------------------------*/
/* 步進馬達定義與變數                                                                                      */
/*---------------------------------------------------------------------------------------------------------*/

// 步進馬達 GPIO 定義 (假設 ULN2003 IN1~IN4 接到 PA.0 ~ PA.3)
#define ULN2003_IN1_PORT     PB
#define ULN2003_IN1_PIN      BIT5
#define ULN2003_IN2_PORT     PB
#define ULN2003_IN2_PIN      BIT4
#define ULN2003_IN3_PORT     PB
#define ULN2003_IN3_PIN      BIT0
#define ULN2003_IN4_PORT     PB
#define ULN2003_IN4_PIN      BIT1

// 步進控制變數
volatile uint8_t g_u8StepCounter = 0;
volatile int32_t g_i32Direction = 1; // 1: CW, -1: CCW
// ** 新增計數與角度變數 **
volatile int32_t g_i32TotalSteps = 0; // 總執行步數
#define STEPS_PER_REV 1030 // 28BYJ-48 步進馬達標準齒輪比後的步數 (全步進約 512 步)
#define STEP_ANGLE_X100 9000/550 // 步距角 x 100 (例如 0.703125度 -> 70)
volatile int32_t g_i32CurrentAngleX100; // 目前角度 x 100 (避免浮點數運算)

// 非阻塞步進控制（避免主迴圈被 MoveSteps 卡住，也避免 USB 影像串流被阻塞）
volatile int32_t g_i32MoveStepsRemaining = 0;     // >0: 還要走多少步
volatile uint8_t g_u8MoveActive = 0;             // 1: 正在走固定步數
volatile uint8_t g_u8ContinuousRun = 0;          // 1: 連續轉動模式 (C/R)
volatile uint8_t g_u8MoveDone = 0;               // 1: 固定步數移動完成（主迴圈讀取後清除）
volatile uint8_t g_u8AutoTestState = 0;          // 0: idle, 1: 進行 Step1, 2: 進行 Step2

/*---------------------------------------------------------------------------------------------------------*/
/* Timer0 GPIO trace (print Timer-driven GPIO states without printing inside ISR)                          */
/*---------------------------------------------------------------------------------------------------------*/
#define AUTO_TEST_CW_STEPS    (STEPS_PER_REV)
#define AUTO_TEST_CCW_STEPS   (550)

/*---------------------------------------------------------------------------------------------------------*/
/* Timer/Stepper trace (印出 IN1~IN4 的 4-bit pattern)                                                     */
/* - 不能在 TIMER0_IRQHandler printf（會影響 UVC），所以 ISR 只更新狀態，main loop 節流印出                 */
/*---------------------------------------------------------------------------------------------------------*/
#define TRACE_PRINT_DIV      (10u)   /* 每 N 次 step 印一次（太密會拖慢 UVC） */
#define TRACE_PRINT_MAX      (30u)   /* 每次收到指令後最多印幾筆（印完自動停止 trace） */

volatile uint8_t  g_u8LastStepIndex   = 0;   /* 最近一次 step index (0~3) */
volatile uint8_t  g_u8StepUpdated     = 0;   /* ISR 更新旗標 */
volatile uint8_t  g_u8TraceEnable     = 0;   /* 1: main loop 會印出 pattern */
volatile uint32_t g_u32TraceSteps     = 0;   /* step 計數（由 ISR 累加） */
volatile uint32_t g_u32TraceRemain    = 0;   /* 還要印幾筆（main loop 減） */


// 二相激磁 (Full Step) 訊號序列
const uint8_t g_FullStepSequence[4][4] =
{
    // IN1, IN2, IN3, IN4
    {1, 1, 0, 0}, // Step 0
    {0, 1, 1, 0}, // Step 1
    {0, 0, 1, 1}, // Step 2
    {1, 0, 0, 1}  // Step 3
};

/*---------------------------------------------------------------------------------------------------------*/
/* 步進馬達控制函式                                                                                        */
/*---------------------------------------------------------------------------------------------------------*/

void STEPPER_Stop(void)
{
    // 清除四個腳位 (設置為 LOW)
    PB->DOUT &= ~(ULN2003_IN1_PIN | ULN2003_IN2_PIN | ULN2003_IN3_PIN | ULN2003_IN4_PIN);
}

void STEPPER_DoStep(void)
{
    // 處理負數步進：(n + 4 + direction) % 4
    g_u8StepCounter = (g_u8StepCounter + 4 + g_i32Direction) % 4;
    uint8_t u8StepIndex = g_u8StepCounter;

    // 清除四個腳位
    PB->DOUT &= ~(ULN2003_IN1_PIN | ULN2003_IN2_PIN | ULN2003_IN3_PIN | ULN2003_IN4_PIN);

    // 設置高電位的腳位
    if (g_FullStepSequence[u8StepIndex][0] == 1)
    {
        PB->DOUT |= ULN2003_IN1_PIN;
    }

    if (g_FullStepSequence[u8StepIndex][1] == 1)
    {
        PB->DOUT |= ULN2003_IN2_PIN;
    }

    if (g_FullStepSequence[u8StepIndex][2] == 1)
    {
        PB->DOUT |= ULN2003_IN3_PIN;
    }

    if (g_FullStepSequence[u8StepIndex][3] == 1)
    {
        PB->DOUT |= ULN2003_IN4_PIN;
    }

    // ** 步數和角度計算 **
    if (g_i32Direction > 0)
    {
        g_i32TotalSteps--; // 順時針增加
        g_i32CurrentAngleX100 -= STEP_ANGLE_X100;
    }
    else
    {
        g_i32TotalSteps++; // 逆時針減少
        g_i32CurrentAngleX100 += STEP_ANGLE_X100;
    }


    /* --- Trace 更新（ISR 只記錄狀態，main loop 來印） --- */
    g_u8LastStepIndex = u8StepIndex;
    g_u8StepUpdated   = 1;
    g_u32TraceSteps++;
}

/**
 * @brief 讓馬達從當前位置移動到零位 (g_u32TotalSteps=0)
 *
 * @param u32StepsToMove 要移動的總絕對步數
 * @param i32TargetDirection 移動的方向 (1: CW, -1: CCW)
 */
/**
 * @brief 以「非阻塞」方式要求移動固定步數。
 *        真正的 stepping 由 TIMER0_IRQHandler 完成，因此不會卡住 USB 影像串流主迴圈。
 *
 * @param u32StepsToMove 要移動的總步數（正數）
 * @param i32TargetDirection 方向 (1: CW, -1: CCW)
 */
static inline uint8_t STEPPER_IsBusy(void)
{
    return (g_u8MoveActive || g_u8ContinuousRun);
}

void STEPPER_MoveSteps(int32_t u32StepsToMove, int32_t i32TargetDirection)
{
    if (u32StepsToMove <= 0)
    {
        return;
    }

    /* 進入固定步數模式：停止連續模式 */
    g_u8ContinuousRun = 0;

    /* 設定方向與剩餘步數（ISR 會消耗這個計數） */
    g_i32Direction = (i32TargetDirection >= 0) ? 1 : -1;
    g_i32MoveStepsRemaining = u32StepsToMove;
    g_u8MoveDone = 0;
    g_u8MoveActive = 1;

    /* 啟動 Timer0 讓 ISR 開始跑步進 */
    TIMER_Start(TIMER0);
}



void STEPPER_InitGPIO(void)
{
    SYS_UnlockReg();

    GPIO_SetMode(ULN2003_IN1_PORT, ULN2003_IN1_PIN, GPIO_MODE_OUTPUT);
    GPIO_SetMode(ULN2003_IN2_PORT, ULN2003_IN2_PIN, GPIO_MODE_OUTPUT);
    GPIO_SetMode(ULN2003_IN3_PORT, ULN2003_IN3_PIN, GPIO_MODE_OUTPUT);
    GPIO_SetMode(ULN2003_IN4_PORT, ULN2003_IN4_PIN, GPIO_MODE_OUTPUT);

    STEPPER_Stop();
    SYS_LockReg();
}
void PrintMenu(void)
{
    printf("\n+---------------------------------------+\n");
    printf("| Stepper Motor UART Control (12.5 Hz)  |\n");
    printf("+---------------------------------------+\n");
    printf("| Commands: 'C': CW, 'R': CCW, 'P': Pause/Stop, 'S': Speed, 'Z': CW x1, 'M': Menu, 'A': Auto Test Seq |\n"); // <-- 新增 'Z'
    printf("+---------------------------------------+\n");
}

/* 開始印出 Timer/Stepper 的 4-bit pattern（收到指令時呼叫） */
static inline void Trace_Start(void)
{
    g_u8TraceEnable  = 1;
    g_u32TraceRemain = TRACE_PRINT_MAX;
    g_u32TraceSteps  = 0;
    g_u8StepUpdated  = 0;
}

/* 停止印出 pattern */
static inline void Trace_Stop(void)
{
    g_u8TraceEnable  = 0;
    g_u32TraceRemain = 0;
}



/*
 * 非阻塞 getchar
 */
static inline int getchar_nb(void)
{
    /* UART1 non-blocking RX:
     * - 有資料才讀，沒有資料立刻回傳 -1
     * - 若偵測到 break/frame/parity/overrun 等錯誤，先清旗標避免一直噴雜訊
     */
    uint32_t sts = UART1->FIFOSTS;

    if (sts & (UART_FIFOSTS_BIF_Msk |
               UART_FIFOSTS_FEF_Msk |
               UART_FIFOSTS_PEF_Msk |
               UART_FIFOSTS_RXOVIF_Msk))
    {
        /* clear error flags */
        UART1->FIFOSTS = (UART_FIFOSTS_BIF_Msk |
                          UART_FIFOSTS_FEF_Msk |
                          UART_FIFOSTS_PEF_Msk |
                          UART_FIFOSTS_RXOVIF_Msk);
        return -1;
    }

    if (UART_IS_RX_READY(UART1))
    {
        int c = (int)UART_READ(UART1);

        /* 常見雜訊：0x00（RX 浮動/線路問題時會一直出現），先丟掉避免刷屏 */
        if (c == 0x00)
        {
            return -1;
        }

        return c;
    }

    return -1;
}

static void ProcessConsoleChar(char c)
{
    switch (c)
    {
        case 'a':
        case 'A':
            if (STEPPER_IsBusy())
            {
                /* 盡量避免大量 printf：會佔用 UART TX 時間，可能影響 UVC */
                printf(" -> Stepper is busy. Please stop first (P).\n");
            }
            else
            {
                printf(" -> Starting Auto Test Sequence...\n");
                printf(" -> 1. Moving CW by %d steps (1 Revolution)...\n", AUTO_TEST_CW_STEPS);
                g_u8AutoTestState = 1;
                Trace_Start();
                STEPPER_MoveSteps(AUTO_TEST_CW_STEPS, 1);
            }

            break;

        case 'c':
        case 'C':
            g_u8AutoTestState = 0;
            g_i32Direction = 1;
            g_u8MoveActive = 0;
            g_u8ContinuousRun = 1;
            Trace_Start();
            TIMER_Start(TIMER0);
            printf("[CMD] C: CW start (Timer0 running)\n");
            break;

        case 'r':
        case 'R':
            g_u8AutoTestState = 0;
            g_i32Direction = -1;
            g_u8MoveActive = 0;
            g_u8ContinuousRun = 1;
            Trace_Start();
            TIMER_Start(TIMER0);
            printf("[CMD] R: CCW start (Timer0 running)\n");
            break;

        case 'p':
        case 'P':
            TIMER_Stop(TIMER0);
            Trace_Stop();
            g_u8ContinuousRun = 0;
            g_u8MoveActive = 0;
            g_u8AutoTestState = 0;
            STEPPER_Stop();
            printf("[CMD] P: Stop\n");
            break;

        case 'z':
        case 'Z':
        {
            /* 範例：走固定步數（這裡沿用你原本的 275，可依需求改） */
            int32_t i32StepsToMove = 275;
            int32_t i32MoveDirection = 1;

            if (STEPPER_IsBusy())
            {
                printf(" -> Stepper is busy. Please stop first (P).\n");
            }
            else
            {
                g_u8AutoTestState = 0;
                Trace_Start();
                STEPPER_MoveSteps(i32StepsToMove, i32MoveDirection);
            }

            break;
        }

        case 'm':
        case 'M':
            PrintMenu();
            break;

        case 's':
        case 'S':
            /*
             * 原本 generate_pulse() 使用 SysTickDelay 會阻塞主迴圈，可能讓 UVC 掉幀。
             * 如果你真的需要固定寬度的脈衝，建議用另一顆 Timer/PWM 產生。
             * 這裡先保留為「不做事」或你可改成調整 Timer0 速度。
             */
            break;

        default:
            /* ignore */
            break;
    }
}

NVT_ITCM void TIMER0_IRQHandler(void)
{
    if (TIMER_GetIntFlag(TIMER0) == 1)
    {
        /* Clear Timer0 time-out interrupt flag */
        TIMER_ClearIntFlag(TIMER0);

        /* 固定步數移動優先，其次才是連續轉動 */
        if (g_u8MoveActive)
        {
            STEPPER_DoStep();

            if (g_i32MoveStepsRemaining > 0)
            {
                g_i32MoveStepsRemaining--;
            }

            if (g_i32MoveStepsRemaining <= 0)
            {
                g_u8MoveActive = 0;
                g_u8MoveDone = 1;      /* 通知主迴圈：移動完成 */
                TIMER_Stop(TIMER0);
                STEPPER_Stop();
            }
        }
        else if (g_u8ContinuousRun)
        {
            STEPPER_DoStep();
        }


        __DSB();
        __ISB();
    }
}

/* Buffer for Packet & Planar format */
static uint8_t u8FrameBuffer0[SENSOR_IN_WIDTH * SENSOR_IN_HEIGHT * 2] __attribute__((aligned(32)));
static uint8_t u8FrameBuffer1[SENSOR_IN_WIDTH * SENSOR_IN_HEIGHT * 2] __attribute__((aligned(32)));

extern volatile uint8_t   gAppConnected;
static volatile uint32_t  s_u32XferSize = 0;
static volatile uint32_t  s_u32XferBufAddr = 0;

volatile uint32_t g_u32Ticks = 0;

/*--------------------------------------------------------------------------*/
/* To run CCAPInterruptHandler, when CAP frame end interrupt                */
/*--------------------------------------------------------------------------*/
void CCAPInterruptHandler(void)
{
    /* UVC transfer counter */
    static uint32_t u32UVCXferIdx = 0;

    /* Current Frame Index */
    static uint32_t u32CurFrameIndex = 2;

    /* Current Format Index */
    static uint32_t u32CurFormatIndex = 1;

    /* Current Width & Height */
    static uint16_t u16CurWidth = 320, u16CurHeight = 240;

    uint32_t u32NextFrameBufferAddr;

    if (s_u32XferBufAddr == 0) // UVC ISO-IN IDLE
    {
        if (u32UVCXferIdx & 0x1u)
        {
            s_u32XferBufAddr = (uint32_t)u8FrameBuffer1;
            u32NextFrameBufferAddr = (uint32_t)u8FrameBuffer0;
        }
        else
        {
            s_u32XferBufAddr = (uint32_t)u8FrameBuffer0;
            u32NextFrameBufferAddr = (uint32_t)u8FrameBuffer1;
        }

        /* UVC_Foramt_YUY2 */
        switch (uvcStatus.FormatIndex)
        {
            case UVC_Format_YUY2:       /* UVC_Foramt_YUY2 */
            {
                s_u32XferSize = uvcStatus.MaxVideoFrameSize;

                if (u32CurFrameIndex != uvcStatus.FrameIndex || u32CurFormatIndex != uvcStatus.FormatIndex)
                {
                    /* Frame Size Changed */
                    switch (uvcStatus.FrameIndex)
                    {
                        case UVC_VGA:
                            u16CurWidth = 640;
                            u16CurHeight = 480;
                            break;

                        case UVC_QVGA:
                            u16CurWidth = 320;
                            u16CurHeight = 240;
                            break;

                        case UVC_QQVGA:
                            u16CurWidth = 160;
                            u16CurHeight = 120;
                            break;
                    }

                    /* Set VideoIn Setting for Frame Size */
                    ChangeFrame(TRUE, u32NextFrameBufferAddr, u16CurWidth, u16CurHeight);
                    u32CurFrameIndex = uvcStatus.FrameIndex;
                    u32CurFormatIndex = uvcStatus.FormatIndex;
                }
                else
                {
                    ChangeFrame(FALSE, u32NextFrameBufferAddr, u16CurWidth, u16CurHeight);
                }

                break;
            }

            default:
                break;
        }

        u32UVCXferIdx++;
    }
}

/*------------------------------------------------------------------------------------------*/
/*  CCAP_IRQHandler                                                                         */
/*------------------------------------------------------------------------------------------*/
NVT_ITCM void CCAP_IRQHandler(void)
{
    uint32_t u32IntStatus = CCAP_GET_INT_STS();

    if (CCAP_IsIntEnabled(CCAP_INT_VIEN_ENABLE) && (u32IntStatus & CCAP_INTSTS_VINTF_Msk) == CCAP_INTSTS_VINTF_Msk)
    {
        CCAPInterruptHandler();
        CCAP_CLR_INT_FLAG(CCAP_INTSTS_VINTF_Msk);   /* Clear Frame end interrupt */
    }

    if (CCAP_IsIntEnabled(CCAP_INT_ADDRMIEN_ENABLE) && (u32IntStatus & CCAP_INTSTS_ADDRMINTF_Msk) == CCAP_INTSTS_ADDRMINTF_Msk)
    {
        CCAP_CLR_INT_FLAG(CCAP_INTSTS_ADDRMINTF_Msk);   /* Clear Address match interrupt */
    }

    if (CCAP_IsIntEnabled(CCAP_INT_MEIEN_ENABLE) && (u32IntStatus & CCAP_INTSTS_MEINTF_Msk) == CCAP_INTSTS_MEINTF_Msk)
    {
        CCAP_CLR_INT_FLAG(CCAP_INTSTS_MEINTF_Msk);     /* Clear Memory error interrupt */
    }

    CCAP_EnableUpdate();

    // CPU read interrupt flag register to wait write(clear) instruction completement.
    u32IntStatus = CCAP_GET_INT_STS();
}

void CCAP_SetFreq(uint32_t u32CCAP_ClkSrc, uint32_t u32SensorFreq)
{
    int32_t  i32Div;
    uint32_t u32CCAP_Clk;

    /* Unlock protected registers */
    SYS_UnlockReg();

    /* Reset IP */
    SYS_ResetModule(SYS_CCAP0RST);

    if (u32CCAP_ClkSrc == CLK_CCAPSEL_CCAP0SEL_HIRC)
    {
        u32CCAP_Clk = __HIRC;
    }
    else if (u32CCAP_ClkSrc == CLK_CCAPSEL_CCAP0SEL_MIRC)
    {
        u32CCAP_Clk = CLK_GetMIRCFreq();
    }
    else if (u32CCAP_ClkSrc == CLK_CCAPSEL_CCAP0SEL_HCLK2)
    {
        u32CCAP_Clk = CLK_GetHCLK2Freq();
    }
    else if (u32CCAP_ClkSrc == CLK_CCAPSEL_CCAP0SEL_APLL0_DIV2)
    {
        u32CCAP_Clk = CLK_GetAPLL0ClockFreq() / 2;
    }
    else if (u32CCAP_ClkSrc == CLK_CCAPSEL_CCAP0SEL_HXT)
    {
        u32CCAP_Clk = CLK_GetHXTFreq();
    }
    else
    {
        printf("Invalid CCAP clock source !\n");
        return ;
    }

    if (u32SensorFreq <= u32CCAP_Clk)
    {
        i32Div = (u32CCAP_Clk / u32SensorFreq);

        if ((u32CCAP_Clk - u32SensorFreq * i32Div) == 0)
        {
            i32Div--;
        }
    }
    else
    {
        i32Div = 0;
    }

    CLK_SetModuleClock(CCAP0_MODULE, u32CCAP_ClkSrc, i32Div);

    /* Lock protected registers */
    SYS_LockReg();

    printf("CCAP   engine clock: %d Hz\n", u32CCAP_Clk);
    printf("Target sensor clock: %d Hz.\n", u32SensorFreq);
    printf("Actual sensor clock: %d Hz. Divider=%d+1\n", u32CCAP_Clk / (i32Div + 1), i32Div);
}

int32_t PacketFormatDownScale(S_SENSOR_INFO *psSensorInfo)
{
    /* Init CCAP clock and Sensor clock */
    CCAP_SetFreq(CLK_CCAPSEL_CCAP0SEL_HIRC, 12000000);

    /* Initialize sensor and set output format as YUV422 */
    if (psSensorInfo->pfnInitSensor(0) == FALSE)
    {
        printf("Init sensor failed !\n");
        return -1;
    }

    /* Enable External CCAP Interrupt */
    NVIC_EnableIRQ(CCAP_IRQn);
    NVIC_SetPriority(CCAP_IRQn, 1);

    /* Enable CCAP Frame End Interrupt */
    CCAP_EnableInt(CCAP_INT_VIEN_ENABLE);

    /* Set Cropping Window Vertical/Horizontal Starting Address and Cropping Window Size */
    CCAP_SetCroppingWindow(0, 0, psSensorInfo->m_u16Height, psSensorInfo->m_u16Width);

    /* Set Vsync polarity, Hsync polarity, pixel clock polarity, Sensor and CCAP format and Order */
    CCAP_OpenPipes(
        psSensorInfo->m_u32Polarity,
        psSensorInfo->m_u32InputFormat,
        CCAP_PKT_OUTFMT_YUV422,
        CCAP_PLN_DISABLED
    );

    /* Set System Memory Packet Base Address Register */
    CCAP_SetPacketBuf((uint32_t)u8FrameBuffer0);

    /* Set Packet Scaling Vertical/Horizontal Factor Register */
    CCAP_SetPacketScaling(SYSTEM_HEIGHT, psSensorInfo->m_u16Height, SYSTEM_WIDTH, psSensorInfo->m_u16Width);

    /* Set Packet Frame Output Pixel Stride Width */
    CCAP_SetPacketStride(SYSTEM_WIDTH);

    /* Start Image Capture Interface */
    CCAP_Start();

    return 0;
}

void SYS_Init(void)
{
    /* Unlock protected registers */
    SYS_UnlockReg();

    /*---------------------------------------------------------------------------------------------------------*/
    /* Init System Clock                                                                                       */
    /*---------------------------------------------------------------------------------------------------------*/

    /* Enable Internal RC 12MHz clock */
    CLK_EnableXtalRC(CLK_SRCCTL_HIRCEN_Msk);

    /* Enable External Crystal (HXT) */
    CLK_EnableXtalRC(CLK_SRCCTL_HXTEN_Msk);
    CLK_WaitClockReady(CLK_STATUS_HXTSTB_Msk);


    /* Waiting for Internal RC clock ready */
    CLK_WaitClockReady(CLK_STATUS_HIRCSTB_Msk);

    /* Switch SCLK clock source to APLL0 and Enable APLL0 220MHz clock */
    CLK_SetBusClock(CLK_SCLKSEL_SCLKSEL_APLL0, CLK_APLLCTL_APLLSRC_HXT, FREQ_220MHZ);

    /* Update System Core Clock */
    /* User can use SystemCoreClockUpdate() to calculate SystemCoreClock. */
    SystemCoreClockUpdate();

    /* Enable all GPIO clock */
    CLK_EnableModuleClock(GPIOA_MODULE);
    CLK_EnableModuleClock(GPIOB_MODULE);
    CLK_EnableModuleClock(GPIOC_MODULE);
    CLK_EnableModuleClock(GPIOD_MODULE);
    CLK_EnableModuleClock(GPIOE_MODULE);
    CLK_EnableModuleClock(GPIOF_MODULE);
    CLK_EnableModuleClock(GPIOG_MODULE);
    CLK_EnableModuleClock(GPIOH_MODULE);
    CLK_EnableModuleClock(GPIOI_MODULE);
    CLK_EnableModuleClock(GPIOJ_MODULE);

    /* Debug UART clock setting */
    SetDebugUartCLK();

    /* UART1 clock (console) */
    CLK_EnableModuleClock(UART1_MODULE);

    /* Enable HXT clock */
    CLK_EnableXtalRC(CLK_SRCCTL_HXTEN_Msk);
    CLK_WaitClockReady(CLK_STATUS_HXTSTB_Msk);

    /* Enable TIMER module clock */
    CLK_SetModuleClock(TMR0_MODULE, CLK_TMRSEL_TMR0SEL_HXT, 0);

    CLK_EnableModuleClock(TMR0_MODULE);

    /* Enable HSOTG module clock */
    CLK_EnableModuleClock(HSOTG0_MODULE);

    /* Select HSOTG PHY Reference clock frequency which is from HXT */
    HSOTG_SET_PHY_REF_CLK(HSOTG_PHYCTL_FSEL_24_0M);

    /* Set HSUSB role to HSUSBD */
    SET_HSUSBDROLE();

    /* Enable HSUSB PHY */
    SYS_Enable_HSUSB_PHY();

    /* Enable HSUSBD peripheral clock */
    CLK_EnableModuleClock(HSUSBD0_MODULE);

    /* Enable CCAP Clock */
    CLK_EnableModuleClock(CCAP0_MODULE);

    /*---------------------------------------------------------------------------------------------------------*/
    /* Init I/O Multi-function                                                                                 */
    /*---------------------------------------------------------------------------------------------------------*/
    SetDebugUartMFP();

    /* UART1 MFP: RXD=PA.8, TXD=PA.9 */
    SET_UART1_RXD_PA8();
    SET_UART1_TXD_PA9();
    /* RX idle should be high; enable pull-up to avoid floating RX */
    GPIO_SetPullCtl(PA, BIT8, GPIO_PUSEL_PULL_UP);



    /* Set multi-function pins for CCAP (64-pin) */
    SET_CCAP_DATA7_PA1();
    SET_CCAP_DATA6_PA0();
    SET_CCAP_DATA5_PC5();
    SET_CCAP_DATA4_PC4();
    SET_CCAP_DATA3_PA3();
    SET_CCAP_DATA2_PA2();
    SET_CCAP_DATA1_PB8();
    SET_CCAP_DATA0_PB7();
    SET_CCAP_HSYNC_PB9();
    SET_CCAP_VSYNC_PB10();
    SET_CCAP_SCLK_PB12();
    SET_CCAP_PIXCLK_PB13();


    SET_GPIO_PC1();
    SET_GPIO_PC0();
    SET_GPIO_PF6();


    /* Lock protected registers */
    SYS_LockReg();
}

/*------------------------------------------------------------------------------------------*/
/* Change VideoIN Setting for Frame size */
/*------------------------------------------------------------------------------------------*/
void ChangeFrame(char bChangeSize, uint32_t u32Address, uint16_t u16Width, uint16_t u16Height)
{
    if (bChangeSize)    /* Change Frame Size */
    {
        CCAP_SetPacketScaling(u16Height, SENSOR_IN_HEIGHT, u16Width, SENSOR_IN_WIDTH);
    }

    /* Set Buffer Address */
    CCAP_SetPacketBuf((uint32_t)u32Address);
    CCAP_SetPacketStride(u16Width);
}

void SysTick_Handler(void)
{
    /* Increment the cycle counter based on load value. */
    g_u32Ticks ++;
}

int Init_SysTick_Export(void)
{
    const uint32_t ticks_10ms = SystemCoreClock / 1000 + 1;
    int err = 0;

    /* Reset CPU cycle count value. */
    g_u32Ticks = 0;

    /* Changing configuration for sys tick => guard from being
     * interrupted. */
    NVIC_DisableIRQ(SysTick_IRQn);

    /* SysTick init - this will enable interrupt too. */
    err = SysTick_Config(ticks_10ms);
    NVIC_SetPriority(SysTick_IRQn, 3);

    /* Enable interrupt again. */
    NVIC_EnableIRQ(SysTick_IRQn);

    /* Wait for SysTick to kick off */
    while (!err && !SysTick->VAL)
    {
        __NOP();
    }

    return err;
}
static uint64_t Get_SysTick_Cycle_Count(void) __attribute__((unused));
/**
 * Gets the current SysTick derived counter value
 */
static uint64_t Get_SysTick_Cycle_Count(void)
{
    uint32_t systick_val;

    NVIC_DisableIRQ(SysTick_IRQn);
    systick_val = SysTick->VAL & SysTick_VAL_CURRENT_Msk;
    NVIC_EnableIRQ(SysTick_IRQn);

    return g_u32Ticks + (SysTick->LOAD - systick_val);
}

int32_t main(void)
{
    uint32_t u32TimeVal, u32TimeVal_Vec;
    NVT_UNUSED(u32TimeVal), NVT_UNUSED(u32TimeVal_Vec);
    /* Init System, peripheral clock and multi-function I/O */
    SYS_Init();

    /* UART1 console init (TX=PA.9, RX=PA.8) */
    UART_Open(CONSOLE_UART, CONSOLE_BAUDRATE);

    STEPPER_InitGPIO();
    printf("NuMicro HSUSBD UVC YUV422 Streaming\n");

    printf("System core clock = %d\n", SystemCoreClock);
    printf("+--------------------------------------------+\n");
    printf("| Stepper Motor Control via TMR0 (12.5 Hz)   |\n");
    printf("+--------------------------------------------+\n\n");

    // [TMR0 馬達控制信息]
    printf("# TMR0 Settings (Stepper Control):\n");
    printf("    - Clock source is HXT (12MHz)\n");
    printf("    - Time-out frequency is 12.5 Hz (Prescale=99, CMP=9600)\n");
    printf("    - Periodic mode, Interrupt enable\n\n");

    /* -------------------------------------------------------------------- */
    /* TMR0 (步進馬達) 配置：實現精確 100 Hz (10 ms 間隔)                      */
    /* -------------------------------------------------------------------- */
    TIMER_Open(TIMER0, TIMER_PERIODIC_MODE, 1);
    // TMR0 Clock Source $F_{\text{in}}$ = 12 MHz
    // 設置 Prescale=99 -> (Prescale + 1) = 100
    TIMER0->CTL = (TIMER0->CTL & ~TIMER_CTL_PSC_Msk) | (99 << TIMER_CTL_PSC_Pos);
    // 設置 CMP=1200 -> $12\text{M} / 100 / 1200 = 100 \text{ Hz}$
    TIMER0->CMP = 2400UL;

    TIMER_EnableInt(TIMER0);
    NVIC_EnableIRQ(TIMER0_IRQn);
    NVIC_SetPriority(TIMER0_IRQn, 0);

    // 確保 TMR0 初始狀態為停止
    STEPPER_Stop();

    PrintMenu();

    //GPIO_SetMode(PH, BIT1, GPIO_MODE_OUTPUT);
    //PH1=0;
    /* Using Packet format to Image down scale */
    if (PacketFormatDownScale(&g_sSensorGC0308_VGA_YUV422) != 0)
    {
        printf("Capture frame failed !\n");
    }

    HSUSBD_Open(&gsHSInfo, UVC_ClassRequest, UVC_SetInterface);

    /* Endpoint configuration */
    UVC_Init();

    /* Enable HSUSBD interrupt */
    NVIC_EnableIRQ(HSUSBD_IRQn);
    NVIC_SetPriority(HSUSBD_IRQn, 2);

    /* Start transaction */
    while (1)
    {
        if (HSUSBD_IS_ATTACHED())
        {
            HSUSBD_Start();
            break;
        }
    }

    Init_SysTick_Export();

    while (1)
    {

        u32TimeVal = g_u32Ticks;

        if (gAppConnected == 1)
        {
            if (s_u32XferBufAddr) //Trigger ISO-IN DMA
            {
                #if (NVT_DCACHE_ON == 1)
                // Invalidate D-Cache to ensure CPU reads the latest image data written by CCAP
                SCB_InvalidateDCache_by_Addr((void *)s_u32XferBufAddr, s_u32XferSize);
                #endif
                UVC_SendImage(s_u32XferBufAddr, s_u32XferSize, uvcStatus.StillImage);
                s_u32XferBufAddr = 0;  // Set ISO-IN IDLE
            }
        }

        u32TimeVal_Vec = g_u32Ticks;

        //printf("Time = %d ms\n", (u32TimeVal_Vec - u32TimeVal));

        /* ------------------------------------------------------------ */
        /* Stepper non-blocking completion handling (won't block UVC)    */
        /* ------------------------------------------------------------ */
        if (g_u8MoveDone)
        {
            g_u8MoveDone = 0;

            if (g_u8AutoTestState == 1)
            {
                /* Step 1 complete -> start step 2 */
                g_i32TotalSteps = 0;
                g_i32CurrentAngleX100 = 0;
                printf(" *** Step1 Done. Reset angle/steps. ***\n");

                printf(" -> 2. Moving CCW by %d steps (Half Revolution)...\n", AUTO_TEST_CCW_STEPS);
                g_u8AutoTestState = 2;
                STEPPER_MoveSteps(AUTO_TEST_CCW_STEPS, -1);
            }
            else if (g_u8AutoTestState == 2)
            {
                /* Step 2 complete */
                g_u8AutoTestState = 0;
                printf(" -> Auto Test Sequence Complete.\n");
                printf(" *** Final Angel %d degree ***\n", g_i32CurrentAngleX100);
                printf(" *** Final Total Steps: %d steps ***\n", -g_i32TotalSteps);
            }
            else
            {
                /* Manual move complete */
                printf(" -> Move Done. Angle=%d, TotalSteps=%d\n", g_i32CurrentAngleX100, g_i32TotalSteps);
            }
        }


        /* ------------------------------------------------------------ */
        /* Trace: 印出 Timer0 正在打出的步進 GPIO pattern (IN1..IN4)     */
        /* - ISR 只更新 g_u8LastStepIndex/g_u32TraceSteps                */
        /* - main loop 節流印出，避免 UART 輸出拖慢 UVC                  */
        /* ------------------------------------------------------------ */
        if (g_u8TraceEnable && g_u8StepUpdated)
        {
            g_u8StepUpdated = 0;

            /* 每 TRACE_PRINT_DIV 次 step 印一次 */
            if ((g_u32TraceSteps % TRACE_PRINT_DIV) == 0u && g_u32TraceRemain > 0u)
            {
                /* 4-bit pattern 來自表格：1100 -> 0110 -> 0011 -> 1001 */
                uint8_t idx = g_u8LastStepIndex & 0x3u;
                int b1 = g_FullStepSequence[idx][0];
                int b2 = g_FullStepSequence[idx][1];
                int b3 = g_FullStepSequence[idx][2];
                int b4 = g_FullStepSequence[idx][3];

                /* 也順便印出實際 PB DOUT 的狀態（方便確認真的有打到腳位） */
                uint32_t dout = PB->DOUT;
                int in1 = (dout & ULN2003_IN1_PIN) ? 1 : 0;
                int in2 = (dout & ULN2003_IN2_PIN) ? 1 : 0;
                int in3 = (dout & ULN2003_IN3_PIN) ? 1 : 0;
                int in4 = (dout & ULN2003_IN4_PIN) ? 1 : 0;

                printf("[TMR0] step=%lu idx=%u pattern=%d%d%d%d (table)  dout=%d%d%d%d (PB) \n",
                       (unsigned long)g_u32TraceSteps, idx,
                       b1, b2, b3, b4,
                       in1, in2, in3, in4);

                g_u32TraceRemain--;

                if (g_u32TraceRemain == 0u)
                {
                    /* 印完就停 trace（Timer 可繼續跑） */
                    g_u8TraceEnable = 0;
                }
            }
        }

        /* ------------------------------------------------------------ */
        /* Console (getchar) service - non-blocking                      */
        /* ------------------------------------------------------------ */

        for (int i = 0; i < 4; i++)
        {
            int ch = getchar_nb();

            if (ch < 0)
            {
                break;
            }

            ProcessConsoleChar((char)ch);
        }
    }
}

/*** (C) COPYRIGHT 2023 Nuvoton Technology Corp. ***/
