@echo off
setlocal
cd /d "%~dp0"

set "PROJ=%~dp0Keil\DMIC_UAC_Codec_Monitor.uvprojx"
set "UV4=C:\Keil_v5\UV4\UV4.exe"
set "BSP_HEADER=%~dp0..\..\..\Library\Device\Nuvoton\M55M1\Include\NuMicro.h"

if not exist "%BSP_HEADER%" (
    echo [ERROR] BSP relative path is not correct.
    echo Put this whole folder at:
    echo M55M1BSP-3.01.004\SampleCode\StdDriver\DMIC_UAC_Codec_Monitor
    pause
    exit /b 1
)

if not exist "%UV4%" (
    echo [ERROR] Keil UV4 not found: %UV4%
    echo Edit UV4 in this BAT if Keil is installed elsewhere.
    pause
    exit /b 1
)

if not exist "%PROJ%" (
    echo [ERROR] Project not found: %PROJ%
    pause
    exit /b 1
)

if not exist "%~dp0Keil\release" mkdir "%~dp0Keil\release"

echo Building DMIC_UAC_Codec_Monitor ...
"%UV4%" -j0 -r "%PROJ%" -o "%~dp0Keil\build.log"
set "RET=%ERRORLEVEL%"

echo.
type "%~dp0Keil\build.log"
echo.

if not "%RET%"=="0" (
    echo [ERROR] Keil build command returned %RET%.
    pause
    exit /b %RET%
)

echo [OK] Keil build command completed.
pause
