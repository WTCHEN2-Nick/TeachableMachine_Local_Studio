/**************************************************************************//**
 * @file     BoardInit.c
 * @version  V1.00
 * @brief    Target board initiate function for the DMIC UAC + codec monitor sample.
 *
 * Derived from SampleCode/MachineLearning/KeywordSpotting/BoardInit.cpp with the
 * Ethos-U NPU bring-up and the ml-embedded-evaluation-kit logging removed, so
 * this project builds as plain C with no ThirdParty dependencies.
 *
 * @copyright SPDX-License-Identifier: Apache-2.0
 * @copyright Copyright (C) 2023 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/
#include <stdio.h>

#include "NuMicro.h"
#include "BoardInit.h"

#define DESIGN_NAME "M55M1"

static void SYS_Init(void)
{
    /*------------------------------------------------------------------*/
    /* Init System Clock                                                */
    /*------------------------------------------------------------------*/

    /* Enable Internal RC 12MHz clock */
    CLK_EnableXtalRC(CLK_SRCCTL_HIRCEN_Msk);

    /* Waiting for Internal RC clock ready */
    CLK_WaitClockReady(CLK_STATUS_HIRCSTB_Msk);

    /* Enable HXT clock */
    CLK_EnableXtalRC(CLK_SRCCTL_HXTEN_Msk);

    /* Waiting for HXT clock ready */
    CLK_WaitClockReady(CLK_STATUS_HXTSTB_Msk);

    /* Switch SCLK clock source to APLL0 and Enable APLL0 220MHz clock */
    CLK_SetBusClock(CLK_SCLKSEL_SCLKSEL_APLL0, CLK_APLLCTL_APLLSRC_HXT, FREQ_220MHZ);

    /* Update System Core Clock */
    SystemCoreClockUpdate();

    /* Enable GPIO module clock */
    CLK_EnableModuleClock(GPIOA_MODULE);
    CLK_EnableModuleClock(GPIOB_MODULE);
    CLK_EnableModuleClock(GPIOC_MODULE);
    CLK_EnableModuleClock(GPIOD_MODULE);
    CLK_EnableModuleClock(GPIOE_MODULE);
    CLK_EnableModuleClock(GPIOF_MODULE);
    CLK_EnableModuleClock(GPIOG_MODULE);
    CLK_EnableModuleClock(GPIOH_MODULE);
    CLK_EnableModuleClock(GPIOI_MODULE);
    CLK_EnableModuleClock(GPIOJ_MODULE);

    /* Enable FMC0 module clock */
    CLK_EnableModuleClock(FMC0_MODULE);

    /* NOTE: NPU0_MODULE clock is intentionally NOT enabled - this build has no
             Ethos-U usage. Re-enable it when the P0' AI firmware grows out of
             this project. */

    /* Select debug UART module clock source */
    SetDebugUartCLK();

    /* DMIC_APLL1_FREQ_196608KHZ supports 8000/16000/48000 Hz sample rates with
       64/128/256 down-sample. */
    CLK_EnableAPLL(CLK_APLLCTL_APLLSRC_HIRC, DMIC_APLL1_FREQ_196608KHZ, CLK_APLL1_SELECT);
    /* Select DMIC CLK source from APLL1_DIV2. */
    CLK_SetModuleClock(DMIC0_MODULE, CLK_DMICSEL_DMIC0SEL_APLL1_DIV2, MODULE_NoMsk);
    /* Enable DMIC clock. */
    CLK_EnableModuleClock(DMIC0_MODULE);
    /* DMIC IP reset. */
    SYS_ResetModule(SYS_DMIC0RST);

    /* LPPDMA init. */
    CLK_EnableModuleClock(LPPDMA0_MODULE);
    CLK_EnableModuleClock(LPSRAM0_MODULE);
    SYS_ResetModule(SYS_LPPDMA0RST);

    /* Enable HSOTG module clock */
    CLK_EnableModuleClock(HSOTG0_MODULE);

    /* Select HSOTG PHY Reference clock frequency which is from HXT */
    HSOTG_SET_PHY_REF_CLK(HSOTG_PHYCTL_FSEL_24_0M);

    /* Set HSUSB role to HSUSBD */
    SET_HSUSBDROLE();

    /* Enable HSUSB PHY */
    SYS_Enable_HSUSB_PHY();

    /* Enable HSUSBD peripheral clock */
    CLK_EnableModuleClock(HSUSBD0_MODULE);

    /*------------------------------------------------------------------*/
    /* Init I/O Multi-function                                          */
    /*------------------------------------------------------------------*/

    /* Set multi-function pins for UART RXD and TXD */
    SetDebugUartMFP();

    /* Set multi-function pins for DMIC.
       NOTE: PB4/PB5 come from the NuMaker-M55M1 samples. Verify against the
             NuMaker-X-M55M1D schematic before trusting a silent capture. */
    SET_DMIC0_CLK_PB4();
    SET_DMIC0_DAT_PB5();
}

/**
  * @brief Initiate the hardware resources of board
  * @return 0: Success, <0: Fail
  */
int BoardInit(void)
{
    /* Unlock protected registers */
    SYS_UnlockReg();

    SYS_Init();

    /* UART init - enables printf (stdout re-directed at the debug UART) */
    InitDebugUart();

    SYS_LockReg();

    printf("BoardInit: complete\n");
    printf("Target system: %s\n", DESIGN_NAME);
    printf("System core clock = %u Hz\n", (unsigned)SystemCoreClock);

    return 0;
}
