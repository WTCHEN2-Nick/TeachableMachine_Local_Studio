/**************************************************************************//**
 * @file     main.c
 * @version  V2.00
 * @brief    NuMaker-X-M55M1D DMIC -> USB UAC + local codec headphone monitor.
 *
 * The uploaded, already-building UAC project remains intact as the capture source.
 * This version adds a second consumer of the same 16 kHz mono PCM stream:
 *
 *   DMIC0 (PB.4 CLK / PB.5 DAT)
 *       -> LPPDMA0 ch2
 *       -> application ring buffer
 *            |-> HSUSBD UAC 1.0 microphone -> PC (optional)
 *            '-> NAU8822 -> I2S0 -> phone jack -> headphones
 *
 * Local playback does not require a PC or Windows "Listen to this device".
 * The mono sample is duplicated to left and right, so both ears hear the same
 * signal. Use headphones, not speakers, to avoid acoustic feedback.
 *
 * SPDX-License-Identifier: Apache-2.0
 ******************************************************************************/
#include <stdio.h>
#include <stdlib.h>

#include "NuMicro.h"
#include "BoardInit.h"
#include "DMICRecord.h"
#include "CodecMonitor.h"
#include "usbd_audio.h"

/*---------------------------------------------------------------------------*/
/* Capture configuration                                                     */
/*---------------------------------------------------------------------------*/
#define AUDIO_SAMPLE_RATE       AUDIO_RATE
#define AUDIO_CHANNELS          REC_CHANNELS

#if (AUDIO_SAMPLE_RATE != 16000)
#error "Codec monitor currently requires AUDIO_RATE = 16000 Hz"
#endif

#if (AUDIO_CHANNELS != 1)
#error "Codec monitor currently requires REC_CHANNELS = 1 (mono)"
#endif

/* The app ring stores 32 monitor blocks = 320 ms of slack. */
#define APP_BLOCK_SAMPLES       CODEC_MONITOR_BLOCK_SAMPLES
#define APP_BLOCK_COUNTS        (32U)
#define READ_CHUNK_SAMPLES      CODEC_MONITOR_BLOCK_SAMPLES

/* 100 x 10 ms = one level report per second. */
#define REPORT_EVERY_CHUNKS     (100U)
#define CLIP_THRESHOLD          (31000)

static void PrintLevel(int32_t i32Peak,
                       uint32_t u32ClipCount,
                       uint32_t u32CodecUnderruns)
{
    const int i32BarWidth = 20;
    int i32Filled = (int)(((int64_t)i32Peak * i32BarWidth) / 32768);
    int i;

    if (i32Filled > i32BarWidth)
        i32Filled = i32BarWidth;

    printf("[");

    for (i = 0; i < i32BarWidth; i++)
        printf(i < i32Filled ? "#" : "-");

    printf("] peak=%5d (%3d%%) codec_underrun=%u",
           (int)i32Peak,
           (int)(((int64_t)i32Peak * 100) / 32768),
           (unsigned)u32CodecUnderruns);

    if (u32ClipCount != 0U)
        printf("  *** CLIP x%u -- lower DMIC_DSP_GAIN_DB ***",
               (unsigned)u32ClipCount);

    printf("\n");
}

int main(void)
{
    static int16_t ai16Chunk[READ_CHUNK_SAMPLES * AUDIO_CHANNELS];
    int32_t i32Peak = 0;
    uint32_t u32ClipCount = 0U;
    uint32_t u32ChunkCount = 0U;
    int32_t i32Ret;

    if (BoardInit() != 0)
    {
        printf("BoardInit failed\n");
        while (1);
    }

    printf("\n");
    printf("+----------------------------------------------------------+\n");
    printf("| M55M1 DMIC -> UAC microphone + NAU8822 phone jack       |\n");
    printf("+----------------------------------------------------------+\n");
    printf("Sample rate      : %u Hz\n", (unsigned)AUDIO_SAMPLE_RATE);
    printf("DMIC format      : mono, signed 16-bit PCM\n");
    printf("Local playback   : mono duplicated to headphone L/R\n");
    printf("USB microphone   : HSUSBD UAC 1.0 (optional)\n");
    printf("Phone jack       : enabled by PD.1 = LOW\n");
    printf("Monitor block    : %u samples / 10 ms, triple buffered\n",
           (unsigned)CODEC_MONITOR_BLOCK_SAMPLES);
    printf("Monitor volume   : attenuation shift %u\n",
           (unsigned)CODEC_MONITOR_ATTENUATION_SHIFT);
    printf("\n");

    /* Bring up the board codec before audio capture starts. I2S0 uses HIRC for
     * its 12 MHz MCLK, leaving the existing APLL1 DMIC clock unchanged. */
    i32Ret = CodecMonitor_Init(AUDIO_SAMPLE_RATE);

    if (i32Ret != 0)
    {
        printf("CodecMonitor_Init failed (%d)\n", (int)i32Ret);
        while (1);
    }

    /* DMICRecord_Init also brings up the existing HSUSBD UAC interface. */
    i32Ret = DMICRecord_Init(AUDIO_SAMPLE_RATE,
                             AUDIO_CHANNELS,
                             APP_BLOCK_SAMPLES,
                             APP_BLOCK_COUNTS);

    if (i32Ret != 0)
    {
        printf("DMICRecord_Init failed (%d)\n", (int)i32Ret);
        while (1);
    }

    DMICRecord_StartRec();

    printf("\nPut on headphones at low volume and speak near the DMIC.\n");
    printf("The first three 10 ms blocks pre-fill the codec buffer.\n");
    printf("USB connection is optional; local monitoring runs without a PC.\n\n");

    while (1)
    {
        uint32_t i;

        /* Do not remove data from the DMIC app ring until the codec confirms
         * that one complete block can be queued. */
        if (CodecMonitor_CanAcceptBlock() == 0U)
            continue;

        if (DMICRecord_AvailSamples() < (int32_t)READ_CHUNK_SAMPLES)
            continue;

        if (DMICRecord_ReadSamples(ai16Chunk, READ_CHUNK_SAMPLES) != 0)
            continue;

        if (CodecMonitor_SubmitBlock(ai16Chunk,
                                     READ_CHUNK_SAMPLES) != 0)
        {
            /* Read index is intentionally not advanced; retry this exact block. */
            continue;
        }

        DMICRecord_UpdateReadSampleIndex(READ_CHUNK_SAMPLES);

        for (i = 0U; i < (READ_CHUNK_SAMPLES * AUDIO_CHANNELS); i++)
        {
            int32_t i32Abs = ai16Chunk[i];

            if (i32Abs < 0)
                i32Abs = -i32Abs;

            if (i32Abs > i32Peak)
                i32Peak = i32Abs;

            if (i32Abs >= CLIP_THRESHOLD)
                u32ClipCount++;
        }

        if (++u32ChunkCount >= REPORT_EVERY_CHUNKS)
        {
            PrintLevel(i32Peak,
                       u32ClipCount,
                       CodecMonitor_GetUnderrunCount());
            i32Peak = 0;
            u32ClipCount = 0U;
            u32ChunkCount = 0U;
        }
    }
}
