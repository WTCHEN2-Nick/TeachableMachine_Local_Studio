/**************************************************************************//**
 * @file     CodecMonitor.c
 * @version  V1.00
 * @brief    Play DMIC PCM through the NuMaker-X-M55M1D NAU8822 phone jack.
 *
 * Hardware path (from the official M55M1BSP V3.01.004 DMIC_I2S_Play sample):
 *   I2C3 : PG.1 SDA, PG.0 SCL -> NAU8822 control
 *   I2S0 : PI.6 BCLK, PI.7 MCLK, PI.8 DI, PI.9 DO, PI.10 LRCK
 *   PD.1 : JK-EN, drive low to enable the phone jack
 *   PDMA0 channel 2 -> I2S0 TX
 *
 * SPDX-License-Identifier: Apache-2.0
 ******************************************************************************/
#include <stdio.h>
#include <string.h>

#include "NuMicro.h"
#include "CodecMonitor.h"

#define CODEC_I2C_PORT                 I2C3
#define CODEC_I2C_BUS_HZ               (100000U)
#define CODEC_NAU8822_ADDR             (0x1AU)
#define CODEC_I2S_TX_PDMA_CH           (2U)
#define CODEC_SUPPORTED_SAMPLE_RATE    (16000U)
#define CODEC_I2S_WORDS_PER_BLOCK      (CODEC_MONITOR_BLOCK_SAMPLES)

typedef enum
{
    E_CODEC_BUF_EMPTY = 0,
    E_CODEC_BUF_FILLING,
    E_CODEC_BUF_READY,
    E_CODEC_BUF_PLAYING
} E_CODEC_BUF_STATE;

/* Each 32-bit word contains one stereo frame: the same signed 16-bit mono
 * sample is copied into both left and right channels. The buffers are in a
 * non-cacheable SRAM section so PDMA always sees the newest PCM. */
#if (NVT_DCACHE_ON == 1)
NVT_NONCACHEABLE __attribute__((aligned(32)))
static uint32_t s_au32I2sTxBuffer[CODEC_MONITOR_BUFFER_COUNT]
                                     [CODEC_I2S_WORDS_PER_BLOCK];
NVT_DTCM __ALIGNED(32)
static DSCT_T s_asI2sTxDesc[CODEC_MONITOR_BUFFER_COUNT];
#else
static uint32_t s_au32I2sTxBuffer[CODEC_MONITOR_BUFFER_COUNT]
                                     [CODEC_I2S_WORDS_PER_BLOCK]
                                     __attribute__((aligned(32)));
static DSCT_T s_asI2sTxDesc[CODEC_MONITOR_BUFFER_COUNT]
                                     __attribute__((aligned(32)));
#endif

static volatile uint8_t  s_au8BufferState[CODEC_MONITOR_BUFFER_COUNT];
static volatile uint8_t  s_u8CurrentPlaying;
static volatile uint8_t  s_u8Started;
static volatile uint32_t s_u32UnderrunCount;

/*---------------------------------------------------------------------------------------------------------*/
/* NAU8822 control                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
static void NAU8822_WriteReg(uint8_t u8Addr, uint16_t u16Data)
{
    I2C_START(CODEC_I2C_PORT);
    I2C_WAIT_READY(CODEC_I2C_PORT);

    I2C_SET_DATA(CODEC_I2C_PORT, CODEC_NAU8822_ADDR << 1);
    I2C_SET_CONTROL_REG(CODEC_I2C_PORT, I2C_CTL_SI);
    I2C_WAIT_READY(CODEC_I2C_PORT);

    I2C_SET_DATA(CODEC_I2C_PORT,
                 (uint8_t)(((uint32_t)u8Addr << 1) | (u16Data >> 8)));
    I2C_SET_CONTROL_REG(CODEC_I2C_PORT, I2C_CTL_SI);
    I2C_WAIT_READY(CODEC_I2C_PORT);

    I2C_SET_DATA(CODEC_I2C_PORT, (uint8_t)(u16Data & 0x00FFU));
    I2C_SET_CONTROL_REG(CODEC_I2C_PORT, I2C_CTL_SI);
    I2C_WAIT_READY(CODEC_I2C_PORT);

    I2C_STOP(CODEC_I2C_PORT);
}

static void NAU8822_Setup(void)
{
    printf("Configure NAU8822 ... ");

    NAU8822_WriteReg(0,  0x000);   /* Reset all registers */
    CLK_SysTickDelay(10000);

    /* These values are the NAU8822 path used by the official
     * SampleCode/StdDriver/DMIC_I2S_Play sample. The codec receives PCM from
     * I2S0; its analogue microphone/ADC path is not used for this monitor. */
    NAU8822_WriteReg(1,  0x02F);
    NAU8822_WriteReg(2,  0x1BF);   /* Enable L/R headphone output stages */
    NAU8822_WriteReg(3,  0x07F);   /* Enable L/R main mixers and DAC */
    NAU8822_WriteReg(4,  0x010);   /* 16-bit I2S, stereo */
    NAU8822_WriteReg(5,  0x000);   /* Disable companding and codec loopback */
    NAU8822_WriteReg(6,  0x14D);
    NAU8822_WriteReg(7,  0x000);
    NAU8822_WriteReg(10, 0x008);   /* DAC soft mute off */
    NAU8822_WriteReg(14, 0x108);
    NAU8822_WriteReg(15, 0x1EF);
    NAU8822_WriteReg(16, 0x1EF);
    NAU8822_WriteReg(44, 0x000);
    NAU8822_WriteReg(47, 0x050);
    NAU8822_WriteReg(48, 0x050);
    NAU8822_WriteReg(50, 0x001);   /* Left DAC -> left mixer */
    NAU8822_WriteReg(51, 0x001);   /* Right DAC -> right mixer */

    printf("OK\n");
}

static void NAU8822_ConfigSampleRate16000(void)
{
    /* 12 MHz MCLK -> codec PLL 12.288 MHz, then divide to 16 kHz. */
    NAU8822_WriteReg(36, 0x008);
    NAU8822_WriteReg(37, 0x00C);
    NAU8822_WriteReg(38, 0x093);
    NAU8822_WriteReg(39, 0x0E9);
    NAU8822_WriteReg(6,  0x1AD);   /* Divide by 6, codec is I2S clock master */
    NAU8822_WriteReg(7,  0x006);   /* 16 kHz internal filter coefficients */
}

/*---------------------------------------------------------------------------------------------------------*/
/* PDMA/I2S                                                                                                */
/*---------------------------------------------------------------------------------------------------------*/
NVT_ITCM void PDMA0_IRQHandler(void)
{
    uint32_t u32TDStatus = PDMA_GET_TD_STS(PDMA0);

    if ((u32TDStatus & (1UL << CODEC_I2S_TX_PDMA_CH)) != 0U)
    {
        uint8_t u8Completed;
        uint8_t u8Next;

        PDMA_CLR_TD_FLAG(PDMA0, (1UL << CODEC_I2S_TX_PDMA_CH));

        if (s_u8Started != 0U)
        {
            u8Completed = s_u8CurrentPlaying;
            u8Next = (uint8_t)((u8Completed + 1U) % CODEC_MONITOR_BUFFER_COUNT);

            s_au8BufferState[u8Completed] = E_CODEC_BUF_EMPTY;
            s_u8CurrentPlaying = u8Next;

            if (s_au8BufferState[u8Next] == E_CODEC_BUF_READY)
            {
                s_au8BufferState[u8Next] = E_CODEC_BUF_PLAYING;
            }
            else
            {
                /* The scatter descriptor has already advanced. Keep state
                 * coherent and count the event; normally the third buffer gives
                 * the main loop two full block periods to refill this slot. */
                s_au8BufferState[u8Next] = E_CODEC_BUF_PLAYING;
                s_u32UnderrunCount++;
            }
        }
    }

    __DSB();
    __ISB();
}

static uint32_t CodecMonitor_AllBuffersReady(void)
{
    uint32_t i;

    for (i = 0U; i < CODEC_MONITOR_BUFFER_COUNT; i++)
    {
        if (s_au8BufferState[i] != E_CODEC_BUF_READY)
            return 0U;
    }

    return 1U;
}

static void CodecMonitor_Start(void)
{
    s_u8CurrentPlaying = 0U;
    s_au8BufferState[0] = E_CODEC_BUF_PLAYING;
    s_u8Started = 1U;

    I2S_ENABLE_TXDMA(I2S0);
    I2S_ENABLE_TX(I2S0);
}

int32_t CodecMonitor_Init(uint32_t u32SampleRate)
{
    uint32_t i;
    uint32_t u32I2sReportedRate;
    uint32_t u32Mclk;

    if (u32SampleRate != CODEC_SUPPORTED_SAMPLE_RATE)
        return -1;

    SYS_UnlockReg();

    CLK_EnableModuleClock(I2C3_MODULE);
    CLK_EnableModuleClock(I2S0_MODULE);
    CLK_EnableModuleClock(PDMA0_MODULE);

    SYS_ResetModule(SYS_I2C3RST);
    SYS_ResetModule(SYS_I2S0RST);
    SYS_ResetModule(SYS_PDMA0RST);

    /* Keep APLL1 dedicated to the already-working DMIC path. I2S0 only needs
     * a 12 MHz MCLK because the NAU8822 generates BCLK/LRCK and M55M1 is slave. */
    CLK_SetModuleClock(I2S0_MODULE,
                       CLK_I2SSEL_I2S0SEL_HIRC,
                       MODULE_NoMsk);

    SET_I2C3_SDA_PG1();
    SET_I2C3_SCL_PG0();
    PG->SMTEN |= GPIO_SMTEN_SMTEN0_Msk;

    SET_I2S0_BCLK_PI6();
    SET_I2S0_MCLK_PI7();
    SET_I2S0_DI_PI8();
    SET_I2S0_DO_PI9();
    SET_I2S0_LRCK_PI10();
    PI->SMTEN |= GPIO_SMTEN_SMTEN6_Msk;

    /* JK-EN is active low on the NuMaker board. */
    SET_GPIO_PD1();

    SYS_LockReg();

    GPIO_SetMode(PD, BIT1, GPIO_MODE_OUTPUT);
    PD1 = 0;

    I2C_Open(CODEC_I2C_PORT, CODEC_I2C_BUS_HZ);
    printf("Codec I2C3 clock = %u Hz\n",
           (unsigned)I2C_GetBusClockFreq(CODEC_I2C_PORT));

    /* Stereo is intentional: every mono DMIC sample is duplicated to L/R. */
    u32I2sReportedRate = I2S_Open(I2S0,
                                  I2S_MODE_SLAVE,
                                  u32SampleRate,
                                  I2S_DATABIT_16,
                                  I2S_STEREO,
                                  I2S_FORMAT_I2S);
    u32Mclk = I2S_EnableMCLK(I2S0, 12000000U);
    I2S0->CTL0 |= I2S_CTL0_ORDER_Msk;
    I2S_CLR_TX_FIFO(I2S0);

    printf("I2S0 slave requested = %u Hz, divider report = %u Hz\n",
           (unsigned)u32SampleRate,
           (unsigned)u32I2sReportedRate);
    printf("I2S0 MCLK = %u Hz\n", (unsigned)u32Mclk);

    NAU8822_Setup();
    NAU8822_ConfigSampleRate16000();

    memset((void *)s_au32I2sTxBuffer, 0, sizeof(s_au32I2sTxBuffer));
    memset((void *)s_au8BufferState, 0, sizeof(s_au8BufferState));
    s_u8CurrentPlaying = 0U;
    s_u8Started = 0U;
    s_u32UnderrunCount = 0U;

    for (i = 0U; i < CODEC_MONITOR_BUFFER_COUNT; i++)
    {
        uint32_t u32Next = (i + 1U) % CODEC_MONITOR_BUFFER_COUNT;

        s_asI2sTxDesc[i].CTL =
            ((CODEC_I2S_WORDS_PER_BLOCK - 1U) << PDMA_DSCT_CTL_TXCNT_Pos) |
            PDMA_WIDTH_32 |
            PDMA_SAR_INC |
            PDMA_DAR_FIX |
            PDMA_REQ_SINGLE |
            PDMA_OP_SCATTER;
        s_asI2sTxDesc[i].SA = (uint32_t)&s_au32I2sTxBuffer[i][0];
        s_asI2sTxDesc[i].DA = (uint32_t)&I2S0->TXFIFO;
        s_asI2sTxDesc[i].NEXT = (uint32_t)&s_asI2sTxDesc[u32Next];
    }

    PDMA_Open(PDMA0, (1UL << CODEC_I2S_TX_PDMA_CH));
    PDMA_SetTransferMode(PDMA0,
                         CODEC_I2S_TX_PDMA_CH,
                         PDMA_I2S0_TX,
                         TRUE,
                         (uint32_t)&s_asI2sTxDesc[0]);
    PDMA_EnableInt(PDMA0,
                   CODEC_I2S_TX_PDMA_CH,
                   PDMA_INT_TRANS_DONE);

    NVIC_SetPriority(PDMA0_IRQn, 2U);
    NVIC_EnableIRQ(PDMA0_IRQn);

    printf("Phone jack enabled: PD.1 (JK-EN) = LOW\n");
    printf("Local monitor: mono DMIC duplicated to L/R, attenuation shift = %u\n",
           (unsigned)CODEC_MONITOR_ATTENUATION_SHIFT);

    return 0;
}

uint32_t CodecMonitor_CanAcceptBlock(void)
{
    uint32_t i;

    for (i = 0U; i < CODEC_MONITOR_BUFFER_COUNT; i++)
    {
        if (s_au8BufferState[i] == E_CODEC_BUF_EMPTY)
            return 1U;
    }

    return 0U;
}

int32_t CodecMonitor_SubmitBlock(const int16_t *pi16Samples,
                                 uint32_t u32SampleCount)
{
    uint32_t i;
    uint32_t u32BufferIndex = CODEC_MONITOR_BUFFER_COUNT;
    uint32_t u32Primask;

    if ((pi16Samples == NULL) ||
        (u32SampleCount != CODEC_MONITOR_BLOCK_SAMPLES))
    {
        return -1;
    }

    u32Primask = __get_PRIMASK();
    __disable_irq();

    for (i = 0U; i < CODEC_MONITOR_BUFFER_COUNT; i++)
    {
        if (s_au8BufferState[i] == E_CODEC_BUF_EMPTY)
        {
            u32BufferIndex = i;
            s_au8BufferState[i] = E_CODEC_BUF_FILLING;
            break;
        }
    }

    __set_PRIMASK(u32Primask);

    if (u32BufferIndex >= CODEC_MONITOR_BUFFER_COUNT)
        return -2;

    for (i = 0U; i < CODEC_MONITOR_BLOCK_SAMPLES; i++)
    {
        int32_t i32Sample = pi16Samples[i];
        uint16_t u16Pcm;

#if (CODEC_MONITOR_ATTENUATION_SHIFT > 0)
        i32Sample /= (1L << CODEC_MONITOR_ATTENUATION_SHIFT);
#endif
        u16Pcm = (uint16_t)(int16_t)i32Sample;
        s_au32I2sTxBuffer[u32BufferIndex][i] =
            ((uint32_t)u16Pcm << 16) | (uint32_t)u16Pcm;
    }

    u32Primask = __get_PRIMASK();
    __disable_irq();

    /* In normal operation a triple buffer leaves two block periods before a
     * just-finished slot is used again. If an extreme stall let PDMA reach this
     * FILLING slot, do not incorrectly change PLAYING back to READY. */
    if (s_au8BufferState[u32BufferIndex] != E_CODEC_BUF_FILLING)
    {
        __set_PRIMASK(u32Primask);
        return -3;
    }

    s_au8BufferState[u32BufferIndex] = E_CODEC_BUF_READY;

    if ((s_u8Started == 0U) && CodecMonitor_AllBuffersReady())
        CodecMonitor_Start();

    __set_PRIMASK(u32Primask);

    return 0;
}

uint32_t CodecMonitor_IsStarted(void)
{
    return (uint32_t)s_u8Started;
}

uint32_t CodecMonitor_GetUnderrunCount(void)
{
    return s_u32UnderrunCount;
}
