/**************************************************************************//**
 * @file     CodecMonitor.h
 * @version  V1.00
 * @brief    DMIC PCM local monitor through NAU8822 and the board phone jack.
 *
 * The source is mono 16-bit PCM. Each sample is duplicated to the left and
 * right I2S channels so the same microphone signal is heard in both ears.
 *
 * SPDX-License-Identifier: Apache-2.0
 ******************************************************************************/
#ifndef __CODEC_MONITOR_H__
#define __CODEC_MONITOR_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* One block is 10 ms at 16 kHz. Three buffers give about 30 ms of buffering
 * while still leaving two complete blocks ahead of the DMA reader. */
#define CODEC_MONITOR_BLOCK_SAMPLES          (160U)
#define CODEC_MONITOR_BUFFER_COUNT           (3U)

/* Local headphone attenuation only. USB UAC samples are not changed.
 *   0 = 100% (0 dB)
 *   1 =  50% (-6 dB, safer default)
 *   2 =  25% (-12 dB)
 */
#define CODEC_MONITOR_ATTENUATION_SHIFT      (1U)

/* Initialise I2C3 + NAU8822 + I2S0 + PDMA0 and enable the phone jack.
 * This project supports 16000 Hz only because the DMIC/UAC path is fixed at
 * that rate. Returns 0 on success, negative on invalid arguments. */
int32_t CodecMonitor_Init(uint32_t u32SampleRate);

/* Returns non-zero when a complete CODEC_MONITOR_BLOCK_SAMPLES block can be
 * accepted immediately. */
uint32_t CodecMonitor_CanAcceptBlock(void);

/* Submit exactly CODEC_MONITOR_BLOCK_SAMPLES mono signed-16 PCM samples.
 * The first three blocks pre-fill the triple buffer; playback then starts
 * automatically. Returns 0 on success, negative when busy/invalid. */
int32_t CodecMonitor_SubmitBlock(const int16_t *pi16Samples,
                                 uint32_t u32SampleCount);

uint32_t CodecMonitor_IsStarted(void);
uint32_t CodecMonitor_GetUnderrunCount(void);

#ifdef __cplusplus
}
#endif

#endif /* __CODEC_MONITOR_H__ */
