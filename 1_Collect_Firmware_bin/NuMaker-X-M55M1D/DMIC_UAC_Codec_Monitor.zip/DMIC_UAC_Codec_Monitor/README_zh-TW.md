# NuMaker-X-M55M1D：DMIC → NAU8822 → Phone Jack 即時監聽

這個版本直接以你上傳、已經能在 Keil **0 Error / 0 Warning** 編譯的
`DMIC_UAC_Mic` 為基礎修改，不重做原本的 DMIC 與 UAC 架構。

新增功能是：

```text
板載 DMIC
PB.4 = DMIC0_CLK
PB.5 = DMIC0_DAT
        │
        ▼
DMIC0，16 kHz / mono / signed 16-bit PCM
        │
        ▼
LPPDMA0 channel 2
        │
        ├────────► HSUSBD UAC 1.0 ───────► PC 麥克風（保留）
        │
        └────────► App PCM ring buffer
                          │
                          ▼
                    I2S0 + PDMA0 ch2
                          │
                          ▼
                       NAU8822
                          │
                          ▼
                 板上 Phone Jack／耳機
```

也就是說：**不需要在 Windows 勾「聆聽此裝置」**，也不需要 PC 幫忙把聲音送回來。
只要板子有供電，插上耳機，就能直接聽到板載 DMIC 收到的聲音。

同時，原本的 USB UAC 麥克風功能仍然保留；接上 HSUSB 時，PC 仍可看到
`M55M1 DMIC Mic`。

---

## 1. 使用的板載硬體

本地播放部分採用 M55M1BSP V3.01.004 官方 `DMIC_I2S_Play` 範例所使用的板級設定：

| 功能 | M55M1 腳位／模組 |
|---|---|
| DMIC Clock | PB.4 / DMIC0_CLK |
| DMIC Data | PB.5 / DMIC0_DAT |
| Codec Control SDA | PG.1 / I2C3_SDA |
| Codec Control SCL | PG.0 / I2C3_SCL |
| Codec BCLK | PI.6 / I2S0_BCLK |
| Codec MCLK | PI.7 / I2S0_MCLK |
| Codec DI | PI.8 / I2S0_DI |
| Codec DO | PI.9 / I2S0_DO |
| Codec LRCK | PI.10 / I2S0_LRCK |
| Phone Jack Enable | PD.1，輸出 LOW |
| Audio Codec | NAU8822 |
| I2S TX DMA | PDMA0 channel 2 |
| DMIC RX DMA | LPPDMA0 channel 2 |

`PDMA0 channel 2` 和 `LPPDMA0 channel 2` 是兩個不同的 DMA 控制器，因此不衝突。

---

## 2. 聲音格式與延遲

```text
DMIC sample rate       16,000 Hz
DMIC channels          1 channel，mono
PCM format             signed 16-bit
Codec output           stereo I2S
Left headphone         DMIC mono sample
Right headphone        同一份 DMIC mono sample
Monitor block          160 samples = 10 ms
Monitor buffer count   3
Initial buffering      約 30 ms
```

程式不是把 mono 當成只有左耳，而是將每一個 DMIC sample 複製到 I2S 的 Left/Right，
因此兩邊耳機都能聽到相同聲音。

---

## 3. 放到 BSP 的位置

請把整個資料夾放到：

```text
M55M1BSP-3.01.004
└─ SampleCode
   └─ StdDriver
      └─ DMIC_UAC_Codec_Monitor
```

最後專案路徑應為：

```text
M55M1BSP-3.01.004\SampleCode\StdDriver\DMIC_UAC_Codec_Monitor
```

專案使用 BSP 內的相對路徑，因此不要只把 `Keil` 資料夾單獨搬走。

---

## 4. 編譯

可以直接執行：

```text
01_BUILD_KEIL.bat
```

或執行：

```text
02_OPEN_KEIL.bat
```

再於 Keil 開啟：

```text
Keil\DMIC_UAC_Codec_Monitor.uvprojx
```

按：

```text
Rebuild
Download
```

Keil project 已新增下列 StdDriver source：

```text
i2c.c
i2s.c
pdma.c
```

並新增：

```text
Codec\CodecMonitor.c
Codec\include\CodecMonitor.h
```

---

## 5. 實際測試方法

1. 先不要戴上耳機，把 Windows／耳機上的音量調低。
2. 將耳機插入 NuMaker-X-M55M1D 板上的 Phone Jack。
3. 使用 Nu-Link 燒錄韌體。
4. Reset 開發板。
5. 再戴上耳機，對板載 DMIC 說話或輕敲 DMIC 附近。
6. 約前三個 10 ms block 填滿後，Phone Jack 開始輸出。

UART 預期會看到：

```text
Codec I2C3 clock = 100000 Hz
I2S0 MCLK = 12000000 Hz
Configure NAU8822 ... OK
Phone jack enabled: PD.1 (JK-EN) = LOW
Local monitor: mono DMIC duplicated to L/R, attenuation shift = 1
DMIC SampleRate is 16000
DMIC DSP gain is +24 dB
```

每秒還會看到：

```text
[##########----------] peak=16384 ( 50%) codec_underrun=0
```

正常狀態應為：

```text
codec_underrun=0
```

---

## 6. 調整耳機音量

### 6.1 只調整本地耳機音量

編輯：

```text
Codec\include\CodecMonitor.h
```

預設：

```c
#define CODEC_MONITOR_ATTENUATION_SHIFT      (1U)
```

意義：

```text
0 = 100%，0 dB，最大
1 =  50%，約 -6 dB，預設且較安全
2 =  25%，約 -12 dB
3 =  12.5%，約 -18 dB
```

這個設定**只影響 Phone Jack**，不會改變送到 PC 的 UAC 錄音振幅。

### 6.2 調整 DMIC 本身增益

編輯：

```text
UAC\usbd_audio.h
```

預設：

```c
#define DMIC_DSP_GAIN_DB    24
```

若 UART 顯示 `CLIP`，請先改成：

```c
#define DMIC_DSP_GAIN_DB    18
```

若 DMIC 與耳機都非常小，可嘗試：

```c
#define DMIC_DSP_GAIN_DB    30
```

不建議一開始就使用 `36 dB`，近距離說話容易削波。

---

## 7. 為什麼 USB 沒接也能聽

原始 UAC 版本的 `UAC_SendRecData()` 每個 DMIC DMA block 都會操作 HSUSBD DMA。
本版本已改成：

```text
DMIC block 完成
    ├─ 一定先送入 application PCM ring buffer，供 Codec 使用
    └─ 只有在：
         1. HSUSB cable 已接上
         2. PC 已選擇 UAC AudioStreaming alternate 1
       才啟動 USB DMA
```

所以本地 Phone Jack 不再依賴 PC，也不會因為 HSUSB 沒接而卡住。

---

## 8. 新增程式的核心結構

### `CodecMonitor_Init()`

負責：

```text
I2C3 clock/MFP
I2S0 clock/MFP
PDMA0 clock
PD.1 = LOW
NAU8822 初始化
NAU8822 16 kHz PLL 設定
I2S0 slave + 12 MHz MCLK
PDMA0 ch2 三組 scatter-gather descriptor
```

### `CodecMonitor_SubmitBlock()`

輸入：

```text
160 個 mono int16_t sample
```

轉換成：

```text
I2S 32-bit stereo frame
upper 16-bit = Right sample
lower 16-bit = Left sample
兩者都是同一個 DMIC sample
```

前三個 block 填滿後，自動啟動 I2S TX。

### `PDMA0_IRQHandler()`

每播放完一個 10 ms block：

```text
目前 block → EMPTY，可由 main refill
下一個 READY block → PLAYING
```

三緩衝讓 CPU 有兩個完整 block 的時間補資料，比雙緩衝更不容易在切換點與 DMA 搶同一塊記憶體。

---

## 9. 安全注意

- 請先把耳機音量調低，再戴上耳機。
- 請使用耳機，不要使用外接喇叭貼近 DMIC，否則會形成聲學回授並發出尖銳聲。
- 若有爆音，先降低 `DMIC_DSP_GAIN_DB`，再增加 `CODEC_MONITOR_ATTENUATION_SHIFT`。
- 這是即時 sidetone，因此聽到自己的聲音有約數十毫秒延遲屬正常現象。

---

## 10. 驗證狀態

已在交付環境完成：

```text
Keil uvprojx XML 解析
Keil uvoptx XML 解析
新增 source/include path 檢查
CodecMonitor.c 語法檢查
main.c 語法檢查
Cortex-M55 target 語法檢查
三緩衝狀態機連續 1000 次 DMA 切換測試
mono 轉左右聲道的 PCM packing 測試
USB descriptor 原始檔保留
上傳版本的 UAC 架構與 descriptor 保留
舊 AXF/BIN/OBJ 已移除，避免誤認為新版本編譯結果
```

目前環境沒有 Keil Arm Compiler 6、Nu-Link、NuMaker-X-M55M1D 與耳機，因此沒有假裝提供
已實板驗證的新 AXF/BIN。請在你的 Keil 執行 Rebuild；若有任何 error，請從第一個 error
開始貼完整 Build Log，後面的 error 常常只是第一個 error 連鎖造成。
