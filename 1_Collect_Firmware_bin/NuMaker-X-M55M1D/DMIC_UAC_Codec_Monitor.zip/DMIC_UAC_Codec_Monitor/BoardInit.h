/**************************************************************************//**
 * @file     BoardInit.h
 * @version  V1.00
 * @brief    Target board related function
 *
 * @copyright SPDX-License-Identifier: Apache-2.0
 * @copyright Copyright (C) 2023 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/
#ifndef __BOARD_INIT_H__
#define __BOARD_INIT_H__

#ifdef __cplusplus
extern "C" {
#endif

/**
  * @brief Initiate the hardware resources
  * @return 0: Success, <0: Fail
  * @details Initiate clock, debug UART, DMIC pins, HSUSBD PHY
  */
int BoardInit(void);

#ifdef __cplusplus
}
#endif

#endif
