/***************************************************************************//**
 * @file     usbd_audio.h
 * @version  V3.00
 * @brief    HSUSBD audio codec header file.
 *
 * @copyright SPDX-License-Identifier: Apache-2.0
 * @copyright Copyright (C) 2021 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/
#ifndef __USBD_UAC_H__
#define __USBD_UAC_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Use LIN as source, undefine it if MIC is used */
//#define INPUT_IS_LIN

/* Define the vendor id and product id */
/* NOTE: VID 0x0416 is Nuvoton's. PID differs from the KeywordSpotting sample
         (0x1287) so both devices can coexist on the same Windows host without
         sharing a cached driver/endpoint description. */
#define USBD_VID        0x0416
#define USBD_PID        0x1288

#define AUDIO_RATE  AUDIO_RATE_16K

#define AUDIO_RATE_16K   16000
#define AUDIO_RATE_48K   48000       /* The audo play sampling rate. The setting is 48KHz */
#define AUDIO_RATE_96K   96000       /* The audo play sampling rate. The setting is 96KHz */
#define AUDIO_RATE_441K  44100       /* The audo play sampling rate. The setting is 44.1KHz */

/*!<Define Audio information */
/* Mono. The on-board DMIC feeds channel 0 only, and the USB descriptor in
   descriptors.c declares bNrChannels = 1, so this MUST stay 1. */
#define REC_CHANNELS    1
#define REC_BIT_RATE    0x10    /* 16-bit data rate */

#define REC_FEATURE_UNITID      0x05

/* Bytes of PCM produced in one 1 ms USB frame.
   16000 Hz * 1 ch * 2 bytes / 1000 = 32 bytes */
#define UAC_REC_BYTES_PER_MS    ((AUDIO_RATE * REC_CHANNELS * 2) / 1000)

/* Size of one PcmRecBuff row. One LPPDMA block == one 1 ms ISO packet, so only
   UAC_REC_BYTES_PER_MS bytes are used; rounded up to a 32-byte cache line. */
#define BUFF_LEN    64

/* DMIC DSP gain in dB (0..36). The Nuvoton samples hard-code +36 dB, which
   clips easily on near-field speech. +24 dB is a safer starting point for
   recording noise/speech datasets; raise it if the level meter stays low. */
#define DMIC_DSP_GAIN_DB    24

/********************************************/
/* Audio Class Current State                */
/********************************************/
/*!<Define Audio Class Current State */
#define UAC_STOP_AUDIO_RECORD           0
#define UAC_START_AUDIO_RECORD          1
#define UAC_PROCESSING_AUDIO_RECORD     2
#define UAC_BUSY_AUDIO_RECORD           3

/***************************************************/
/*      Audio Class-Specific Request Codes         */
/***************************************************/
/*!<Define Audio Class Specific Request */
#define UAC_REQUEST_CODE_UNDEFINED  0x00
#define UAC_SET_CUR                 0x01
#define UAC_GET_CUR                 0x81
#define UAC_SET_MIN                 0x02
#define UAC_GET_MIN                 0x82
#define UAC_SET_MAX                 0x03
#define UAC_GET_MAX                 0x83
#define UAC_SET_RES                 0x04
#define UAC_GET_RES                 0x84
#define UAC_SET_MEM                 0x05
#define UAC_GET_MEM                 0x85
#define UAC_GET_STAT                0xFF

#define MUTE_CONTROL                0x01
#define VOLUME_CONTROL              0x02

/*-------------------------------------------------------------*/
/* Define EP maximum packet size */
#define CEP_MAX_PKT_SIZE        64
#define CEP_OTHER_MAX_PKT_SIZE  64
/* descriptors.c declares wMaxPacketSize = EPA_MAX_PKT_SIZE + 24.
   40 + 24 = 64 bytes, i.e. 2x the 32 bytes actually sent each 1 ms frame. */
#define EPA_MAX_PKT_SIZE            40
#define EPA_OTHER_MAX_PKT_SIZE      40

#define CEP_BUF_BASE    0
#define CEP_BUF_LEN     CEP_MAX_PKT_SIZE
#define EPA_BUF_BASE    0x100
#define EPA_BUF_LEN     0x600

/* Define the interrupt In EP number */
#define ISO_IN_EP_NUM    0x01

#define PDMA_TXBUFFER_CNT     7
#define PDMA_RXBUFFER_CNT     8

/* For I2C transfer */
typedef enum
{
    E_RS_NONE,          // no re-sampling
    E_RS_UP,            // up sampling
    E_RS_DOWN           // down sampling
} RESAMPLE_STATE_T;


/*-------------------------------------------------------------*/
extern volatile uint8_t u8RxDataCntInBuffer;

extern uint32_t volatile u32BuffLen, u32RxBuffLen;
extern uint32_t volatile g_usbd_UsbAudioState;
extern uint32_t g_usbd_SampleRate;

extern uint8_t PcmRecBuff[PDMA_RXBUFFER_CNT][BUFF_LEN];
extern uint8_t u8PcmRxBufFull[PDMA_RXBUFFER_CNT];
extern volatile uint8_t u8PDMARxIdx;

void UAC_DeviceEnable(uint32_t bIsPlay);
void UAC_DeviceDisable(uint32_t bIsPlay);
void UAC_SendRecData(void);

void AudioStartRecord(uint32_t u32SampleRate);
/*-------------------------------------------------------------*/
void UAC_Init(void);
void UAC_ClassRequest(void);
void UAC_SetInterface(uint32_t u32AltInterface);

void EPA_Handler(void);
void timer_init(void);
void AdjustCodecPll(RESAMPLE_STATE_T r);

typedef struct dma_desc_t
{
    uint32_t ctl;
    uint32_t src;
    uint32_t dest;
    uint32_t offset;
} DMA_DESC_T;

extern volatile uint8_t g_usbd_txflag;
extern volatile uint8_t g_usbd_rxflag;
void LPPDMA_init();

#ifdef __cplusplus
}
#endif

#endif  /* __USBD_UAC_H_ */
