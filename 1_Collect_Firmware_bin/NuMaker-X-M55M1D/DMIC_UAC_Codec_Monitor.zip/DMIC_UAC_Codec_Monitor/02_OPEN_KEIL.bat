@echo off
setlocal
cd /d "%~dp0"

set "PROJ=%~dp0Keil\DMIC_UAC_Codec_Monitor.uvprojx"
set "BSP_HEADER=%~dp0..\..\..\Library\Device\Nuvoton\M55M1\Include\NuMicro.h"

if not exist "%BSP_HEADER%" (
    echo [ERROR] Put this whole folder at:
    echo M55M1BSP-3.01.004\SampleCode\StdDriver\DMIC_UAC_Codec_Monitor
    pause
    exit /b 1
)

if exist "C:\Keil_v5\UV4\UV4.exe" (
    start "" "C:\Keil_v5\UV4\UV4.exe" "%PROJ%"
) else (
    start "" "%PROJ%"
)
